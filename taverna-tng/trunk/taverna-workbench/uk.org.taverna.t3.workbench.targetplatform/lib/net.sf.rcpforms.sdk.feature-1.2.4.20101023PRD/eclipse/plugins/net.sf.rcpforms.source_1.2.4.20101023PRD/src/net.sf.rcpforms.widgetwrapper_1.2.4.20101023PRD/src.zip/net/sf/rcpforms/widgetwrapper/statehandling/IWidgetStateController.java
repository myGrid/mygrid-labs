/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher, Christian Spicher - initial API and implementation
 *
 ******************************************************************************
 */
package net.sf.rcpforms.widgetwrapper.statehandling;

import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;

/**
 * The <code><i>IWidgetStateController</i></code> is responsible for 
 * controlling the states of the widgets. The RCP-default {@link WidgetStateManager}
 * may be instructed to use such a <code>IWidgetStateController</code> by
 * setting a global instance via {@link WidgetStateManager#setWidgetStateController(IWidgetStateController)}.
 * <p>
 * This controller is then asked to accept the <b>state</b> of any widget that
 * is being set ({@link RCPControl#setEnabled(boolean)}, {@link RCPControl#setVisible(boolean)},
 * {@link RCPControl#setState(net.sf.rcpforms.widgetwrapper.wrapper.EControlState, boolean)}). 
 * <p>
 * This is useful if the <code><i>IWidgetStateController</i></code> is
 * permission aware and checks whether the current user actually has the right
 * to read or change any widgets.
 * <p>
 */
public interface IWidgetStateController
{
    public int reviewState(final RCPControl rcpControl, final int state);
}