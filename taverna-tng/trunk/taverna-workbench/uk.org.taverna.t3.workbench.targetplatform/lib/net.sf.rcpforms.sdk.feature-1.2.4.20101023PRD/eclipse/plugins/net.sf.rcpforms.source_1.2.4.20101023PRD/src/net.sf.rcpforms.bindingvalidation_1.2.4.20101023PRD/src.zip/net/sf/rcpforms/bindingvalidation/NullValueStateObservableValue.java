/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.bindingvalidation;

import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;

import org.eclipse.core.databinding.observable.Diffs;
import org.eclipse.core.databinding.observable.value.AbstractObservableValue;

/**
 * WidgetObservableValue wraps a widget to unidirectionally synchronize widget state like ENABLED,
 * EDITABLE from a model value. The state is set depending if the model value is <null>;
 * Use this class as:
 * 
 * ValidationManager.bindValue(new NullValueStateObservableValue(RCPControl, EControlState.XYZ, true|false)), beanModel, propertie(s))
 * 
 * @author Remo Loetscher
 */
public class NullValueStateObservableValue extends AbstractObservableValue
{

    private final RCPControl control;

    private final EControlState attribute;

	private final boolean setTrueForNullValue;

    /**
     * @param control
     * @param state
     * @param enableForNullValue inidicates if wigdet state should be set to true if value is null, otherwise sets to false
     */
    public NullValueStateObservableValue(RCPControl control, EControlState state, boolean setTrueForNullValue)
    {
        this.control = control;
        this.attribute = state;
		this.setTrueForNullValue = setTrueForNullValue;
    }

    public void doSetValue(Object value)
    {
        Object oldValue = doGetValue();
        boolean newValue = value == null ? setTrueForNullValue : !setTrueForNullValue;
        control.setState(attribute, newValue);
        fireValueChange(Diffs.createValueDiff(oldValue, newValue));
    }

    public Object doGetValue()
    {
        return !control.hasState(attribute);
    }

    public Object getValueType()
    {
    	return null;
    }

}
