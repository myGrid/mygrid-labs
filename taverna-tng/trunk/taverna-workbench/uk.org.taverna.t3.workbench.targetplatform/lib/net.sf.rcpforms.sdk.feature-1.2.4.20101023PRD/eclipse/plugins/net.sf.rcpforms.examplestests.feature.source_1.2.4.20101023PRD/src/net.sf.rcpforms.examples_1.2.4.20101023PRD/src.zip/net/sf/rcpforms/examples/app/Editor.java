
package net.sf.rcpforms.examples.app;

import net.sf.rcpforms.examples.complete.SandboxStackForm;
import net.sf.rcpforms.examples.complete.models.AddressModel;
import net.sf.rcpforms.examples.complete.models.NestedAddressModel;
import net.sf.rcpforms.form.IRCPFormEditorInput;
import net.sf.rcpforms.form.RCPFormEditorPart;
//import net.sf.rcpforms.form.ValidationRCPFormEditorPart;

import org.eclipse.core.runtime.IProgressMonitor;

public class Editor extends RCPFormEditorPart<SandboxStackForm>
//public class Editor extends ValidationRCPFormEditorPart<SandboxStackForm>
{
    public static final String ID = "net.sf.rcpforms.examples.app.editor";

    public Editor()
    {
        // create
        super(new SandboxStackForm());
    }

    @Override
    public void doSave(IProgressMonitor monitor)
    {
        // sample editors cannot be saved, only dirty state is managed
        this.setDirty(false);
    }

    @Override
    public void doSaveAs()
    {
        // not supported
    }

    @Override
    public boolean isSaveAsAllowed()
    {
        return false;
    }

    @Override
    protected void initializeDirtyChangeListener(IRCPFormEditorInput oldInput,
                                                 IRCPFormEditorInput newInput)
    {
        super.initializeDirtyChangeListener(oldInput, newInput);
        //support dirty states for nested properties
        if(oldInput != null)
        {
            for(Object o : oldInput.getModels())
            {
                if(o instanceof AddressModel)
                {
                   this.removeDirtyChangeListener(o);
                   this.removeDirtyChangeListener(((AddressModel)o).getAddress());
                   this.removeDirtyChangeListener(((NestedAddressModel)((AddressModel)o).getAddress()).getCountry());
                }
            }
        }
        
        for(Object o : newInput.getModels())
        {
            if(o instanceof AddressModel)
            {
               this.addDirtyChangeListener(o);
               this.addDirtyChangeListener(((AddressModel)o).getAddress());
               this.addDirtyChangeListener(((NestedAddressModel)((AddressModel)o).getAddress()).getCountry());
            }
        }
    }
}
