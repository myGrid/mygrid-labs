
package net.sf.rcpforms.tablesupport.tables;

public interface IGenericSorter
{

    public abstract void switchSortDirection();

    public abstract boolean isDescendingOrder();

}