/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.complete.formparts;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.common.model.JavaBean;
import net.sf.rcpforms.examples.complete.IExpandablePart;
import net.sf.rcpforms.examples.complete.models.SimpleBean;
import net.sf.rcpforms.examples.complete.widgets.RCPLabeledPickerComposite;
import net.sf.rcpforms.modeladapter.converter.MethodValidator;
import net.sf.rcpforms.modeladapter.converter.SymmetricMultilineValidator;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.builder.GridLayoutFactory;
import net.sf.rcpforms.widgetwrapper.customwidgets.RCPDatePicker;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPCombo;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPComposite;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPLabeledControl;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleButton;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleLabel;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleText;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * FormPart for GridLayouts in sandbox example. Demonstrates some simple layouts.
 * 
 * @author Remo Loetscher
 */
public class SandboxLayoutFormPart extends RCPFormPart
implements IExpandablePart
{
    private RCPSection mainSection;

    private RCPSimpleText m_multiLineText;

    private RCPSimpleLabel m_labelText;

    private RCPDatePicker m_birthDateText;

    private RCPCombo m_geschlechtCombo;

    private RCPSimpleButton m_kontoueberzugCheck;
    
    private RCPLabeledCheckButton m_kontoueberzugCheckLabel;

    private RCPText m_singleLineText;

    private boolean minimizeSection;

    /**
     * Constructor for KontodatenViewModel.
     */
    public SandboxLayoutFormPart()
    {
    }

    public SandboxLayoutFormPart(boolean minimizeSection)
    {
        this();
        this.minimizeSection = minimizeSection;
    }

    public void createUI(FormToolkit toolkit, Composite parent)
    {
        // create wrappers
        mainSection = new RCPSection("LayoutSection");
        m_labelText = new RCPSimpleLabel("Multiline:");
        m_multiLineText = new RCPSimpleText(SWT.MULTI);
        m_multiLineText.setState(EControlState.MANDATORY, true);

        m_singleLineText = new RCPText("SingleLine:");

        m_birthDateText = new RCPDatePicker("DatePicker:");
        m_birthDateText.setState(EControlState.RECOMMENDED, true);
        m_geschlechtCombo = new RCPCombo("Combo:", false);
        m_kontoueberzugCheck = new RCPSimpleButton("CheckBox", SWT.CHECK | SWT.RIGHT_TO_LEFT);
        
        m_kontoueberzugCheckLabel = new RCPLabeledCheckButton("Labeled Checkbox:");

        // build layout
        GridBuilder builder = new GridBuilder(toolkit, parent, 2);
        GridBuilder widgetBuilder = builder.addContainer(mainSection, 4);

        if(minimizeSection)
            mainSection.getSWTSection().setExpanded(false);
        
        widgetBuilder.add(m_labelText);

        // build customized layout
        GridData gd = GridLayoutFactory.createDefaultLayoutData();
        gd.widthHint = widgetBuilder.getWidthHint(10);
        gd.horizontalSpan = 3;
        gd.grabExcessHorizontalSpace = true;
        gd.heightHint = widgetBuilder.getHeightHint(4);
        gd.verticalSpan = 3;
        gd.grabExcessVerticalSpace = true;
        m_multiLineText.setLayoutData(gd);
        //widgetBuilder.add(m_multiLineText);
        widgetBuilder.add(m_multiLineText, gd);

        widgetBuilder.add(new RCPSimpleLabel("Vertical Span: 2nd Line..."));
        widgetBuilder.add(new RCPSimpleLabel("Vertical Span: 3rd Line..."));
        widgetBuilder.newLine();
        // go ahead with "normal" layout.

        // add empty lines
        widgetBuilder.add(new RCPSimpleLabel("Filler and empty line added..."));
        widgetBuilder.fillLine();
        widgetBuilder.newLine();

        widgetBuilder.fillLine();
        
        RCPText text = new RCPText("Using efficient layout:");
        widgetBuilder.addLineSpan(text, true);
        widgetBuilder.fillLine();
        
        RCPLabeledPickerComposite pcWidget = new RCPLabeledPickerComposite("PickerComposite (using efficient layout)");
        widgetBuilder.addLineSpan(pcWidget, true);
        widgetBuilder.fillLine();
        
        
        pcWidget = new RCPLabeledPickerComposite("PickerComposite:");
        widgetBuilder.addLineSpan(pcWidget, false);
        widgetBuilder.fillLine();
        
        RCPComposite pickerComposite = new RCPComposite();
        RCPDatePicker datePicker = new RCPDatePicker("");
        datePicker.setState(EControlState.MANDATORY, true);
        RCPSimpleLabel simpleLabel = new RCPSimpleLabel("DatePicker (Composite): ");
        widgetBuilder.add(simpleLabel);
        gd = new GridData();
        gd.horizontalAlignment = SWT.END;
        simpleLabel.setLayoutData(gd);
        GridBuilder datePickerBuilder = widgetBuilder.addAlignedContainer(pickerComposite, 2, 3);
        datePickerBuilder.add(datePicker);
        
        widgetBuilder.addLine(m_birthDateText, 8);
        widgetBuilder.addSkipLeftLine(m_singleLineText, 1);
        widgetBuilder.addLine(m_kontoueberzugCheck);
        widgetBuilder.addLine(m_kontoueberzugCheckLabel);
        
        // create one radio button for each code and associate a radio group manager
        widgetBuilder.addLine(m_geschlechtCombo);

    }

    public void bind(ValidationManager context, Object dataModel)
    {
        context.bindValue(m_multiLineText, dataModel, SimpleBean.P_TEXT);
        //MethodValidator validator = new AsymmetricMultilineValidator(SimpleBean.P_TEXT, new int[]{1,2,3});
        MethodValidator validator = new SymmetricMultilineValidator(SimpleBean.P_TEXT, 3, 35);
        context.addValidator(this, validator); 
    }

    @Override
    public void setState(EControlState state, boolean value)
    {
        mainSection.setState(state, value);

    }
    
    public void expandPart(boolean doExpand)
    {
        this.mainSection.getSWTSection().setExpanded(doExpand);
    }

    public static void main(String[] args)
    {

        final JavaBean model = new SimpleBean();
        final RCPFormPart part = new SandboxLayoutFormPart();
        RCPFormFactory.getInstance().startTestShell("SandboxLayoutFormPart", part, model);
    }
    
}

class RCPLabeledCheckButton extends RCPLabeledControl<RCPSimpleButton>
{
    public RCPLabeledCheckButton(String label)
    {
        this(label, SWT.CHECK);
    }

    public RCPLabeledCheckButton(String label, int style)
    {
        super(label, new RCPSimpleButton("", style | SWT.CHECK));
    }

    public final Button getSWTButton()
    {
        return getRCPControl().getSWTButton();
    }

}
