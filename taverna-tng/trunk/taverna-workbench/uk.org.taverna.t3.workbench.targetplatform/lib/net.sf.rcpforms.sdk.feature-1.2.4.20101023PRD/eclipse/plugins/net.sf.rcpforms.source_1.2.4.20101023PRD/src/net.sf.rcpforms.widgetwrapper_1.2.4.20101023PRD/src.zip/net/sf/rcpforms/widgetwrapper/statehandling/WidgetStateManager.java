/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.widgetwrapper.statehandling;

import java.lang.reflect.Field;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.widgetwrapper.util.WidgetUtil;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;

import org.eclipse.jface.fieldassist.ControlDecoration;
import org.eclipse.jface.fieldassist.FieldDecoration;
import org.eclipse.jface.fieldassist.FieldDecorationRegistry;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CCombo;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.RGB;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.forms.FormColors;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;

/**
 * RCPControls delegate state rendering and state control (e.g. mandatory, readonly..) to this class.
 * State managing can be customized by installing a subclass of this state manager for a specific widget class;
 * all subclasses of this widget class use the same state manager. Currently specific state
 * managers are registered for RCPControl and RCPSection, all others are inherited.
 * <p>
 * TODO: refactor state rendering to use formtoolkit and keys for colors etc.<BR>
 * -> see tracker 152103
 * 
 * @author Marco van Meegen
 * @author Remo Loetscher
 */
public class WidgetStateManager implements IWidgetStateController
{
    
    private static IWidgetStateController controller = null;
    
    private static final Logger LOG = Logger.getLogger(WidgetStateManager.class.getName());
    
    private static Map<String, Color> colorMap = new HashMap<String, Color>();

    private static Map<Class<? extends RCPControl>, WidgetStateManager> instanceMap;
    
    protected static final String READONLY_MARKER = "net.sf.rcpforms.widgetwrapper.readonly"; //$NON-NLS-1$

    protected PaintListener m_readonlyBorderPaintListener;

    public static final RGB standardRGB_BG = new RGB(255, 255, 255);

    public static final RGB requiredRGB_BG = new RGB(255, 255, 225);

    public static final RGB disabledRGB_BG = new RGB(240, 240, 240);
    
    private boolean isLayoutUpdateEnabled = true;
    
    private Color widgetBackground;

    private static Field s_fldListener;

    private static Field s_fldTxt;

    private static Field s_fldArrow;

    private static boolean s_bCComboFieldsFound;
    
    private FormColors formColors;
    
    static
    {
        instanceMap = new HashMap<Class<? extends RCPControl>, WidgetStateManager>();
        instanceMap.put(RCPControl.class, new WidgetStateManager());
        instanceMap.put(RCPSection.class, new WidgetStateManager()
        {
            @Override
            protected void setStateBackground(RCPControl section)
            {
                // ignore state backgrounds on a section
            }

        });
    }
    static
    {
        // Mega haessliches Hack, damit wir die Children einer CCombo zugreifen k�nnen.
        // Kann unter Umst�nde Probleme machen wenn SWT die Implementierung von CCombo �ndert.
        try
        {
            Field[] fields = CCombo.class.getDeclaredFields();
            for (Field f : fields)
            {
                if ("listener".equals(f.getName())) { //$NON-NLS-1$
                    s_fldListener = f;
                    s_fldListener.setAccessible(true);
                }
                if ("text".equals(f.getName())) { //$NON-NLS-1$
                    s_fldTxt = f;
                    s_fldTxt.setAccessible(true);
                }
                if ("arrow".equals(f.getName())) { //$NON-NLS-1$
                    s_fldArrow = f;
                    s_fldArrow.setAccessible(true);
                }

                if (null != s_fldListener && null != s_fldTxt && null != s_fldArrow)
                {
                    s_bCComboFieldsFound = true;
                    break;
                }
            }

        }
        catch (Exception e)
        {
            s_bCComboFieldsFound = false;
            LOG
                    .severe("The Fields listener, text or arrow of the class CCombo could not be accessed! Probably the internal implementation of the SWT CCombo changed!"); //$NON-NLS-1$
        }

    }
    
    public WidgetStateManager()
    {
        this.formColors = new FormColors(Display.getCurrent());
        widgetBackground = Display.getCurrent().getSystemColor(SWT.COLOR_WIDGET_BACKGROUND);
    }

    /**
     * @return the system wide default state renderer to use for the given control class. If no
     *         renderer is registered for this class, the next superclass is tested until one is
     *         found; this StateManager is registered for RCPControl, thus always one is found.
     */
    public static WidgetStateManager getInstance(Class<? extends RCPControl> controlClass)
    {
        Class<?> currentClass = controlClass;
        while (currentClass != null && !instanceMap.containsKey(currentClass))
        {
            currentClass = currentClass.getSuperclass();
        }
        WidgetStateManager result = instanceMap.get(currentClass);
        Validate.notNull(result,
                "Internal Error: No State Renderer is registered for the class or any superclass of " //$NON-NLS-1$
                        + controlClass.getName());
        return result;
    }

    /**
     * registers a new state manager for the given control class and all superclasses.
     * 
     * @param controlClass control class to register state renderer for
     * @param manager state manager to use, maybe null in which case only a renderer entry is removed if
     *            existing
     * @return old state manager or null if none was directly registered for this class
     */
    public static WidgetStateManager registerWidgetStateManager(Class<? extends RCPControl> controlClass,
                                                      WidgetStateManager manager)
    {
        WidgetStateManager old;
        if (manager != null)
        {
            old = instanceMap.put(controlClass, manager);
        }
        else
        {
            old = instanceMap.remove(controlClass);
        }
        return old;
    }
    
    /**
     * @return unmodifiable collection with all registered rcpcontrol objects.
     */
    public static Set<Class<? extends RCPControl>> getRegisteredWidgetStateManager()
    {
        return Collections.unmodifiableSet(instanceMap.keySet());
    }

    /**
     * create a control decoration with the clipping parent got mainly right. This does not work in
     * all cases, see bug https://bugs.eclipse.org/bugs/show_bug.cgi?id=172294
     * 
     * @param position decoration position e.g. SWT.LEFT|SWT.TOP
     * @return control decoration
     */
    protected ControlDecoration createControlDecoration(Control swtControl, int position)
    {
        Control parent = swtControl;
        // walk up parent chain to find a scrolled form
        while (parent != null && !(parent instanceof ScrolledForm))
        {
            parent = parent.getParent();
        }
        Composite clippingParent = null;
        if (parent instanceof ScrolledForm)
        {
            clippingParent = ((ScrolledForm) parent).getBody();
        }

        ControlDecoration result = new ControlDecoration(swtControl, position, clippingParent);
        return result;
    }

    /**
     * 
     * @param control
     * @param oDecoPos
     * @return
     * @deprecated use {@link #initDeco(Control, String, int)} instead
     * 
     */
    protected ControlDecoration initOtherDeco(Control control, int oDecoPos)
    {
        return this.initDeco(control, FieldDecorationRegistry.DEC_CONTENT_PROPOSAL, oDecoPos);
    }
    

    /**
     * creates a defined control decoration for the given swt widget at the speciefied position 
     * @param swtControl swt control do decorate
     * @param decContentProposal constant for decoration type. see {@link FieldDecorationRegistry} for types
     * @param decoPos position of the decoration
     * @return new created control decoration
     */
    protected ControlDecoration initDeco(Control swtControl, String decContentProposal, int decoPos)
    {
        FieldDecoration deco = FieldDecorationRegistry.getDefault().getFieldDecoration(decContentProposal);
        ControlDecoration result = createControlDecoration(swtControl, decoPos);
        result.setDescriptionText(null);
        result.setMarginWidth(5);
        result.setShowOnlyOnFocus(false);
        result.setImage(deco.getImage());
        result.show();
        return result;
    }
    
    
    /**
     * Allows to set a widgetStateController that is asked to correct the state of
     * widgets when their state is altered via 
     * {@link RCPControl#setState(EControlState, boolean)}.
     * 
     * @param newController the new controller
     */
    public static void setWidgetStateController(IWidgetStateController newController) {
        controller = newController;
    }
    
    public static IWidgetStateController getWidgetStateController() {
        return controller;
    }
    
    public final int reviewState(RCPControl rcpControl, int state)
    {
        //let controller check and manipulate state
        if(WidgetStateManager.getWidgetStateController() != null)
        {
            return WidgetStateManager.getWidgetStateController().reviewState(rcpControl, state);
        }else
        {
            return state;
        }
    }

    public void updateState(RCPControl rcpControl, int state)
    {
        Validate.notNull(rcpControl);
        if (WidgetUtil.isValid(rcpControl))
        {
//            Control swtControl = rcpControl.getTypedWidget();
            //performance optimization: only calculate value once and reuse it
            boolean isVisible = rcpControl.getState(EControlState.VISIBLE);
            boolean isReadonly = rcpControl.getState(EControlState.READONLY);
            boolean isChainEnabled = rcpControl.isChainEnabled();
            boolean isMandatory = rcpControl.getState(EControlState.MANDATORY);
            boolean isInfo = rcpControl.getState(EControlState.INFO);
            
            //set all the states
            setVisibleState(rcpControl, isVisible);
            setReadOnlyState(rcpControl, isReadonly);
            setEnabledState(rcpControl, isChainEnabled);
            setRequiredState(rcpControl, isMandatory, isReadonly, isChainEnabled);
            setOtherState(rcpControl);
            setInfoState(rcpControl, isInfo);
            
            setCrustomStates(rcpControl);
            
            setStateBackground(rcpControl);
        }
    }

    /**
     * Allows to handle custom states defined in {@link EControlState} enumeration
     * @param rcpControl
     */
    protected void setCrustomStates(RCPControl rcpControl)
    {
        // TODO Auto-generated method stub
        
    }

    /**
     * Not yet implemented -> empty body! Users may want to overwrite this method
     * @param rcpControl
     * @param isInfo
     */
    protected void setInfoState(RCPControl rcpControl, boolean isInfo)
    {
        Control swtControl = rcpControl.getTypedWidget();
        if (isInfo && rcpControl.isChainVisible())
        {
            // configure other state.
            if (rcpControl.informationDecoration == null)
            {
                rcpControl.informationDecoration = initDeco(swtControl, FieldDecorationRegistry.DEC_INFORMATION, SWT.RIGHT | SWT.CENTER);
            }

        }
        else if (!isInfo
                && rcpControl.informationDecoration != null)
        {
            // hide other decoration
            rcpControl.informationDecoration.hide();
            rcpControl.informationDecoration.dispose();
            rcpControl.informationDecoration = null;
        }
    }

    protected void setOtherState(RCPControl rcpControl)
    {
        Control swtControl = rcpControl.getTypedWidget();
        if (rcpControl.hasState(EControlState.OTHER) && rcpControl.isChainVisible())
        {
            // configure other state.
            if (rcpControl.otherDecoration == null)
                rcpControl.otherDecoration = initDeco(swtControl, FieldDecorationRegistry.DEC_CONTENT_PROPOSAL, SWT.LEFT | SWT.CENTER);

        }
        else if (!rcpControl.hasState(EControlState.OTHER)
                && rcpControl.otherDecoration != null)
        {
            // hide other decoration
            rcpControl.otherDecoration.hide();
            rcpControl.otherDecoration.dispose();
            rcpControl.otherDecoration = null;
        }
    }

    protected void setRequiredState(RCPControl rcpControl, boolean isMandatory, boolean isReadonly, boolean isChainEnabled)
    {
        Control swtControl = rcpControl.getTypedWidget();
        if (isChainEnabled && isMandatory
                && !isReadonly
                && rcpControl.requiredDecoration == null)
        {
            // show required decoration
            rcpControl.requiredDecoration = initDeco(swtControl, FieldDecorationRegistry.DEC_REQUIRED, SWT.LEFT | SWT.TOP);
            
//            rcpControl.requiredDecoration = createControlDecoration(swtControl, SWT.LEFT
//                    | SWT.TOP);
//            rcpControl.requiredDecoration.setImage(FieldDecorationRegistry.getDefault()
//                    .getFieldDecoration(FieldDecorationRegistry.DEC_REQUIRED).getImage());
        }
        else if ((!isChainEnabled || !isMandatory || isReadonly)
                && rcpControl.requiredDecoration != null)
        {
            // hide required decoration
            rcpControl.requiredDecoration.hide();
            rcpControl.requiredDecoration.dispose();
            rcpControl.requiredDecoration = null;
        }
        
    }

    protected void setEnabledState(RCPControl rcpControl, boolean isChainEnabled)
    {
        Control swtControl = rcpControl.getTypedWidget();
        swtControl.setEnabled(isChainEnabled);
    }

    protected void setReadOnlyState(RCPControl rcpControl, boolean isReadonly)
    {
        // important ! some controls e.g. button render readonly the same as disabled !
        this.setReadonly(rcpControl,
                isReadonly);
    }

    protected void setVisibleState(RCPControl rcpControl, boolean isVisible)
    {
        Control swtControl = rcpControl.getTypedWidget();
        boolean cachedVisibility = swtControl.isVisible();
        swtControl.setVisible(isVisible);
        // set exclude flag in any case. reason: possible inconsistency if
        // swtControl.setVisible(true) but parent control is invisible. swtControl.isVisible will
        // return false and condition "cachedVisibility != swtControl.isVisible()" will therefore
        // result in false!
        if (!rcpControl.isKeepSpaceIfInvisible()
                && swtControl.getLayoutData() instanceof GridData)
        {
            // exclude/included in layout
            GridData data = (GridData) swtControl.getLayoutData();
            data.exclude = !isVisible;
//            swtControl.setLayoutData(data);
        }
        
        //if visibility has changed let the control reflow the form to update layout
        if(cachedVisibility != swtControl.isVisible())
        {
                //only do time consuming update if layout should be updated
                if(isLayoutUpdateEnabled)
                    rcpControl.reflowForm();
        }
    }

    /**
     * @return flag if update should be performed for state changes which has an effect on the layout (like visibility).
     */
    public boolean isLayoutUpdateEnabled()
    {
        return isLayoutUpdateEnabled;
    }

    /**
     * Flag for performance optimizations. If this flag is set to false changes to widget states
     * which can affect the (form) layout will not cause a forced relayouting of the form. instead a
     * call {@link ScrolledForm#reflow(boolean)} by yourself is suggested. if its true (default) the
     * form will be relayouted anytime a statechange needs layout updates.
     * 
     * @param isLayoutUpdateEnabled
     */
    public void setIsLayoutUpdateEnabled(boolean isLayoutUpdateEnabled)
    {
        this.isLayoutUpdateEnabled = isLayoutUpdateEnabled;
    }

    /**
     * sets the background defined by the widget state; subclasses may override to not use state
     * background colors
     */
    protected void setStateBackground(RCPControl rcpControl)
    {
        Color color = null;
        if (rcpControl.isChainEnabled())
        {
            if ((rcpControl.getState(EControlState.RECOMMENDED) || rcpControl
                    .getState(EControlState.MANDATORY))
                    && !rcpControl.getState(EControlState.READONLY))
            {
                color = getColor(requiredRGB_BG);
            }
            else
            {
                // set parent background
                color = rcpControl.getSWTParent().getBackground();
            }
        }
        else
        {
            color = widgetBackground;
        }
        if (color != null)
        {
            rcpControl.getSWTControl().setBackground(color);
        }
    }

    /**
     * get color with given rgb value, create if not existing
     * 
     * @param descriptor rgb values needed
     * @return color, cached or newly created; do not dispose !
     */
    public static Color getColor(RGB descriptor)
    {
        // TODO: delegate to form colors and color key
        String key = descriptor.toString();
        if (!colorMap.containsKey(key))
        {
            Color color = new Color(Display.getCurrent(), descriptor);
            colorMap.put(key, color);
        }
        return colorMap.get(key);
    }
    
    /**
     * set the readonly style for the control if this is supported. Controls not supporting the
     * readonly style are set en/disabled.
     * 
     * @param control control to apply style to
     * @param readonly readonly style
     */
    public void setReadonly(final RCPControl rcpControl, final boolean readonly)
    {
        setReadonly(rcpControl.getSWTControl(), readonly);
    }
    
    /**
     * set the readonly style for the control if this is supported. Controls not supporting the
     * readonly style are set en/disabled.
     * 
     * @param control control to apply style to
     * @param readonly readonly style
     */
    public void setReadonly(final Control control, final boolean readonly)
    {
        // the readonly style means the control is only for display, the user cannot change the
        // control value.
        // Opposed to disabled, the user can still copy the displayed text to the clipboard.
        // most widgets do not support readonly style
        if (control instanceof CCombo)
        {
            setReadonly((CCombo) control, readonly);
        }
        else if (control instanceof Text)
        {
            setReadonly((Text) control, readonly);
        }else
        {
            control.setEnabled(!readonly);
        }
    }
    
    protected void setReadonly(final CCombo combo, final boolean readonly)
    {
        if (WidgetUtil.isValid(combo))
        {
            if (s_bCComboFieldsFound)
            {
                // Die Felder aus der Klasse CCombo konnten erfolgreich geholt werden
                combo.setData(FormToolkit.KEY_DRAW_BORDER, !readonly);
                combo.setData(READONLY_MARKER, readonly); // mark control
                combo.setEditable(!readonly);

                // Mega haessliches Hack, damit wir die Children einer CCombo zugreifen k�nnen.
                // Kann unter Umst�nde Probleme machen wenn SWT die Implementierung von CCombo
                // �ndert.
                // H�ngt alle Listener vom internen Text ab.
                // Nimmt den internen Pfeil weg.
                try
                {
                    Listener listener = (Listener) s_fldListener.get(combo);

                    Text text = (Text) s_fldTxt.get(combo);
                    int[] textEvents = {SWT.KeyDown, SWT.KeyUp, SWT.MenuDetect, SWT.Modify,
                            SWT.MouseDown, SWT.MouseUp, SWT.MouseWheel, SWT.Traverse, SWT.FocusIn, SWT.Verify};

                    if (readonly)
                    {
                        for (int i = 0; i < textEvents.length; i++)
                            text.removeListener(textEvents[i], listener);
                    }
                    // Wenn wieder editable, kein addListener() n�tig!
                    // Listener wurden bereits wieder angeh�ngt!

                    Button btn = (Button) s_fldArrow.get(combo);
                    btn.setVisible(!readonly);

                    final String painterAddedKey = "painterAddedKey"; //$NON-NLS-1$
                    final Composite pComp = combo.getParent();
                    if (readonly && null == pComp.getData(painterAddedKey))
                    {
                        pComp.setData(painterAddedKey, Boolean.TRUE);
                        pComp.addPaintListener(getReadonlyBorderPaintListener());
                    }
                }
                catch (Exception e)
                {
                    combo.setEnabled(!readonly);
                    LOG
                            .severe("The Fields listener, text or arrow of the class CCombo could not be accessed! Probably the internal implementation of the SWT CCombo changed!"); //$NON-NLS-1$
                }
                redrawBorderRect(combo);

            }
            else
            {
                combo.setEnabled(!readonly);
            }
        }
    }

    protected void setReadonly(final Text text, final boolean readonly)
    {
        if (WidgetUtil.isValid(text))
        {
            text.setData(FormToolkit.KEY_DRAW_BORDER, !readonly);
            text.setData(READONLY_MARKER, readonly); // mark control

            text.setEditable(!readonly);

            final String painterAddedKey = "painterAddedKey"; //$NON-NLS-1$
            final Composite pComp = text.getParent();
            if (readonly && null == pComp.getData(painterAddedKey))
            {
                pComp.setData(painterAddedKey, Boolean.TRUE);
                pComp.addPaintListener(getReadonlyBorderPaintListener());
            }
            text.redraw();
        }
    }
    
    /**
     * @param control control to check
     * @return true if the control is marked as read-only, used to draw read-only border
     */
    private static boolean isReadonly(final Control control)
    {
        return control.getData(READONLY_MARKER) != null
                && ((Boolean) control.getData(READONLY_MARKER)).booleanValue();
    }

    protected PaintListener getReadonlyBorderPaintListener()
    {
        if (m_readonlyBorderPaintListener == null)
        {
            m_readonlyBorderPaintListener = new PaintListener()
            {
                public void paintControl(PaintEvent event)
                {
                    Composite composite = (Composite) event.widget;
                    Control[] children = composite.getChildren();
                    GC gc = event.gc;
                    gc.setForeground(getReadonlyTextBorderColor());

                    for (int i = 0; i < children.length; i++)
                    {
                        Control c = children[i];
                        // check control's mark
                        if (c.isVisible() && isReadonly(c))
                        {
                            final Rectangle b = c.getBounds();
                            int x1 = b.x - 1;
                            int x2 = b.x + b.width;
                            int by = b.y + b.height;
                            gc.drawLine(x1, by, x2, by);
                            gc.drawLine(x1, by - 1, x1, by);
                            gc.drawLine(x2, by, x2, by - 1);
                        }
                    }
                }
            };
        }
        return m_readonlyBorderPaintListener;
    }

    protected Color getReadonlyTextBorderColor()
    {
        final String colorKey = "COLOR_NONEDITABLE_BORDER"; //$NON-NLS-1$

        Color borderColor = formColors.getColor(colorKey);
        if (null == borderColor)
        {
            Color origBorderColor = formColors.getBorderColor();
            int r = brighter(origBorderColor.getRed(), 2, 3);
            int g = brighter(origBorderColor.getGreen(), 2, 3);
            int b = brighter(origBorderColor.getBlue(), 2, 3);
            borderColor = formColors.createColor(colorKey, r, g, b);
        }
        return borderColor;
    }
    
    protected int brighter(final int color, final int x, final int y)
    {
        Validate.isTrue(color <= 255);
        return (255 - color) * x / y + color;
    }
    

    /**
     * marks the area of the control parent which contains the border as dirty
     * 
     * @param control control for which borders should be redrawn
     */
    protected void redrawBorderRect(CCombo combo)
    {
        Rectangle rect = combo.getParent().getBounds();
        combo.getParent().redraw(rect.x - 1, rect.y - 2, rect.width + 1, rect.height + 3, false);
    }
}
