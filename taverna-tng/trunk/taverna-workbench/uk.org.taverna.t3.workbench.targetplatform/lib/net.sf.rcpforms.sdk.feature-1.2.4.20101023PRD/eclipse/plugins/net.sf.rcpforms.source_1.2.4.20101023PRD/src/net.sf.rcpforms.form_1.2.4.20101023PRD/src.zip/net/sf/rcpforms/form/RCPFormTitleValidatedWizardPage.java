
package net.sf.rcpforms.form;

import net.sf.rcpforms.bindingvalidation.ValidationManager;

import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.ValidationStatusProvider;
import org.eclipse.core.databinding.observable.list.IObservableList;
import org.eclipse.core.databinding.observable.list.WritableList;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.core.databinding.observable.value.WritableValue;
import org.eclipse.core.internal.databinding.observable.UnmodifiableObservableList;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.jface.databinding.wizard.WizardPageSupport;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.widgets.Composite;

/**
 * Wrapper to use an RCPForm in a wizard as wizard page. The validation state of the form is used to
 * indicate when the page is complete.
 * Validationstate of the Form is presented in Wizard header
 * NOTE: PROVISIONAL API! DO NOT USE THIS.
 * 
 * @author Remo Loetscher
 */
public class RCPFormTitleValidatedWizardPage extends RCPFormWizardPage implements IMessageDisplay
{
    public RCPFormTitleValidatedWizardPage(String pageId, RCPForm form)
    {
        super(pageId, form);
    }
    
    

    public RCPFormTitleValidatedWizardPage(String pageId, RCPForm form,
                                            ImageDescriptor imageDescriptor)
    {
        super(pageId, form, imageDescriptor);
    }



    /**
     * Create contents of the wizard
     * 
     * @param pageContainer
     */
    public void createControl(Composite pageContainer)
    {
        super.createControl(pageContainer);
        final ValidationManager validationManager = super.getForm().getValidationManager();
        if(validationManager != null){
            //init validationmanager manually to get binding Context
            validationManager.initialize(super.getForm().getMessageManager());
            DataBindingContext dbc = validationManager.getBindingContext();  
            dbc.addValidationStatusProvider(new ValidationStatusProvider(){
                final IObservableList emptyList = new WritableList();

                @Override
                public IObservableList getModels()
                {
                    return emptyList;
                }

                @Override
                public IObservableList getTargets()
                {   
                    return emptyList;
                }

                @Override
                public IObservableValue getValidationStatus()
                {
                    IObservableValue validationState = validationManager.getValidationState();
                    if(validationState.getValue() instanceof MultiStatus)
                    {
                        MultiStatus mState = (MultiStatus)validationState.getValue();
                        for(IStatus state : mState.getChildren())
                        {
                            if(mState.getSeverity() == state.getSeverity())
                            {
                                WritableValue wv = new WritableValue();
                                wv.setValue(state);
                                return wv;
                            }
                        }
                    }
                    return validationState;
                }});
            WizardPageSupport.create(this, dbc);
        }
    }
}
