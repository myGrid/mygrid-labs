/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.form;

import java.util.logging.Logger;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.widgetwrapper.builder.ColumnLayoutFactory;
import net.sf.rcpforms.widgetwrapper.util.WidgetUtil;

import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.forms.IFormColors;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.IMessage;
import org.eclipse.ui.forms.IMessageManager;
import org.eclipse.ui.forms.ManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;
import org.eclipse.ui.internal.forms.MessageManager;
import org.eclipse.ui.internal.forms.widgets.FormHeading;

/**
 * /** The main form concept of rcpforms. An RCPForm is composed of a Header which displays error
 * markers and heading of the whole form, as well as one or more RCPFormPart
 * <p>
 * A most simple form contains one RCPFormPart as a view and an arbitrary object which represents
 * the presentation model.
 * <p>
 * TODO LATER: explain concept more clearly with integration into existing Eclipse concepts like
 * IManagedForm, FormDialog, ViewPart, Wizard, MultipageEditor<BR>
 * TODO LATER: implement the form and integration layer
 * <p>
 * 
 * @author Marco van Meegen, Remo Loetscher
 */
public class RCPForm
{

    private static final Logger LOG = Logger.getLogger(RCPForm.class.getName());

    /**
     * validation manager used by this form, spans all form part to enable part-spanning validations
     */
    private ValidationManager validationManager = null;

    /**
     * managed form which contains and manages the ScrolledForm swt control
     */
    private ManagedForm managedForm;

    /**
     * form parts passed in constructor
     */
    private RCPFormPart[] formParts;

    /**
     * title passed in constructor
     */
    private String title;

    /**
     * form tempInput, intermediately saved to allow flexible call order of createUI and setInput()
     */
    private Object tempInput = null;

    private boolean isFormCreated = false;
    
    /**
     * Constructor for a RCPForm with the given formParts using a custom validation manager
     * subclass, no ui is created and no binding done yet
     * 
     * @param title title, maybe null if no title area is needed
     * @param validationManager validation manager to use, maybe null. If a validationManager is passed (not null) the binding resources are NOT disposed automatically using {@link ValidationManager#dispose()}.
     * @param formParts formParts to create, they will be created in the order as lined out
     */
    public RCPForm(String title, ValidationManager validationManager, RCPFormPart... parts)
    {
        Validate.noNullElements(parts);
        this.title = title;
        this.formParts = parts;
        this.validationManager = validationManager;
    }

    /**
     * Constructor for a RCPForm with the given formParts, no ui is created and no binding done yet
     * 
     * @param title title, maybe null if no title area is needed
     * @param formParts formParts to create, they will be created in the order as lined out
     */
    public RCPForm(String title, RCPFormPart... parts)
    {
        this(title, null, parts);
    }
    
    /**
     * Constructor for a RCPForm with the given formParts, no ui is created and no binding done yet
     * 
     * @param title title, maybe null if no title area is needed
     * @param formParts formParts to create, they will be created in the order as lined out
     */
    public RCPForm(String title)
    {
        this(title, null, (RCPFormPart[])null);
    }
    
    /**
     * Constructor for RCPForm using a separate toolkit and form
     * 
     * @param toolkit toolkit to use
     * @param form form to use
     * @deprecated Use {@link RCPForm#RCPForm(String, RCPFormPart...)} of {@link RCPForm}{@link #RCPForm(String, ValidationManager, RCPFormPart...)} instead
     */
    public RCPForm(FormToolkit toolkit, ScrolledForm form)
    {
        managedForm = new ManagedForm(toolkit, form);
//        validationManager = RCPFormFactory.getInstance().createBindingAndValidationManager(
//                "BindingManager:" + this.getClass().getName()); //$NON-NLS-1$
    }
    
    /**
     * @return Returns the title. If no title is set, returns null.
     */
    public String getTitle()
    {
        return title;
    }

    /**
     * creates and fully initializes the form.
     * <p>
     * This implies:
     * <ul>
     * <li>create a Validation Manager shared for all bindings in the form parts
     * <li>create the managed form and its {@link ScrolledForm} widget including
     * {@link MessageManager}, {@link FormHeading} to display errors
     * <li>
     * 
     * @param parent parent to create form in
     */
    public void createUI(Composite parent)
    {
        Validate
                .notNull(
                        Realm.getDefault(),
                        "Make sure a Databinding Realm is set; you should wrap your main method into Realm.runWithDefault() to provide one"); //$NON-NLS-1$
        Validate.notNull(parent);
        Validate.notNull(formParts, "No formpats are set. Please make sure that formparts ara set befor creation the ui!");
        WidgetUtil.ensureValid(parent);
        isFormCreated = true;
        try
        {
            boolean useOwnValidationManager = validationManager == null;
            // create the validation manager to use
            if (useOwnValidationManager)
            {
                // if no manager was passed in constructor, create default one
                validationManager = RCPFormFactory.getInstance().createBindingAndValidationManager(
                        title);
            }

            // create the scrolled form swt control and a managed form
            // maintaining it
            // each form part is created too
            FormToolkit toolkit = this.createFormToolkit();
            //check if already a managed form was passed using the constructor RCPForms(Toolkit, ScrolledForm)
            if(managedForm == null)
                managedForm = createManagedForm(parent, title, toolkit);
            else if(title != null)
            {
                Validate.notNull(managedForm.getForm(), "ManagedForm has no form!");
                managedForm.getForm().setText(title);
            }

            // disable validation -> prevent flickering during ui and binding
            // creation
            validationManager.enableValidation(false);
            // init form body layout; default is column layout
            initBodyLayout();
            for (int i = 0; i < formParts.length; i++)
            {
                formParts[i].createUI(toolkit, managedForm.getForm().getBody());
            }

            // if tempInput was already set, use it and bind
            if (tempInput != null)
            {
                setInput(tempInput);
            }
            // add dispose listener to form if the validation manager was created by the rcpform
            if(useOwnValidationManager)
            {
                
                this.managedForm.getForm().addDisposeListener(new DisposeListener(){

                    public void widgetDisposed(DisposeEvent e)
                    {
                        if(validationManager != null)
                            validationManager.dispose();
                        
                    }});
            }
            initializeUI();

        }
        catch (RuntimeException ex)
        {
            LOG.severe("Exception in createUI: " + ex.getLocalizedMessage()); //$NON-NLS-1$
            ex.printStackTrace();
            throw ex;

        }
        finally
        {
            // enable validation
            validationManager.enableValidation(true);
        }
        // force relayout if something has changed during validation
        reflow(true);
    }

    /**
     * @return the ScrolledForm widget representing the form
     */
    public ScrolledForm getScrolledForm()
    {
        Validate.notNull(managedForm, "getScrolledForm() must be called after createUI()"); //$NON-NLS-1$
        return managedForm.getForm();
    }

    /**
     * @return the binding and validation manager used by this form. This is needed to check the
     *         form validation state, add new validators or create bindings directly instead through
     *         form formParts.
     */
    public ValidationManager getValidationManager()
    {
        return validationManager;
    }

    /**
     * Returns a FormToolkit for creation of the formparts.
     * if clients overwrite these methods pay attention to resource handling and memory leaks. Disposing the FormToolkit has to be done manually.
     * Best practise is to cache and reuse one FormToolkit for severals RCPForms.
     * @return FormToolkit
     */
    protected FormToolkit createFormToolkit()
    {
        return RCPFormFactory.getInstance().getToolkit(Display.getCurrent());
    }
    
    /**
     * creates the managed form including the scrolled form and form header
     * 
     * @param parent parent to create form in
     * @param title title
     * @param toolkit toolkit to use
     * @return the managed form
     */
    protected ManagedForm createManagedForm(Composite parent, String title, FormToolkit toolkit)
    {
        ManagedForm managedForm = null;
        ScrolledForm form = new ScrolledForm(parent, SWT.V_SCROLL | SWT.H_SCROLL
                | Window.getDefaultOrientation())
        {
            // HACK to avoid loading of images which needs osgi
            // runtime in Eclipse 3.1, so this can be used with swt too.
            // in 3.4 this bug was fixed
            @Override
            public void setMessage(String newMessage, int newType, IMessage[] messages)
            {
                try
                {
                    super.setMessage(newMessage, newType, messages);
                }
                catch (RuntimeException ex)
                {
                    // if this does not work, set message without image
                    super.setMessage(newMessage, 0, messages);
                }
                catch (NoClassDefFoundError ex)
                {
                    // using 3.3 libraries "standalone" a NoClassDefFoundError
                    // could be thrown
                    super.setMessage(newMessage, 0, messages);
                }
                catch (ExceptionInInitializerError eiie)
                {
                    // using 3.3 libraries "standalone" an
                    // ExceptionInInitializeError could be thrown
                    super.setMessage(newMessage, 0, messages);
                }
            }
        };

        managedForm = new ManagedForm(toolkit, form);
        toolkit.decorateFormHeading(form.getForm());
        form.setExpandHorizontal(true);
        form.setExpandVertical(true);
        form.setBackground(toolkit.getColors().getBackground());
        form.setForeground(toolkit.getColors().getColor(IFormColors.TITLE));
        form.setFont(JFaceResources.getHeaderFont());
        if (title != null)
        {
            form.setText(title);
        }
        return managedForm;
    }

    /**
     * sets the layout for the form body. Default implementation sets a ColumnLayout.
     */
    protected void initBodyLayout()
    {
        // Sets the Layout to the form body which is also the parent to the
        // sections

        managedForm.getForm().getBody().setLayout(ColumnLayoutFactory.createFormLayout());
    }

    /**
     * sets the given data model as datamodel for the form and binds all view models against it.
     * Initializes the viewmodel manager if input is not null
     * <p>
     * @param input an array of data models; -> see tracker 152079. if input is null -> no binding to formparts will be done
     * LATER: extend to hierarchical models ? 
     */
    public void setInput(Object input)
    {
        try
        {
            Validate.isTrue(input == null || input.getClass().isArray(),
                    "Your Input must be null or an array with the same length as form formParts"); //$NON-NLS-1$
            Object[] inputArray = (Object[]) input;
            if (input != null)
            {
                //only set input if managed form is available
                if (managedForm != null)
                {
                    Validate.isTrue(inputArray.length == formParts.length,
                        "Input array must have same length as form part array"); //$NON-NLS-1$
                    Validate.noNullElements(inputArray, "No null Input elements allowed"); //$NON-NLS-1$
                    managedForm.setInput(input);
                    bind(inputArray);
                }
                else
                {
                    // save until createUI was called
                    this.tempInput = input;
                }
            }else{
                LOG.warning("Input was <null> -> therefore input was not set and there is nothing to bind!");
            }
            
        }
        catch (RuntimeException ex)
        {
            ex.printStackTrace();
            throw ex;
        }
    }

    /**
     * initializeUI is called after ui has been created, this happens only once in the form life
     * cycle.
     * <p>
     * Listeners to widgets, binding to form-internal extra data, part spanning validators should be
     * registered here.
     * <p>
     * For input-dependent data use {@link #initialize()}.
     */
    public void initializeUI()
    {

    }

    /**
     * initialize is called after an input has been set and bound. input dependent
     * information/listeners should be initialized here
     */
    public void initialize()
    {

    }

    /**
     * check if no data binding error exist and all validation rules are ok. Error markers and the
     * observable validation status are updated as side effect.
     * 
     * @return status of the validation; status.isOk() is true if the form does not contain any
     *         validation errors, otherwise a status or multistatus containing the errors is
     *         returned.
     */
    public IStatus validateForm()
    {
        return validationManager.revalidate();
    }

    /**
     * returns the validation state of the view model managed by this. The IObservableValue type is
     * IStatus and is automatically updated if the validation state changes.
     * 
     * @return IObservableValue of type IStatus or null if no status if available
     */
    public IObservableValue getObservableValidationStatus()
    {
        return validationManager != null ? validationManager.getValidationState() : null;
    }

    /**
     * override in subclass to define the control which gets the focus when entering the form
     */
    public void setFocus()
    {
        // do nothing here
    }

    /**
     * binds the form parts against the models. calls {@link #initialize()} after everything is bound
     * 
     * @param models models to bind against
     */
    protected void bind(Object[] models)
    {
        Validate.noNullElements(models, "Models must not be null"); //$NON-NLS-1$
        Validate.isTrue(formParts.length == models.length);
        ValidationManager vm = validationManager;
        if(!vm.isInitialized())
            vm.initialize(managedForm.getMessageManager());
        vm.enableValidation(false);
        try{
            for (int i = 0; i < formParts.length; i++)
            {
                vm.bindPart(formParts[i], models[i]);
            }
        }finally
        {
            vm.enableValidation(true);
        }
        initialize();
    }

    /**
     * @see org.eclipse.ui.forms.IManagedForm#reflow(boolean)
     */
    public void reflow(boolean changed)
    {
        managedForm.reflow(changed);
    }

    /**
     * retrieve the form part with the given index
     * 
     * @param index 0-based part index
     * @return part
     */
    public RCPFormPart getPart(int index)
    {
        Validate.isTrue(index >= 0 && index < formParts.length, "Invalid part index: " + index //$NON-NLS-1$
                + ", only " + formParts.length + " parts registered"); //$NON-NLS-1$ //$NON-NLS-2$
        return formParts[index];
    }
    
    /**
     * @return number of registered formparts
     */
    public int getPartCount() {
        return formParts.length;
    }


    /**
     * convenience test method to start a shell containing this form, used for easy testing
     */
    public void startTestShell()
    {

        final Display display = Display.getDefault();
        final Shell shell = new Shell(display);
        shell.setLayout(new FillLayout());

        Realm.runWithDefault(SWTObservables.getRealm(Display.getDefault()), new Runnable()
        {
            public void run()
            {
                createUI(shell);
            }
        });
        shell.open();
        shell.pack(true);
        while (!shell.isDisposed())
        {
            if (!display.readAndDispatch())
                display.sleep();
        }

        display.dispose();
    }
    
    public void startTestView(Composite parent)
    {
        createUI(parent);
    }

    /**
     * @return currently set input on this form
     */
    public Object getInput()
    {
        Object result = null;
        if (managedForm != null)
        {
            result = managedForm.getInput();
        }
        else
        {
            result = tempInput;
        }
        return result;
    }

    /**
     * @return Message manager or null if none exists
     */
    public IMessageManager getMessageManager()
    {
        return managedForm != null ? managedForm.getMessageManager() : null;
    }
    
//    protected RCPFormPart[] getFormParts()
//    {
//        return formParts;
//    }

    /**
     * Use this function before {@link RCPForm#createUI(Composite)} is called for setting the formparts otherwise an {@link IllegalStateException} will be thrown.
     * @param formParts
     */
    protected void setFormParts(RCPFormPart[] formParts)
    {
        if(isFormCreated)
            throw new IllegalStateException("Form is already created. Changing parts at runtime is not supported!");
        else
            this.formParts = formParts;
    }

    public IManagedForm getManagedForm()
    {
        return managedForm;
    }
}
