package net.sf.rcpforms.examples.complete.formparts;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.bindingvalidation.util.ControlStateDependencyManager;
import net.sf.rcpforms.common.NullValue;
import net.sf.rcpforms.examples.complete.IExpandablePart;
import net.sf.rcpforms.examples.complete.MyControlStateDependencyManager;
import net.sf.rcpforms.examples.complete.models.TestModel;
import net.sf.rcpforms.modeladapter.configuration.BeanAdapter;
import net.sf.rcpforms.modeladapter.converter.ObservableStatusToBooleanAdapter;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.customwidgets.RCPDatePicker;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPCombo;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleButton;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;


public class ControlStateDependencyFormPart extends RCPFormPart 
implements IExpandablePart{

    private RCPSection mainSection;

    private RCPText m_nameText;
    
    private RCPDatePicker m_birthDateText;

    private RCPCombo m_geschlechtComboWithNull;
    
    private RCPSimpleButton m_isValidButton;

	private ControlStateDependencyManager m_ControlStateDependencyManager;

    private boolean minimizeSection;
	
	public ControlStateDependencyFormPart(boolean minimizeSection)
    {
        this();
        this.minimizeSection = minimizeSection;
    }

    public ControlStateDependencyFormPart()
    {
        super();
    }

    @Override
	public void createUI(FormToolkit toolkit, Composite parent) {

		mainSection = new RCPSection("Controlstate dependency Section");
        
        m_nameText = new RCPText("Name:");
        m_nameText.setState(EControlState.MANDATORY, true);
        m_nameText.setState(EControlState.INFO, true);
        m_birthDateText = new RCPDatePicker("Geburtsdatum:");
        m_birthDateText.setState(EControlState.MANDATORY, true);
        m_geschlechtComboWithNull = new RCPCombo("Geschlecht:", true);
        m_geschlechtComboWithNull
                .setNullValuePresentationKey(NullValue.GENERIC_NULL_VALUE_REPRESENTATION_DASH);
        
        m_isValidButton = new RCPSimpleButton("Form is valid:", SWT.CHECK);
        m_isValidButton.setState(EControlState.ENABLED, false);
        
        // build layout
        GridBuilder builder = new GridBuilder(toolkit, parent, 2);
        GridBuilder widgetBuilder = builder.addContainer(mainSection, 4);
        mainSection.getSWTSection().addDisposeListener(new DisposeListener() {
            public void widgetDisposed(DisposeEvent e) {
                dispose();
            }
        });
        
        if(minimizeSection)
            mainSection.getSWTSection().setExpanded(false);
        
        widgetBuilder.addLine(m_nameText, 20);
        m_nameText.getMainControl().informationDecoration.setDescriptionText("Enter a name and the birthdate will become editable.");
        widgetBuilder.addLine(m_birthDateText, 8);
        
        widgetBuilder.fillLine();

        widgetBuilder.addLine(m_geschlechtComboWithNull);
        
        widgetBuilder.addLine(m_isValidButton);
	}

	@Override
	public void bind(ValidationManager vm, Object modelBean) {
		
		final TestModel dm = (TestModel) modelBean;
		
		m_ControlStateDependencyManager = new MyControlStateDependencyManager(dm);
		
		vm.bindValue(m_nameText, dm, TestModel.P_Name);
		m_ControlStateDependencyManager.bind(vm, m_nameText, TestModel.P_Name);
		
		//convenience method of the ControlStateDependencyManager which binds value and states in one method call
		m_ControlStateDependencyManager.bindValue(vm, m_birthDateText, dm, TestModel.P_BirthDate);
		m_ControlStateDependencyManager.bindValue(vm, m_geschlechtComboWithNull, dm, TestModel.P_Gender);

		vm.addValidator(this, m_ControlStateDependencyManager);
		
        // bind valid check
        ObservableStatusToBooleanAdapter booleanState = new ObservableStatusToBooleanAdapter(
                vm.getValidationState());
        vm.bindValue(BeanAdapter.getInstance(), m_isValidButton, booleanState);
		
	}

	@Override
	public void setState(EControlState state, boolean value) {
	    mainSection.setState(state, value);
	}
	
    public void expandPart(boolean doExpand)
    {
        this.mainSection.getSWTSection().setExpanded(doExpand);
    }

	public void dispose() {
		if(m_ControlStateDependencyManager != null) {
			m_ControlStateDependencyManager.dispose();
		}
	}
	
}
