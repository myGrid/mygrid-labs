/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.bindingvalidation;

import java.util.logging.Logger;

/**
 * manages bindings of n RCPFormPart parts to one or more models.
 * <p>
 * The ValiationManager uses eclipse databinding and a set of default rules to create the most
 * suitable ObservableValues and offer an easy to use facade for binding control values to data
 * model values and control state to data model state.
 * This validation manager enhances binding to widgets for using a bean wrapper for swt widgets.
 * It offers a bean-binding for all the widget properties.
 * NOTE: THIS IS PROVISIONAL API AND NOT INTENDEND TO BE USED AT THE MOMENT   
 * <p>
 * 
 * @author Remo Loetscher
 * @since version 1.1
 * @deprecated all methods are moved {@link ValidationManager} 
 */

public class WidgetBeanValidationManager extends ValidationManager
{
    private static final Logger LOG = Logger.getLogger(WidgetBeanValidationManager.class.getName());
    
    
    public WidgetBeanValidationManager(String instanceName)
    {
        super(instanceName);
    }
    
}
