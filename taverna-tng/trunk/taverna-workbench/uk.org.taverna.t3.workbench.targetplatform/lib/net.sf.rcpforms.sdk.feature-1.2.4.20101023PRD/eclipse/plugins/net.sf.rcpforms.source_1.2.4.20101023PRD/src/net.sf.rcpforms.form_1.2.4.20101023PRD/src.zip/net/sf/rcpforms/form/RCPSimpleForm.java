/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.form;

import java.util.logging.Logger;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;

import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.IFormColors;
import org.eclipse.ui.forms.IMessage;
import org.eclipse.ui.forms.ManagedForm;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ScrolledForm;

/**
 * The main form concept of rcpforms. This RCPForm is NOT composed of a Header which displays error
 * markers and heading of the whole form.
 * NOTE: PROVISIONAL API! DO NOT USE THIS.
 * @author Remo Loetscher
 */
public class RCPSimpleForm extends RCPForm
{

    private static final Logger LOG = Logger.getLogger(RCPSimpleForm.class.getName());

    public RCPSimpleForm(String title, RCPFormPart... parts)
    {
        super(title, parts);
    }


    public RCPSimpleForm(String title, ValidationManager validationManager, RCPFormPart... parts)
    {
        super(title, validationManager, parts);
    }
    
    
    
    public RCPSimpleForm(FormToolkit toolkit, ScrolledForm form)
    {
        super(toolkit, form);
    }


    /**
     * creates the managed form including the scrolled form and form header
     * 
     * @param parent parent to create form in
     * @param title title will be ignored here
     * @param toolkit toolkit to use
     * @return the managed form
     */
    protected ManagedForm createManagedForm(Composite parent, String title, FormToolkit toolkit)
    {
        ManagedForm managedForm = null;
        ScrolledForm form = new ScrolledForm(parent, SWT.V_SCROLL | SWT.H_SCROLL
                | Window.getDefaultOrientation())
        {
            // HACK to avoid loading of images which needs osgi
            // runtime in Eclipse 3.1, so this can be used with swt too.
            // in 3.4 this bug was fixed
            @Override
            public void setMessage(String newMessage, int newType, IMessage[] messages)
            {
                try
                {
                    super.setMessage(newMessage, newType, messages);
                }
                catch (RuntimeException ex)
                {
                    // if this does not work, set message without image
                    super.setMessage(newMessage, 0, messages);
                }
                catch (NoClassDefFoundError ex)
                {
                    // using 3.3 libraries "standalone" a NoClassDefFoundError
                    // could be thrown
                    super.setMessage(newMessage, 0, messages);
                }
                catch (ExceptionInInitializerError eiie)
                {
                    // using 3.3 libraries "standalone" an
                    // ExceptionInInitializeError could be thrown
                    super.setMessage(newMessage, 0, messages);
                }
            }
        };

        managedForm = new ManagedForm(toolkit, form);
//        toolkit.decorateFormHeading(form.getForm());
        form.setExpandHorizontal(true);
        form.setExpandVertical(true);
        form.setBackground(toolkit.getColors().getBackground());
        form.setForeground(toolkit.getColors().getColor(IFormColors.TITLE));
        form.setFont(JFaceResources.getHeaderFont());
//        if (title != null)
//        {
//            form.setText(title);
//        }
        return managedForm;
    }

    
}
