/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.tablesupport.tables;

import net.sf.rcpforms.modeladapter.configuration.ModelAdapter;
import net.sf.rcpforms.modeladapter.util.Validate;
import net.sf.rcpforms.tablesupport.Messages;

import org.eclipse.core.databinding.observable.list.WritableList;
import org.eclipse.jface.viewers.ColumnViewer;
import org.eclipse.jface.viewers.IContentProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.TreeViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableCursor;
import org.eclipse.swt.events.FocusAdapter;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.MouseListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.events.TraverseEvent;
import org.eclipse.swt.events.TraverseListener;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Tree;
import org.eclipse.swt.widgets.TreeColumn;

/**
 * Class TableUtil is a powerful utility to create an editable table just by defining the column
 * properties like heading, property to display, editor type to use for the column.
 * 
 * @author Marco van Meegen
 * @author Remo Loetscher
 */
public class TableUtil
{
    /**
     * configures the viewer using the given columnConfigurations. Make sure that the input to the
     * editor is a {@link WritableList} and for the elements of the list a ModelAdapter is
     * registered.
     * <p>
     * 
     * @param tableViewer table viewer which should be configured; if column auto resizing is
     *            needed, make sure the table from the viewer is of Type {@link SizeFixedTable}.
     * @param rowElementClass Class of the elements which display a row
     * @param tableData configuration unit for the table
     * @return fully configured and functional table viewer, just set the input.
     */
    public static TableViewer configureTableViewer(
                                                   final TableViewer tableViewer,
                                                   Object rowElementMetaClass,
                                                   RCPTableData tableData)
    {
        return configureTableViewer(tableViewer, rowElementMetaClass, tableData, null);
    }
    
    /**
     * configures the viewer using the given columnConfigurations. Make sure that the input to the
     * editor is a {@link WritableList} and for the elements of the list a ModelAdapter is
     * registered.
     * <p>
     * 
     * @param tableViewer table viewer which should be configured; if column auto resizing is
     *            needed, make sure the table from the viewer is of Type {@link SizeFixedTable}.
     * @param rowElementClass Class of the elements which display a row
     * @param tableData configuration unit for the table.
     * @param propertyLabelProvider add a custom {@link PropertyLabelProviderAndCellModifier} to the
     *            viewer or null if default should be used. If a custom
     *            {@link PropertyLabelProviderAndCellModifier} is passed, it will be initialised
     *            with the given columnConfigurations and rowElementClass calling the
     *            init(ColumnConfiguration[], Class<?>) method on it.
     * @return fully configured and functional table viewer, just set the input.
     */
    public static TableViewer configureTableViewer(
                                                   final TableViewer tableViewer,
                                                   Object rowElementMetaClass,
                                                   RCPTableData tableData,
                                                   PropertyLabelProviderAndCellModifier propertyLabelProvider)
    {
        boolean isEditable = TableUtil.columnConfigurationCheck(tableData.columnConfigurations);
        Table table = tableViewer.getTable();
        boolean isCheckboxTable = (table.getStyle() & SWT.CHECK) != 0;

        Validate.isTrue(!isEditable || (table.getStyle() & SWT.FULL_SELECTION) != 0,
                "Use SWT.FULL_SELECTION for the table, cell editors need it"); //$NON-NLS-1$

        Validate.isTrue(tableViewer instanceof TableViewer,
                "Viewer for tables has to be a subclass of TableViewer"); //$NON-NLS-1$

        if (isCheckboxTable && tableData.enableSeparateCheckboxColumn)
        {
            tableData.columnConfigurations = TableUtil
                    .createModifiedColumnConfig(tableData.columnConfigurations);
        }

        propertyLabelProvider = TableUtil.initPropertyLabelProvider(propertyLabelProvider,
                tableData.columnConfigurations, rowElementMetaClass);

        // build editing supports for columns
        // if no sorters were initialized create new one.
        if (tableData.columnSorter == null)
        {
            tableData.columnSorter = new GenericTableSorter[tableData.columnConfigurations.length];
        }
        // initialize array to store create viewercolumn
        tableData.viewerColumn = new TableViewerColumn[tableData.columnConfigurations.length];

        for (int i = 0; i < tableData.columnConfigurations.length; i++)
        {
            tableData.viewerColumn[i] = new TableViewerColumn(tableViewer, SWT.NONE);
            tableData.viewerColumn[i].getColumn().setWidth(tableData.columnConfigurations[i].getSize());
            tableData.viewerColumn[i].getColumn().setText(tableData.columnConfigurations[i].getHeader());
            tableData.viewerColumn[i].setEditingSupport(new TableEditingSupport(tableViewer, propertyLabelProvider,
                        tableData.columnConfigurations[i]));
            // add sorting functionality
            if (tableData.columnConfigurations[i].isColumnSortingEnabled())
            {
                // create new generic sorter if column has to be sorted but no initial sorter is
                // available
                if (tableData.columnSorter[i] == null)
                {
                    tableData.columnSorter[i] = new GenericTableSorter(
                            tableData.columnConfigurations[i].getProperty());
                }
                if(tableData.columnSorter[i] instanceof SelectionListener)
                    tableData.viewerColumn[i].getColumn().addSelectionListener((SelectionListener)tableData.columnSorter[i]);
                else if(tableData.columnSorter[i] instanceof AbstractGenericSorter)
                    tableData.viewerColumn[i].getColumn().addSelectionListener(new TableSorterSelectionAdapter(tableViewer, (AbstractGenericSorter)tableData.columnSorter[i]));
            }
        }

        // set content and label provider after creating columns, otherwise
        // column label provider are not created
        ModelAdapter adapter = ModelAdapter.getAdapterForMetaClass(rowElementMetaClass);
        Validate
                .notNull(
                        adapter,
                        "No adapter found for the meta class "
                                + rowElementMetaClass
                                + ". Make sure you register a suitable adapter using ModelAdapter.registerAdapter().");

        IStructuredContentProvider defaultContentProvider = adapter.createDefaultContentProvider();
        Validate.notNull(defaultContentProvider,
                "ModelAdapter must return a default content provider");
        TableUtil.initViewer(tableViewer, defaultContentProvider, propertyLabelProvider);

        // enable auto resizing
        if (tableData.enableAutoresizing)
        {
            int[] columnWeights = new int[tableData.columnConfigurations.length];
            int sum = 0;
            for (int i = 0; i < tableData.columnConfigurations.length; i++)
            {
                columnWeights[i] = tableData.columnConfigurations[i].getSize();
                sum += columnWeights[i];
            }
            if (table instanceof SizeFixedTable)
            {
                // if table supports special calculation, use table column resize
                // adapter to get rid of "last" empty column
                new TableColumnResizeAdapter(table, columnWeights);
                ((SizeFixedTable) table).setAccumulatedColumnMinWidth(sum);
            }
        }

        // flag was introduced to have the choice of either TableCursor support
        // or editing by simple clicking
        if (isEditable && tableData.enableTableCursorSupport)
        {
            createTableCursor(tableViewer, table);
        }
        return tableViewer;
    }
    /**
     * configures the viewer using the given columnConfigurations. Make sure that the input to the
     * editor is a {@link WritableList} and for the elements of the list a ModelAdapter is
     * registered.
     * <p>
     * 
     * @param tableViewer table viewer which should be configured; if column auto resizing is
     *            needed, make sure the table from the viewer is of Type {@link SizeFixedTable}.
     * @param columnConfigurations configures the columns and cell editors
     * @param rowElementClass Class of the elements which display a row
     * @param separateCheckBoxColumn if creating a viewer for a table with {@link SWT#CHECK} style,
     *            setting this to true will create an empty first column with the check boxes
     *            instead of the swt standard of inserting the checkbox into the first column
     * @param enableTableCursorSupport if cursor support is enabled table can be browsed by keyboard
     *            an cell editing (if available) will be activating by clicking \<enter\>
     * @return fully configured and functional table viewer, just set the input.
     * @deprecated use {@link TableUtil#configureTableViewer(TableViewer, Object, RCPTableData, PropertyLabelProviderAndCellModifier)} instead
     */
    public static TableViewer configureTableViewer(final TableViewer tableViewer,
                                                   ColumnConfiguration[] columnConfigurations,
                                                   Object rowElementClass,
                                                   boolean separateCheckBoxColumn,
                                                   boolean enableTableCursorSupport)
    {
        return configureTableViewer(tableViewer, columnConfigurations, rowElementClass,
                separateCheckBoxColumn, enableTableCursorSupport, null);
    }

    /**
     * configures the viewer using the given columnConfigurations. Make sure that the input to the
     * editor is a {@link WritableList} and for the elements of the list a ModelAdapter is
     * registered.
     * <p>
     * 
     * @param tableViewer table viewer which should be configured; if column auto resizing is
     *            needed, make sure the table from the viewer is of Type {@link SizeFixedTable}.
     * @param columnConfigurations configures the columns and cell editors
     * @param rowElementMetaClass Class of the elements which display a row
     * @param separateCheckBoxColumn if creating a viewer for a table with {@link SWT#CHECK} style,
     *            setting this to true will create an empty first column with the check boxes
     *            instead of the swt standard of inserting the checkbox into the first column
     * @param enableTableCursorSupport if cursor support is enabled table can be browsed by keyboard
     *            an cell editing (if available) will be activating by clicking \<enter\>
     * @param propertyLabelProvider add a custom {@link PropertyLabelProviderAndCellModifier} to the
     *            viewer or null if default should be used. If a custom
     *            {@link PropertyLabelProviderAndCellModifier} is passed, it will be initialised
     *            with the given columnConfigurations and rowElementClass calling the
     *            init(ColumnConfiguration[], Class<?>) method on it.
     * @return fully configured and functional table viewer, just set the input.
     * @deprecated use {@link TableUtil#configureTableViewer(TableViewer, Object, RCPTableData, PropertyLabelProviderAndCellModifier)} instead
     */
    public static TableViewer configureTableViewer(
                                                   final TableViewer tableViewer,
                                                   ColumnConfiguration[] columnConfigurations,
                                                   Object rowElementMetaClass,
                                                   boolean separateCheckBoxColumn,
                                                   boolean enableTableCursorSupport,
                                                   PropertyLabelProviderAndCellModifier propertyLabelProvider)
    {
        RCPTableData tableData = new RCPTableData();
        tableData.columnConfigurations = columnConfigurations;
        tableData.enableSeparateCheckboxColumn = separateCheckBoxColumn;
        tableData.enableTableCursorSupport = enableTableCursorSupport;
        return configureTableViewer(tableViewer, rowElementMetaClass, tableData, propertyLabelProvider);
    }

    /**
     * @param tableViewer
     * @param table
     */
    private static void createTableCursor(final TableViewer tableViewer, final Table table)
    {
        // create a TableCursor to navigate around the table
        final TableCursor cursor = new TableCursor(table, SWT.NONE);
        cursor.setVisible(true);

        cursor.addSelectionListener(new SelectionAdapter()
        {
            @Override
            public void widgetDefaultSelected(SelectionEvent e)
            {
                // when the user hits "ENTER" in the TableCursor,
                // let the table do cell editing
                TableItem row = cursor.getRow();
                int column = cursor.getColumn();
                tableViewer.editElement(row.getData(), column);
            }
        });

        cursor.addMouseListener(new MouseListener()
        {

            public void mouseDoubleClick(MouseEvent e)
            {
                TableItem row = cursor.getRow();
                int column = cursor.getColumn();
                tableViewer.editElement(row.getData(), column);
            }

            public void mouseDown(MouseEvent e)
            {
                // do nothing
            }

            public void mouseUp(MouseEvent e)
            {
                // do nothing
            }

        });
        cursor.addTraverseListener(new TraverseListener()
        {
            public void keyTraversed(TraverseEvent e)
            {
                // skip table control if cursor is
                if (e.detail == SWT.TRAVERSE_TAB_PREVIOUS)
                {
                    e.doit = false;
                    table.traverse(SWT.TRAVERSE_TAB_PREVIOUS);
                }
            }
        });
        table.addFocusListener(new FocusAdapter()
        {
            // if the table first gets the focus, position the table cursor
            @Override
            public void focusGained(FocusEvent e)
            {
                Display.getCurrent().asyncExec(new Runnable()
                {
                    public void run()
                    {
                        // find the currently selected row and position cursor
                        // there
                        if (cursor.getRow() == null)
                        {
                            TableItem[] selection = table.getSelection();
                            TableItem row = null;
                            if (selection.length == 0)
                            {
                                int topIndex = table.getTopIndex();
                                if (topIndex < table.getItemCount())
                                {
                                    row = table.getItem(topIndex);
                                }
                            }
                            else
                            {
                                row = selection[0];
                            }
                            if (row != null)
                            {
                                table.showItem(row);
                                // first time set
                                cursor.setSelection(row, 0);
                            }
                        }
                        cursor.setFocus();
                    }
                });
            }
        });
    }
    
    /**
     * configures the tree viewer using the given columnConfigurations to create a table tree
     * viewer. Make sure that the input to the editor is a {@link WritableList} and for the elements
     * of the list a ModelAdapter is registered.
     * 
     * @param treeViewer tree viewer which should be configured;
     * @param columnConfigurations configures the columns and cell editor
     * @param rowElementClass Class of the elements which display a row
     * @param treeTableData configuration unit for the tree
     * @param contentProvider tree content provider
     * @return fully configured and functional tree viewer, just set the input.
     */

    public static TreeViewer configureTreeTableViewer(
                                                   final TreeViewer treeViewer,
                                                   Object rowElementMetaClass,
                                                   RCPTreeTableData treeTableData,
                                                   ITreeContentProvider contentProvider)
    {
        return TableUtil.configureTreeTableViewer(treeViewer, rowElementMetaClass, treeTableData, contentProvider, null);
    }
    
    /**
     * configures the tree viewer using the given columnConfigurations to create a table tree
     * viewer. Make sure that the input to the editor is a {@link WritableList} and for the elements
     * of the list a ModelAdapter is registered.
     * 
     * @param treeViewer tree viewer which should be configured;
     * @param columnConfigurations configures the columns and cell editor
     * @param rowElementClass Class of the elements which display a row
     * @param treeTableData configuration unit for the tree
     * @param contentProvider tree content provider
     * @param propertyLabelProvider add a custom {@link PropertyLabelProviderAndCellModifier} to the
     *            viewer or null if default should be used. If a custom
     *            {@link PropertyLabelProviderAndCellModifier} is passed, it will be initialised
     *            with the given columnConfigurations and rowElementClass calling the
     *            init(ColumnConfiguration[], Class<?>) method on it.
     * @return fully configured and functional tree viewer, just set the input.
     */

    public static TreeViewer configureTreeTableViewer(
                                                   final TreeViewer treeViewer,
                                                   Object rowElementMetaClass,
                                                   RCPTreeTableData treeTableData,
                                                   ITreeContentProvider contentProvider,
                                                   PropertyLabelProviderAndCellModifier propertyLabelProvider)
    {
        boolean isEditable = TableUtil.columnConfigurationCheck(treeTableData.columnConfigurations);
        final Tree tree = treeViewer.getTree();
        tree.setHeaderVisible(true);

        Validate.isTrue(!isEditable || (tree.getStyle() & SWT.FULL_SELECTION) != 0,
                "Use SWT.FULL_SELECTION for the tree, cell editors need it"); //$NON-NLS-1$

        Validate.isTrue(treeViewer instanceof TreeViewer,
                "Viewer for Trees has to be a subclass of TreeViewer"); //$NON-NLS-1$

        if ((tree.getStyle() & SWT.CHECK) != 0)
        {
            if (treeTableData.enableSeparateCheckboxColumn)
            {
                treeTableData.columnConfigurations = TableUtil.createModifiedColumnConfig(treeTableData.columnConfigurations);
            }
        }

        propertyLabelProvider = TableUtil.initPropertyLabelProvider(propertyLabelProvider,
                treeTableData.columnConfigurations, rowElementMetaClass);

        // build editing supports for columns
        // if no sorters were initialized create new one.
        if (treeTableData.columnSorter == null)
        {
            treeTableData.columnSorter = new GenericTableSorter[treeTableData.columnConfigurations.length];
        }
        // initialize array to store create viewercolumn
        treeTableData.viewerColumn = new TreeViewerColumn[treeTableData.columnConfigurations.length];
        for (int i = 0; i < treeTableData.columnConfigurations.length; i++)
        {
            treeTableData.viewerColumn[i] = new TreeViewerColumn(treeViewer, SWT.NONE);
            treeTableData.viewerColumn[i].getColumn().setWidth(treeTableData.columnConfigurations[i].getSize());
            treeTableData.viewerColumn[i].getColumn().setText(treeTableData.columnConfigurations[i].getHeader());
            treeTableData.viewerColumn[i].setEditingSupport(new TableEditingSupport(treeViewer, propertyLabelProvider,
                    treeTableData.columnConfigurations[i]));
            // add sorting functionality
            if (treeTableData.columnConfigurations[i].isColumnSortingEnabled())
            {
                // create new generic sorter if column has to be sorted but no initial sorter is
                // available
                if (treeTableData.columnSorter[i] == null)
                {
                    treeTableData.columnSorter[i] = new GenericTableSorter(
                            treeTableData.columnConfigurations[i].getProperty());
                }
                if(treeTableData.columnSorter[i] instanceof SelectionListener)
                    treeTableData.viewerColumn[i].getColumn().addSelectionListener((SelectionListener)treeTableData.columnSorter[i]);
                else if(treeTableData.columnSorter[i] instanceof AbstractGenericSorter)
                    treeTableData.viewerColumn[i].getColumn().addSelectionListener(new TableTreeSorterSelectionAdapter(treeViewer, (AbstractGenericSorter)treeTableData.columnSorter[i]));
            }
        }

        // set content and label provider after creating columns, otherwise
        // column label provider are not created
        TableUtil.initViewer(treeViewer, contentProvider, propertyLabelProvider);

        // enable auto resizing
        if (treeTableData.enableAutoresizing)
        {
            int[] columnWeights = new int[treeTableData.columnConfigurations.length];
            int sum = 0;
            for (int i = 0; i < treeTableData.columnConfigurations.length; i++)
            {
                columnWeights[i] = treeTableData.columnConfigurations[i].getSize();
                sum += columnWeights[i];
            }
            new TreeTableColumnResizeAdapter(tree, columnWeights);
        }

        return treeViewer;
    }

    /**
     * configures the tree viewer using the given columnConfigurations to create a table tree
     * viewer. Make sure that the input to the editor is a {@link WritableList} and for the elements
     * of the list a ModelAdapter is registered.
     * 
     * @param treeViewer tree viewer which should be configured;
     * @param columnConfigurations configures the columns and cell editor
     * @param rowElementClass Class of the elements which display a row
     * @param separateCheckBoxColumn if creating a viewer for a table with {@link SWT#CHECK} style,
     *            setting this to true will create an empty first column with the check boxes
     *            instead of the swt standard of inserting the checkbox into the first column
     * @return fully configured and functional tree viewer, just set the input.
     * @deprecated use {@link TableUtil#configureTreeTableViewer(TreeViewer, Object, RCPTreeTableData, ITreeContentProvider, PropertyLabelProviderAndCellModifier)} instead
     */
    public static TreeViewer configureTreeTableViewer(final TreeViewer treeViewer,
                                                      ITreeContentProvider contentProvider,
                                                      ColumnConfiguration[] columnConfigurations,
                                                      Class<?> rowElementClass,
                                                      boolean separateCheckBoxColumn)
    {
        return configureTreeTableViewer(treeViewer, contentProvider, columnConfigurations,
                rowElementClass, separateCheckBoxColumn, null);
    }

    /**
     * configures the tree viewer using the given columnConfigurations to create a table tree
     * viewer. Make sure that the input to the editor is a {@link WritableList} and for the elements
     * of the list a ModelAdapter is registered.
     * 
     * @param treeViewer tree viewer which should be configured;
     * @param columnConfigurations configures the columns and cell editor
     * @param rowElementClass Class of the elements which display a row
     * @param separateCheckBoxColumn if creating a viewer for a table with {@link SWT#CHECK} style,
     *            setting this to true will create an empty first column with the check boxes
     *            instead of the swt standard of inserting the checkbox into the first column
     * @param propertyLabelProvider add a custom {@link PropertyLabelProviderAndCellModifier} to the
     *            viewer or null if default should be used. If a custom
     *            {@link PropertyLabelProviderAndCellModifier} is passed, it will be initialised
     *            with the given columnConfigurations and rowElementClass calling the
     *            init(ColumnConfiguration[], Class<?>) method on it.
     * @return fully configured and functional tree viewer, just set the input.
     * @deprecated use {@link TableUtil#configureTreeTableViewer(TreeViewer, Object, RCPTreeTableData, ITreeContentProvider, PropertyLabelProviderAndCellModifier)} instead
     */
    public static TreeViewer configureTreeTableViewer(
                                                      final TreeViewer treeViewer,
                                                      ITreeContentProvider contentProvider,
                                                      ColumnConfiguration[] columnConfigurations,
                                                      Class<?> rowElementClass,
                                                      boolean separateCheckBoxColumn,
                                                      PropertyLabelProviderAndCellModifier propertyLabelProvider)
    {
        RCPTreeTableData ttd = new RCPTreeTableData();
        ttd.columnConfigurations = columnConfigurations;
        ttd.enableSeparateCheckboxColumn = separateCheckBoxColumn;
        return TableUtil.configureTreeTableViewer(treeViewer, rowElementClass, ttd, contentProvider, propertyLabelProvider);
        
    }

    private static void initViewer(ColumnViewer columnViewer, IContentProvider contentProvider,
                                   PropertyLabelProviderAndCellModifier propertyLabelProvider)
    {
        // only set if available; e.g. emf binding will not use this content provider as default
        if (contentProvider != null)
        {
            columnViewer.setContentProvider(contentProvider);
        }
        columnViewer.setLabelProvider(propertyLabelProvider);
        columnViewer.setCellModifier(propertyLabelProvider);
    }

    /**
     * add dummy column for checkbox viewer if checkboxes should be in its own column
     * 
     * @return adapted ColumnConfiguration array
     */
    private static ColumnConfiguration[] createModifiedColumnConfig(
                                                                    ColumnConfiguration[] originalColConf)
    {
        ColumnConfiguration[] modifiedColumnConfigurations = new ColumnConfiguration[originalColConf.length + 1];
        modifiedColumnConfigurations[0] = new ColumnConfiguration(Messages
                .getString("TableUtil.SelectionHeader"), null, 55, SWT.NONE); //$NON-NLS-1$
        //fix for bug 2898547: if table have own column for checkboxes --> disable sorting functionality
        //TODO how to add generic sorter for this column? no binding to property available
        // --> boolean sorting does not work.
        modifiedColumnConfigurations[0].enableColumnSorting(false);
        System.arraycopy(originalColConf, 0, modifiedColumnConfigurations, 1,
                originalColConf.length);
        return modifiedColumnConfigurations;
    }

    /**
     * @param columnConfigurations
     * @return indicates if viewer has to support editable functionality
     */
    private static boolean columnConfigurationCheck(ColumnConfiguration[] columnConfigurations)
    {
        boolean isEditable = false;
        // check if it should be editable
        // verify column configurations
        for (ColumnConfiguration columnConfiguration : columnConfigurations)
        {
            if (columnConfiguration.getCellEditorType() != null)
            {
                isEditable = true;
            }
            if (columnConfiguration.getCellEditorType() == ECellEditorType.COMBO)
            {
                Validate.notNull(columnConfiguration.getComboItems(),
                        "Pass combo items in constructor for cell editors of type COMBO"); //$NON-NLS-1$
                Validate.noNullElements(columnConfiguration.getComboItems(),
                        "Null items are not allowed"); //$NON-NLS-1$
            }
        }

        return isEditable;
    }

    /**
     * create label provider with integrated cell modifier or take the one passed
     * 
     * @param propertyLabelProvider
     * @param modifiedColumnConfigurations
     * @param rowElementMetaClass
     */
    private static PropertyLabelProviderAndCellModifier initPropertyLabelProvider(
                                                                                  PropertyLabelProviderAndCellModifier propertyLabelProvider,
                                                                                  ColumnConfiguration[] modifiedColumnConfigurations,
                                                                                  Object rowElementMetaClass)
    {

        if (propertyLabelProvider == null)
        {
            propertyLabelProvider = new PropertyLabelProviderAndCellModifier(
                    modifiedColumnConfigurations, rowElementMetaClass);
        }
        else
        {
            propertyLabelProvider.init(modifiedColumnConfigurations, rowElementMetaClass);
        }

        return propertyLabelProvider;

    }

}

class TableSorterSelectionAdapter extends SelectionAdapter
{
    private TableViewer tableViewer;
    private AbstractGenericSorter genericSorter;

    public TableSorterSelectionAdapter(TableViewer viewer, AbstractGenericSorter sorter)
    {
        this.tableViewer = viewer;
        this.genericSorter = sorter;
    }
    
    @Override
    public void widgetSelected(SelectionEvent e)
    {
        AbstractGenericSorter sorter = genericSorter;
        // switch sorting direction
        sorter.switchSortDirection();
        
        // set sort indicator to the table header
        tableViewer.getTable().setSortColumn((TableColumn) e.widget);
        tableViewer.getTable().setSortDirection(sorter.isDescendingOrder() ? SWT.DOWN : SWT.UP);
        
        // set sorter or only refresh
        if (tableViewer.getSorter() != sorter)
            tableViewer.setSorter(sorter);
        else
            tableViewer.refresh();
        
    }
}

class TableTreeSorterSelectionAdapter extends SelectionAdapter
{
    private TreeViewer treeViewer;
    private AbstractGenericSorter genericSorter;

    public TableTreeSorterSelectionAdapter(TreeViewer viewer, AbstractGenericSorter sorter)
    {
        this.treeViewer = viewer;
        this.genericSorter = sorter;
    }
    
    @Override
    public void widgetSelected(SelectionEvent e)
    {
        AbstractGenericSorter sorter = genericSorter;
        // switch sorting direction
        sorter.switchSortDirection();
        
        // set sort indicator to the table header
        treeViewer.getTree().setSortColumn((TreeColumn) e.widget);
        treeViewer.getTree().setSortDirection(sorter.isDescendingOrder() ? SWT.DOWN : SWT.UP);
        
        // set sorter or only refresh
        if (treeViewer.getSorter() != sorter)
            treeViewer.setSorter(sorter);
        else
            treeViewer.refresh();
        
    }
}
