/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.app;

import net.sf.rcpforms.examples.complete.DisposeRebindStackForm;
import net.sf.rcpforms.examples.complete.models.PersonDataModel;
import net.sf.rcpforms.form.RCPFormViewPart;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.swt.widgets.Composite;

public class DisposeRebindView extends RCPFormViewPart<DisposeRebindStackForm>
{
    public static final String ID = "net.sf.rcpforms.examples.DisposeRebindview";

    private static DisposeRebindStackForm drStackForm;
    public DisposeRebindView()
    {
        // create
        super(drStackForm = new DisposeRebindStackForm());
        // and set input
        setInput(DisposeRebindStackForm.createModels());
    }
    @Override
    public void createPartControl(Composite parent)
    {
        super.createPartControl(parent);
        IToolBarManager toolBarManager = getViewSite().getActionBars().getToolBarManager();
        toolBarManager.add(new Action("dispose"){

            @Override
            public void run()
            {
                drStackForm.dispose();
            }});
        
        toolBarManager.add(new Action("re-create"){

            @Override
            public void run()
            {
                drStackForm.recreate();
            }});
        getViewSite().getActionBars().getToolBarManager().add(new Action("add new model"){

            @Override
            public void run()
            {
                setNewModel();
            }});
        getViewSite().getActionBars().getToolBarManager().add(new Action("revalidate"){

            @Override
            public void run()
            {
                drStackForm.revalidate();
            }});
    }
    
    protected void setNewModel()
    {
        drStackForm.prepareModelChange();
        Object[] model = (DisposeRebindStackForm.createModels());
        PersonDataModel testModel = ((PersonDataModel) model[0]);
        testModel.setName("NewName " + System.currentTimeMillis());
        setInput(model);
    }
}