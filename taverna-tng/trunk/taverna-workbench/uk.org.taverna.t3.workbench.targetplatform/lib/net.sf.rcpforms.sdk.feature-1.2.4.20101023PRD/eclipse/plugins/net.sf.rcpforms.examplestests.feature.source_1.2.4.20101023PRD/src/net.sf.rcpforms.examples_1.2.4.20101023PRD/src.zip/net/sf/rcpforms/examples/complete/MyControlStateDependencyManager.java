package net.sf.rcpforms.examples.complete;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import net.sf.rcpforms.bindingvalidation.util.ControlStateDependencyManager;
import net.sf.rcpforms.examples.complete.models.TestModel;

public class MyControlStateDependencyManager extends ControlStateDependencyManager implements PropertyChangeListener {

	private TestModel model;
	
	public MyControlStateDependencyManager(TestModel newModel) {
		super(newModel, TestModel.P_Name, TestModel.P_BirthDate, TestModel.P_Gender);
				
		newModel.addPropertyChangeListener(TestModel.P_Name, this);
		
		this.refreshStates(TestModel.P_Name, null);
		
		model = newModel;
		
		setMandatoryState(TestModel.P_Name, true);
	}
	
	public void propertyChange(PropertyChangeEvent event) {
		this.refreshStates(event.getPropertyName(), event.getNewValue());
	}
	
	public void dispose() {		
		model.removePropertyChangeListener(TestModel.P_Name, this);
		super.dispose();
	}
	
	protected void refreshStates(String property, Object newValue)
	{
	    if(TestModel.P_Name.equals(property)) {
            String value = "";
            
            if(newValue != null) {
                value = ((String)newValue).toLowerCase();
            }
            
            //check if a name is set
            boolean isNameEmpty = true;
            if(value.length() > 0) {
                isNameEmpty = false;
            }
            
            //set states
            setMandatoryState(TestModel.P_BirthDate, !isNameEmpty);
            setEnableState(TestModel.P_BirthDate, !isNameEmpty);
            setReadonlyState(TestModel.P_Gender, isNameEmpty);
        }
	}
	
}
