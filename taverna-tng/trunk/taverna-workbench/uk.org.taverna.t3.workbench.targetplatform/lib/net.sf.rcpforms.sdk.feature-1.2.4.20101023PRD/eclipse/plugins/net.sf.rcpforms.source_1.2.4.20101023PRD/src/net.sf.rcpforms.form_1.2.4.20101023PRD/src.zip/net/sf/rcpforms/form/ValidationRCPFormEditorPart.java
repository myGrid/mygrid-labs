/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Anthony Wallace - initial API and implementation
 *     Remo Loetscher - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.form;

import org.eclipse.core.databinding.observable.value.IValueChangeListener;
import org.eclipse.core.databinding.observable.value.ValueChangeEvent;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.swt.widgets.Composite;

/**
 * This is a special Editor part which connects validation state of the form and the editor dirty
 * state. This means that an editor will be marked as dirty if model changed and the validation
 * status is {@link IStatus#OK}. Therefore save action will not be available until the form is
 * valid.
 * @see RCPFormEditorPart
 * 
 * @author Anthony Wallace
 * @since Version 1.1
 */
public abstract class ValidationRCPFormEditorPart<T extends RCPForm> extends RCPFormEditorPart<T>
{
    /**
     * @param form
     */
    public ValidationRCPFormEditorPart(T form)
    {
        super(form);
    }

    private IValueChangeListener m_statusChangeListener;

    private boolean formIsValid;

    /*
    * (non-Javadoc)
    * 
    * @see net.sf.rcpforms.form.RCPFormEditorPart#isDirty()
    */
    @Override
    public boolean isDirty()
    {
        return super.isDirty() && formIsValid;
    }

    /*
    * (non-Javadoc)
    * 
    * @see
    * net.sf.rcpforms.form.RCPFormEditorPart#createPartControl(org.eclipse.
    * swt.widgets.Composite)
    */
    @Override
    public void createPartControl(Composite parent)
    {
        super.createPartControl(parent);
        addStatusChangeListener(getForm());
    }

    /*
    * (non-Javadoc)
    * 
    * @see net.sf.rcpforms.form.RCPFormEditorPart#setDirty(boolean)
    */
    @Override
    protected void setDirty(boolean value)
    {
        // Check if the form is valid before setting dirty state
        if (getForm().getObservableValidationStatus() != null)
        {
            IStatus newStatus = (IStatus) getForm().getObservableValidationStatus().getValue();
            formIsValid = newStatus.isOK();
            if (!formIsValid)
            {
                super.setDirty(formIsValid);
            }
            else
            {
                super.setDirty(value);
            }
        }
        else
        {
            super.setDirty(value);
        }
    }

    /**
     * add a status change listener to the form to inform dirty state
     * 
     * @param form
     */
    protected void addStatusChangeListener(RCPForm form)
    {
        if (form != null)
        {
            // Register status change listener
            m_statusChangeListener = new IValueChangeListener()
            {
                // Don't want to mark the form as dirty on first validation pass
                private boolean first = true;

                public void handleValueChange(ValueChangeEvent event)
                {
                    IStatus newStatus = (IStatus) event.getObservableValue().getValue();
                    formIsValid = newStatus.isOK();
                    if (!first)
                    {
                        if (!formIsValid || !isDirty())
                        {
                            setDirty(formIsValid);
                        }
                    }
                    first = false;
                }
            };
            IStatus newStatus = (IStatus) form.getObservableValidationStatus().getValue();
            formIsValid = newStatus.isOK();
            form.getObservableValidationStatus().addValueChangeListener(m_statusChangeListener);
        }
    }

    protected void removeStatusChangeListener(RCPForm form)
    {
        if (m_statusChangeListener != null && form != null)
        {
            // deregister listener
            form.getObservableValidationStatus().removeValueChangeListener(m_statusChangeListener);
            m_statusChangeListener = null;
        }
    }

    protected IValueChangeListener getStatusChangeListener()
    {
        return m_statusChangeListener;
    }

    protected void setStatusChangeListener(IValueChangeListener ivcl)
    {
        m_statusChangeListener = ivcl;
    }

    /*
    * (non-Javadoc)
    * 
    * @see org.eclipse.ui.part.WorkbenchPart#dispose()
    */
    @Override
    public void dispose()
    {
        super.dispose();
        removeStatusChangeListener(getForm());
    }

}
