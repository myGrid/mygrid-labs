/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.complete.formparts;

import java.util.Date;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.examples.complete.IExpandablePart;
import net.sf.rcpforms.examples.complete.models.TableModel;
import net.sf.rcpforms.examples.complete.models.TestModel;
import net.sf.rcpforms.examples.complete.models.TestModel.Gender;
import net.sf.rcpforms.modeladapter.configuration.ModelAdapter;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPComposite;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPList;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPPushButton;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * Example part demonstrating the advanced list features of RCPForms.
 * <p>
 * <ul>
 * <li>creating a list
 * <li>creating a change aware list
 * </ul>
 * 
 * @author Remo Loetscher
 */
public class SandboxListPart extends RCPFormPart
implements IExpandablePart
{
    private RCPSection mainSection;

    private RCPList m_List, m_changeAwareList;

    private RCPPushButton m_addItem;

    private RCPPushButton m_removeItem;

    private TableModel dataModel;

    private boolean minimizeSection;

    public SandboxListPart()
    {
        m_addItem = new RCPPushButton("add random item");
        m_removeItem = new RCPPushButton("remove selected item");
        m_List = new RCPList("List:", SWT.SINGLE | SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
        m_changeAwareList = new RCPList("List tracking changes:", SWT.SINGLE | SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
    }

    public SandboxListPart(boolean minimizeSection)
    {
        this();
        this.minimizeSection = minimizeSection;
    }

    @Override
    public void createUI(FormToolkit formToolkit, Composite parent)
    {
        GridBuilder builder = new GridBuilder(formToolkit, parent, 1);
        mainSection = new RCPSection("Sandbox List Section");
        GridBuilder sectionBuilder = builder.addContainer(mainSection, 2);
        
        if(minimizeSection)
            mainSection.getSWTSection().setExpanded(false);
        
        RCPComposite buttonPanel = new RCPComposite();
        GridBuilder buttonWidgetFactory = sectionBuilder.fill(1).addContainer(buttonPanel, 8);
        buttonWidgetFactory.add(m_addItem);
        m_addItem.getSWTButton().addSelectionListener(new SelectionAdapter()
        {
            @Override
            public void widgetSelected(SelectionEvent e)
            {
                addRandomItem();
            }
        });

        buttonWidgetFactory.add(m_removeItem);
        m_removeItem.getSWTButton().addSelectionListener(new SelectionAdapter()
        {
            @Override
            public void widgetSelected(SelectionEvent e)
            {
                removeSelectedItem();
            }
        });


        // create normal Table with table cursor support
        sectionBuilder.addLine(m_List, 75);
        m_List.setState(EControlState.ENABLED, false);
        sectionBuilder.addLine(m_changeAwareList, 75);
    }

    @Override
    public void bind(ValidationManager context, Object modelBean)
    {
        Validate.isTrue(modelBean instanceof TableModel);
        this.dataModel = (TableModel) modelBean;

        // set normal list viewers input
        m_List.getViewer().setInput(dataModel.getList());
        
        //special content provider for tracking list changes
        ModelAdapter adapterForInstance = ModelAdapter.getAdapterForInstance(modelBean);
        IStructuredContentProvider createDefaultContentProvider = adapterForInstance.createDefaultContentProvider();
        m_changeAwareList.getViewer().setContentProvider(createDefaultContentProvider);
        m_changeAwareList.getViewer().setInput(dataModel.getList());
    }

    private void removeSelectedItem()
    {
        if (dataModel.getList().size() > 0 && !m_changeAwareList.getViewer().getSelection().isEmpty())
        {
            StructuredSelection selection = (StructuredSelection) m_changeAwareList.getViewer().getSelection();
            if(dataModel.getList().remove(selection.getFirstElement()) && dataModel.getList().size() > 0)
                //select first element
                m_changeAwareList.getViewer().setSelection(new StructuredSelection(dataModel.getList().get(0)));
        }
    }

    private void addRandomItem()
    {
        dataModel.getList().add(this.generateNewDataModelItem());
        //select first element
        m_changeAwareList.getViewer().setSelection(new StructuredSelection(dataModel.getList().get(0)));
    }

    private TestModel generateNewDataModelItem()
    {
        // generate Geschlechtscode
        Gender geschlecht = null;
        switch ((int) (Math.random() * 10000) % 3)
        {
            case 0:
                geschlecht = Gender.FEMALE;
                break;
            case 1:
                geschlecht = Gender.MALE;
                break;
            default:
                geschlecht = Gender.UNKNOWN;
                break;
        }

        return new TestModel("Mueller - " + (int) (Math.random() * 1000), new Date((long) (Math
                .random() * 1100000000000L)), (int) (Math.random() * 1000) % 2 == 0 ? true : false,
                (int) (Math.random() * 1000) % 5, Math.random() * 10000, geschlecht, (int) (Math
                        .random() * 1000) % 2 == 0 ? true : false);
    }
    
    public void expandPart(boolean doExpand)
    {
        this.mainSection.getSWTSection().setExpanded(doExpand);
    }

    public static void main(String[] args)
    {
        final TableModel model = new TableModel();
        final RCPFormPart part = new SandboxListPart();
        RCPFormFactory.getInstance().startTestShell("SandboxListPart", part, model);
    }

    @Override
    public void setState(EControlState state, boolean value)
    {
        mainSection.setState(state, value);
    }
}
