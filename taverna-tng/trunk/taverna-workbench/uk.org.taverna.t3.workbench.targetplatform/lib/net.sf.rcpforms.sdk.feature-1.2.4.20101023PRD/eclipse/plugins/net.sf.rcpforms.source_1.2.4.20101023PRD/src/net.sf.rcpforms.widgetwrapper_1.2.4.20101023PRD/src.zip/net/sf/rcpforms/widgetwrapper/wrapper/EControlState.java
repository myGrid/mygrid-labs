/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */
// Created on 08.02.2008

package net.sf.rcpforms.widgetwrapper.wrapper;

import net.sf.rcpforms.widgetwrapper.statehandling.WidgetStateManager;

/**
 * enumeration listing all available rcp control states.
 * <p>
 * Helper methods to encode the state bitwise into an integer.
 * For CUSTOM States 1-5: Rendering is intended to be done by api clients.
 * For usage see {@link WidgetStateManager} how to enable customized rendering for this states.
 * 
 * 
 * @author Marco van Meegen
 * @author Remo Loetscher
 */
public enum EControlState {
    VISIBLE(1), ENABLED(2), READONLY(4), MANDATORY(8), RECOMMENDED(16), OTHER(32),
    INFO(64), CUSTOM_1(128), CUSTOM_2(256), CUSTOM_3(512), CUSTOM_4(1024), CUSTOM_5(2048);

    private int stateBit;

    EControlState(int flag)
    {
        this.stateBit = flag;
    }

    public static boolean isMember(EControlState controlState, int stateBits)
    {
        return (controlState.stateBit & stateBits) != 0;
    }

    public static int getFlags(EControlState... controlStates)
    {
        int result = 0;
        for (EControlState controlState : controlStates)
        {
            result |= controlState.stateBit;
        }
        return result;
    }

    /**
     * modifies the state in the given stateBits
     * 
     * @param state state to modify
     * @param set true: set the state, false: reset the state
     * @param stateBits stateBits to modify
     * @return modified stateBits
     */
    public static int modifyState(EControlState state, boolean set, int stateBits)
    {
        int result;
        if (set)
        {
            result = stateBits | state.stateBit;
        }
        else
        {
            result = (~state.stateBit) & stateBits;
        }
        return result;
    }
}
