package net.sf.rcpforms.examples.complete.widgets.composite;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.examples.complete.models.PersonDataModel;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPComposite;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;

import org.eclipse.ui.forms.widgets.FormToolkit;

public class RCPPersonComposite extends RCPComposite {

    private RCPText name;
    private RCPText firstName;
    private RCPText street;
    private RCPText streetNumber;
    private RCPText city;
    private RCPText country;
    private RCPText birthdate;
    
	@Override
	public void createUI(FormToolkit formToolkit) {
		// TODO Auto-generated method stub
		super.createUI(formToolkit);
		
		name = new RCPText("Composite_Name: ");
		name.setState(EControlState.READONLY, true);
        firstName = new RCPText("Composite_Firstname: ");
        firstName.setState(EControlState.READONLY, true);
        street = new RCPText("Composite_Street/Number: ");
        street.setState(EControlState.READONLY, true);
        streetNumber = new RCPText(null);
        streetNumber.setState(EControlState.READONLY, true);
        city = new RCPText("Composite_City: ");
        city.setState(EControlState.READONLY, true);
        country = new RCPText("Composite_Country: ");
        country.setState(EControlState.READONLY, true);
        birthdate = new RCPText("Composite_Birthdate: ");
        birthdate.setState(EControlState.READONLY, true);
        
        //add elements to container
        GridBuilder compositeBuilder = new GridBuilder(formToolkit, getClientComposite(), 3);
        //1st line
        compositeBuilder.addLineGrabAndFill(name, 2);
        //2nd line
        compositeBuilder.addLine(firstName);
        //3rd line
        compositeBuilder.add(street);
        compositeBuilder.add(streetNumber);
        compositeBuilder.fillLine();
        //4th line
        compositeBuilder.addLine(city);
        //5th line
        compositeBuilder.addLineGrabAndFill(country, 2);
        //6th line
        compositeBuilder.addLine(birthdate);
	}
	
	public void bindComposite(ValidationManager vm, PersonDataModel model)
	{
		vm.bindValue(name, model, PersonDataModel.P_Name);
		vm.bindValue(firstName, model, PersonDataModel.P_FirstName);
		vm.bindValue(street, model, PersonDataModel.P_Street);
		vm.bindValue(streetNumber, model, PersonDataModel.P_StreetNumber);
		vm.bindValue(city, model, PersonDataModel.P_City);
		vm.bindValue(country, model, PersonDataModel.P_Country);
		vm.bindValue(birthdate, model, PersonDataModel.P_Birthdate);
	}
	
	

}
