/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.complete.formparts;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.common.NullValue;
import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.examples.complete.IExpandablePart;
import net.sf.rcpforms.examples.complete.models.TableModel;
import net.sf.rcpforms.examples.complete.models.TestModel;
import net.sf.rcpforms.examples.complete.models.TestModel.Gender;
import net.sf.rcpforms.modeladapter.configuration.BeanAdapter;
import net.sf.rcpforms.tablesupport.tables.ColumnConfiguration;
import net.sf.rcpforms.tablesupport.tables.ECellEditorType;
import net.sf.rcpforms.tablesupport.tables.RCPTableData;
import net.sf.rcpforms.tablesupport.tables.TableUtil;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPCheckboxTable;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPList;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * Example part demonstrating the advanced table features of RCPForms.
 * <p>
 * <ul>
 * <li>binding of multi selection state of a normal table to a list
 * <li>automatic creation of a table cursor if the table contains editable columns
 * <li>disabled rows if {@link RCPTableFormToolkit} is used
 * </ul>
 * 
 * @author Remo Loetscher
 */
public class SandboxDualListSelectionPart extends RCPFormPart
implements IExpandablePart
{
    private RCPSection mainSection;

    private RCPCheckboxTable m_CheckboxTable;

    private TableViewer m_CheckboxTableViewer;
    
    private RCPList m_SelectedElements;

    private TableModel dataModel;

    private boolean minimizeSection;

    public SandboxDualListSelectionPart()
    {
        m_CheckboxTable = new RCPCheckboxTable("CheckboxTable:");
        m_SelectedElements = new RCPList("SelectedElements: ", SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
    }
    
    public SandboxDualListSelectionPart(boolean minimizeSection)
    {
        this();
        this.minimizeSection = minimizeSection;
    }
    
    private static ColumnConfiguration[] createColumnConfigurations(boolean editable)
    {
        // this configures the table with the attributes to display;
        // automatic conversion will be applied using the standard data binding converters
        // which are used in text fields too
        Object[] values = new Object[Gender.values().length + 1];
        // add null value
        values[0] = NullValue.getInstance();
        System.arraycopy(Gender.values(), 0, values, 1, values.length - 1);
        ColumnConfiguration[] columnConfigurations = {
                new ColumnConfiguration("Name", TestModel.P_Name, 100, SWT.LEFT, false,
                        editable ? ECellEditorType.TEXT : null).setGrabHorizontal(true),
                new ColumnConfiguration("Geburtsdatum", TestModel.P_BirthDate, 80, SWT.LEFT, false,
                        editable ? ECellEditorType.DATE : null),
                editable ? new ColumnConfiguration("Geschlecht", TestModel.P_Gender, 60, SWT.LEFT,
                        values) : new ColumnConfiguration("Geschlecht", TestModel.P_Gender, 60,
                        SWT.LEFT),
                new ColumnConfiguration("Konto�berzug", TestModel.P_OverdrawAccount, 50,
                        SWT.CENTER, false, editable ? ECellEditorType.CHECK : null),
                new ColumnConfiguration("Kinder", TestModel.P_ChildCount, 50, SWT.RIGHT, false,
                        editable ? ECellEditorType.TEXT : null),
                new ColumnConfiguration("Kontostand", TestModel.P_AccountBalance, 70, SWT.RIGHT,
                        false, editable ? ECellEditorType.TEXT : null)};
        Validate.noNullElements(columnConfigurations,
                "ColumnConfigurations must not have null elements");
        return columnConfigurations;
    }

    @Override
    public void createUI(FormToolkit formToolkit, Composite parent)
    {
        GridBuilder builder = new GridBuilder(formToolkit, parent, 1);
        mainSection = new RCPSection("Sandbox Bind Selection to List Part");
        GridBuilder sectionBuilder = builder.addContainer(mainSection, 4);

        if(minimizeSection)
            mainSection.getSWTSection().setExpanded(false);
        
        // create Checkbox Table
        sectionBuilder.add(m_CheckboxTable);
        
        RCPTableData tableData = new RCPTableData();
        tableData.columnConfigurations = createColumnConfigurations(false);
        tableData.enableSeparateCheckboxColumn = false;
        tableData.enableTableCursorSupport = false;
        
        m_CheckboxTableViewer = TableUtil.configureTableViewer((TableViewer) m_CheckboxTable
                .getViewer(), TestModel.class, tableData);

        sectionBuilder.add(m_SelectedElements);
        GridData gd = (GridData) m_SelectedElements.getMainControl().getSWTControl().getLayoutData();
        gd.grabExcessVerticalSpace = true;
        gd.verticalAlignment = SWT.FILL;
        gd.grabExcessHorizontalSpace = true;
        gd.horizontalAlignment = SWT.FILL;
        m_SelectedElements.getViewer().setContentProvider(BeanAdapter.getInstance().createDefaultContentProvider());
        m_SelectedElements.getViewer().setLabelProvider(new LabelProvider(){

            @Override
            public String getText(Object element)
            {
                TestModel mod = (TestModel)element;
                return mod.getName() + " " + mod.getBirthDate();
            }});
        
    }

    @Override
    public void bind(ValidationManager context, Object modelBean)
    {
        Validate.isTrue(modelBean instanceof TableModel);
        this.dataModel = (TableModel) modelBean;

        // set the CheckboxViewer's input
        m_CheckboxTableViewer.setInput(dataModel.getList());

        // bind selection to table; if its checkbox table, the check state is bound,
        // otherwise the multi selection of rows.
        context.bindSelection(BeanAdapter.getInstance(), m_CheckboxTable, dataModel.getSelectedList());

        m_SelectedElements.getViewer().setInput(dataModel.getSelectedList());
    }

    public void expandPart(boolean doExpand)
    {
        this.mainSection.getSWTSection().setExpanded(doExpand);
    }

    public static void main(String[] args)
    {
        final TableModel model = new TableModel();
        final RCPFormPart part = new SandboxDualListSelectionPart();
        RCPFormFactory.getInstance().startTestShell("SandboxTableSelectionPart", part, model);
    }

    @Override
    public void setState(EControlState state, boolean value)
    {
        mainSection.setState(state, value);

    }
}
