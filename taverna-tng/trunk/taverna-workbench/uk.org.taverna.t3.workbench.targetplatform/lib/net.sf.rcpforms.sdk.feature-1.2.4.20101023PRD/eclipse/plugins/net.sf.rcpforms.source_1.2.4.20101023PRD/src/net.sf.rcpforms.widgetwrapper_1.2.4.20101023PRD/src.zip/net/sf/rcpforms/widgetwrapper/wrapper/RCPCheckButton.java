/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */
// Created on 15.01.2008

package net.sf.rcpforms.widgetwrapper.wrapper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;


/**
 * a compound of a label and a {@link RCPSimpleButton} with {@link SWT#CHECK} style.<br>
 * <b>Note:</b>This class has a confusing implementation name of the check box which is not following the
 * common naming pattern. So it was refactored to a labeled control.<br>
 * The origin implementation class is still {@link RCPCheckButton} which is NOT a labeled Control!<br>
 * FIXME Version 2.0: Synchronise to RCPFroms naming pattern.
 * 
 * @author Remo Loetscher
 */
public class RCPCheckButton extends RCPLabeledControl<RCPSimpleButton>
{
    public RCPCheckButton(String label)
    {
        this(label, SWT.CHECK);
    }

    public RCPCheckButton(String label, int style)
    {
        super(label, new RCPSimpleButton("", style | SWT.CHECK));
    }

    public final Button getSWTButton()
    {
        return getRCPControl().getSWTButton();
    }

}