/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.form;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.rcpforms.common.util.Validate;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

/**
 * Class RCPFormEditorPart embeds an RCPForm into an Eclipse Editor.
 * <p>
 * Usage:
 * 
 * <pre>
 * public class XYEditor extends RCPFormEditorPart&lt;SandboxStackForm&gt;
 * {
 *     public static final String ID = &quot;net.sf.rcpforms.examples.app.editorw&quot;;
 * 
 *     public XYEditor()
 *     {
 *         super(new SandboxStackForm());
 *     }
 * }
 * </pre>
 * 
 * You need to subclass the RCPFormEditorPart for being able to declare it in an extension point.
 * 
 * @author Remo Loetscher
 */
public abstract class RCPFormEditorPart<T extends RCPForm> extends EditorPart
{
    T form = null;

    private boolean dirtyFlag = false;

    private static final Logger LOG = Logger.getLogger(RCPFormEditorPart.class.getName());

    private PropertyChangeListener dirtyChangeListener = new PropertyChangeListener()
    {

        public void propertyChange(PropertyChangeEvent evt)
        {
            RCPFormEditorPart.this.setDirty(true);
        }
    };

    /**
     * @return Returns the form.
     */
    public T getForm()
    {
        return form;
    }

    /**
     * creates a view part around a form
     */
    public RCPFormEditorPart(T form)
    {
        this.form = form;
    }

    /**
     * create the form
     */
    public void createPartControl(Composite parent)
    {
        form.createUI(parent);
    }

    /**
     * Pass the focus request to the form
     */
    public void setFocus()
    {
        form.setFocus();
    }

    /*
     * ATTENTION: input has to be of type IRCPFormEditorInput
     * @see org.eclipse.ui.part.EditorPart#init(org.eclipse.ui.IEditorSite, org.eclipse.ui.IEditorInput)
     */
    @Override
    public void init(IEditorSite site, IEditorInput input) throws PartInitException
    {
        this.setSite(site);
        Validate.isTrue(input instanceof IRCPFormEditorInput,
                "Input in RCPFormEditorPart has to implement Interface IRCPFormEditorInput"); //$NON-NLS-1$
        this.setInput(input);
    }

    protected void setDirty(boolean value)
    {
        if (this.dirtyFlag == value)
            return;
        dirtyFlag = value;
        firePropertyChange(PROP_DIRTY);
    }

    /* (non-Javadoc)
     * @see org.eclipse.ui.part.EditorPart#setInput(org.eclipse.ui.IEditorInput)
     */
    public void setInput(IEditorInput input)
    {
        Validate.isTrue(input instanceof IRCPFormEditorInput,
            "Input in RCPFormEditorPart has to implement Interface IRCPFormEditorInput"); //$NON-NLS-1$
        IEditorInput oldGenericInput = this.getEditorInput();
        IRCPFormEditorInput oldInput = (IRCPFormEditorInput) oldGenericInput;
        IRCPFormEditorInput newInput = (IRCPFormEditorInput) input;
        
        this.initializeDirtyChangeListener(oldInput, newInput);
        super.setInput(newInput);
        form.setInput(newInput.getModels());
        this.setDirty(false);
    }
    
    /**
     * Initialize generic PropertyChangeListeners to set the dirty state to true if a property of
     * the {@link IRCPFormEditorInput#getModels()} model changes. Note that only property change
     * listener for the top level models are registered. If you need property change support for
     * nested properties you may want to overwrite this method. But pay attention to unregister
     * PropertyChangeListener if you register it yourself.
     * 
     * @param oldInput registered PropertyChangeListener for top level models are automatically
     *            unregistered. see {@link RCPFormEditorPart#removeDirtyChangeListener(Object)}. Can
     *            be null.
     * @param newInput registers PropertyChangeListener for the new input top level models. see
     *            {@link RCPFormEditorPart#addDirtyChangeListener(Object)}. Not null.
     */
    protected void initializeDirtyChangeListener(IRCPFormEditorInput oldInput,
                                                 IRCPFormEditorInput newInput)
    {
        Validate.notNull(newInput);
        // remove old PropertyChangeListeners
        if (oldInput != null)
        {
            for (Object o : oldInput.getModels())
            {
                this.removeDirtyChangeListener(o);
            }
        }
        // add PropertyChangeListeners
        for (Object o : newInput.getModels())
        {
            this.addDirtyChangeListener(o);
        }
    }

    /**
     * Registers a PropertyChangeListener. If you use this method don't forget to unregister the
     * listener if input change.
     * 
     * @param o object to register a PropertyChangeListener on it. Note that the Object must provide
     *            a method called addPropertyChangeListener which takes a parameter of type
     *            {@link PropertyChangeListener}
     * @return true if registration was successful, otherwise false.
     */
    public boolean addDirtyChangeListener(Object o)
    {
        return this.processListener("addPropertyChangeListener", //$NON-NLS-1$
                "Could not add PropertyChangeListener to ", o); //$NON-NLS-1$
    }

    /**
     * Unregisters a PropertyChangeListener. Use this method if you have registered a
     * PropertyChangeListener using {#link {@link RCPFormEditorPart#addDirtyChangeListener(Object)}.
     * 
     * @param o object to unregister a PropertyChangeListener on it. Note that the Object must provide
     *            a method called removePropertyChangeListener which takes a parameter of type
     *            {@link PropertyChangeListener}
     * @return true if unregistration was successful, otherwise false.
     */
    public boolean removeDirtyChangeListener(Object o)
    {
        return this.processListener("removePropertyChangeListener", //$NON-NLS-1$
                "Could not remove PropertyChangeListener from ", o); //$NON-NLS-1$
    }

    @Override
    public boolean isDirty()
    {
        return dirtyFlag;
    }

    /**
     * Invokes the method for the provided <code>methodName</code> attempting to first use the
     * method with the property name and then the unnamed version.
     * 
     * @param methodName either addPropertyChangeListener or removePropertyChangeListener
     * @param message string that will be prefixed to the target in an error message
     * @param target object to invoke the method on
     * @return <code>true</code> if the method was invoked successfully
     */
    private boolean processListener(String methodName, String message, Object target)
    {
        Method method = null;
        Object[] parameters = null;

        try
        {
            method = target.getClass().getMethod(methodName,
                    new Class[]{PropertyChangeListener.class});

            parameters = new Object[]{dirtyChangeListener};
        }
        catch (SecurityException e)
        {
            LOG.log(Level.WARNING, message + target, e.getMessage());
        }
        catch (NoSuchMethodException e)
        {
            LOG.log(Level.WARNING, message + target, e.getMessage());
        }

        if (method != null)
        {
            if (!method.isAccessible())
            {
                method.setAccessible(true);
            }
            try
            {
                method.invoke(target, parameters);
                return true;
            }
            catch (IllegalArgumentException e)
            {
                LOG.log(Level.WARNING, message + target, e.getMessage());
            }
            catch (IllegalAccessException e)
            {
                LOG.log(Level.WARNING, message + target, e.getMessage());
            }
            catch (InvocationTargetException e)
            {
                LOG.log(Level.WARNING, message + target, e.getMessage());
            }
        }
        return false;
    }
    
    public void dispose()
    {
        IRCPFormEditorInput input = (IRCPFormEditorInput) this.getEditorInput();
        // remove PropertyChangeListeners from model
        if (input != null)
        {
            for (Object o : input.getModels())
            {
                if(o != null)
                    this.removeDirtyChangeListener(o);
            }
        }
    }
}