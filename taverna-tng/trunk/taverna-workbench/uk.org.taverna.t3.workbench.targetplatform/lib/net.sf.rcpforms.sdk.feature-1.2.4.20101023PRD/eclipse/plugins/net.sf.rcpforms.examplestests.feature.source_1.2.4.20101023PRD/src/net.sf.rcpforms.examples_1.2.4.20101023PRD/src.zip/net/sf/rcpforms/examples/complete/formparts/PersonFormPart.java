package net.sf.rcpforms.examples.complete.formparts;

import java.util.Date;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.examples.complete.models.PersonDataModel;
import net.sf.rcpforms.examples.complete.widgets.composite.RCPPersonComposite;
import net.sf.rcpforms.examples.complete.widgets.compound.RCPPersonCompound;
import net.sf.rcpforms.modeladapter.converter.AbstractModelValidator;
import net.sf.rcpforms.modeladapter.converter.RequiredValidator;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.customwidgets.RCPDatePicker;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPCombo;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPComposite;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleLabel;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class PersonFormPart extends RCPFormPart
{

    /**
     * Class DateFutureValidator is an example for a custom validator
     * 
     * @author Remo Loetscher
     */
    public static final class DateFutureValidator extends AbstractModelValidator
    {
        public Object[] getProperties()
        {
            return new String[]{PersonDataModel.P_Birthdate};
        }

        public IStatus validate(Object value)
        {
            PersonDataModel model = (PersonDataModel) value;
            IStatus result = ok();
            if (model.getBirthdate() != null && model.getBirthdate().after(new Date()))
            {
                result = error("Birthdate has to be in the past!");
            }
            return result;
        }
    }

    private RCPComposite section;

    private RCPText name;

    private RCPText firstName;

    private RCPText street;

    private RCPText streetNumber;

    private RCPText city;

    private RCPCombo country;

    private RCPText birthdate;
    
    private RCPDatePicker datePicker ;

    private RCPPersonComposite pc;
    
    private RCPPersonCompound compound;

    private GridBuilder formPartBuilder;

    @Override
    public void bind(ValidationManager bm, Object modelBean)
    {
        bm.bindValue(name, modelBean, PersonDataModel.P_Name);
        bm.bindValue(firstName, modelBean, PersonDataModel.P_FirstName);
        bm.bindValue(street, modelBean, PersonDataModel.P_Street);
        bm.bindValue(streetNumber, modelBean, PersonDataModel.P_StreetNumber);
        bm.bindValue(city, modelBean, PersonDataModel.P_City);
        bm.bindValue(country, modelBean, PersonDataModel.P_Country);
        bm.bindValue(birthdate, modelBean, PersonDataModel.P_Birthdate);

        bm.bindValue(datePicker, modelBean, PersonDataModel.P_Birthdate);
        
        // add required validator
        bm.addValidator(this, new RequiredValidator(PersonDataModel.P_Name,
                PersonDataModel.P_FirstName, PersonDataModel.P_Birthdate));

        // add date validator
        bm.addValidator(this, new DateFutureValidator());
        
        //bind composite
//        pc.bindComposite(bm, (PersonDataModel)modelBean);
        
        //bind compound
//        compound.bindCompound(bm, (PersonDataModel)modelBean);
    }

    @Override
    public void createUI(FormToolkit toolkit, Composite parent)
    {
        // create RCPForm elements
//        section = new RCPSection("This title will be invisible", Section.NO_TITLE);
        section = new RCPComposite();
        name = new RCPText("Name: ");
        name.setState(EControlState.MANDATORY, true);
        firstName = new RCPText("Firstname: ");
        firstName.setState(EControlState.MANDATORY, true);
        street = new RCPText("Street/Number: ");
        streetNumber = new RCPText(null);
        city = new RCPText("City: ");
        country = new RCPCombo("Country: ");
        birthdate = new RCPText("Birthdate: ");
        birthdate.setState(EControlState.MANDATORY, true);

        // add elements to container
        formPartBuilder = new GridBuilder(toolkit, parent, 1);
        GridBuilder sectionBuilder = formPartBuilder.addContainer(section, 4);
        // 1st line
        sectionBuilder.addLineGrabAndFill(name, 3);
        // 2nd line
        sectionBuilder.addLine(firstName);
        // 3rd line
        sectionBuilder.add(street);
        sectionBuilder.add(streetNumber);
        sectionBuilder.fillLine();
        // 4th line
        sectionBuilder.addLine(city);
        // 5th line
        sectionBuilder.addLine(country);
        // 6th line
        sectionBuilder.addLine(birthdate, 10);
        sectionBuilder.fillLine();
        
        RCPComposite pickerComposite = new RCPComposite();
        datePicker = new RCPDatePicker("");
        datePicker.setState(EControlState.MANDATORY, true);
        RCPSimpleLabel simpleLabel = new RCPSimpleLabel("Date: ");
        sectionBuilder.add(simpleLabel);
        GridData gd = new GridData();
        gd.horizontalAlignment = SWT.END;
        simpleLabel.setLayoutData(gd);
        GridBuilder datePickerBuilder = sectionBuilder.addAlignedContainer(pickerComposite, 2, 3);
        GridLayout gl = new GridLayout(3, false);
        gl.marginWidth = 0;
        gl.marginHeight = 0;
        gl.horizontalSpacing = 5;
        gl.verticalSpacing = 5;
//        gd.horizontalSpan = 1;
//        pickerComposite.setLayout(gl);
        gd = new GridData();
        gd.horizontalAlignment = SWT.FILL;
        gd.horizontalSpan = 3;
        gd.grabExcessHorizontalSpace = true;
        //only 7 not 8 because of the border of the first child -> if parent indent is 8 and child is 0 -> border woun't be painted!
//        gd.horizontalIndent = 7;
        gd.horizontalIndent = 0;
//        pickerComposite.setLayoutData(gd);
        
        datePickerBuilder.add(datePicker);
        datePicker.getText().getRCPHyperlink().setVisible(false);
        gd = new GridData();
        gd.horizontalAlignment = SWT.FILL;
        gd.grabExcessHorizontalSpace = true;
        //set 1 indent to have border painted!
//        gd.horizontalIndent = 1;
        gd.horizontalIndent = 8;
//        datePicker.setLayoutData(gd);
        
        //Composite creation
//        pc = new RCPPersonComposite();
//        sectionBuilder.addLine(pc);
        
        //Compound creation
//        compound = new RCPPersonCompound();
//        sectionBuilder.add(compound);
    }

    @Override
    public void setState(EControlState state, boolean value)
    {
        section.setState(state, value);
    }

    public void dispose()
    {
        section.dispose();
    }

}
