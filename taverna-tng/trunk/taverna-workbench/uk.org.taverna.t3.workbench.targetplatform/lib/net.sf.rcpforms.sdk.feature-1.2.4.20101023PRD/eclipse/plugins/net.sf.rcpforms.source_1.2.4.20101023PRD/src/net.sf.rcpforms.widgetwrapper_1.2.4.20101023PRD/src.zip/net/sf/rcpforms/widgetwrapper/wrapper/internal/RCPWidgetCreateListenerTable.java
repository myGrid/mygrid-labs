/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.widgetwrapper.wrapper.internal;

/*******************************************************************************
 * Copyright (c) 2000, 2008 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation. Copied and modified from org.eclipse.swt.widgets.EventTable
 *******************************************************************************/

import net.sf.rcpforms.widgetwrapper.wrapper.event.IWidgetCreationListener;
import net.sf.rcpforms.widgetwrapper.wrapper.event.WidgetCreationEvent;


public class RCPWidgetCreateListenerTable
{
    IWidgetCreationListener[] listeners;

    int level;

    static final int GROW_SIZE = 4;

    public IWidgetCreationListener[] getCreationListeners()
    {
        if (listeners == null)
            return new IWidgetCreationListener[0];
        return listeners;
    }

    public void hook(IWidgetCreationListener listener)
    {
        if (listeners == null)
            listeners = new IWidgetCreationListener[GROW_SIZE];
        int length = listeners.length, index = length - 1;
        while (index >= 0)
        {
            if (listeners[index] != null)
                break;
            --index;
        }
        index++;
        if (index == length)
        {
            IWidgetCreationListener[] newListeners = new IWidgetCreationListener[length + GROW_SIZE];
            System.arraycopy(listeners, 0, newListeners, 0, length);
            listeners = newListeners;
        }
        listeners[index] = listener;
    }

    public void sendEvent(WidgetCreationEvent event)
    {
        if (listeners == null)
            return;
        level += level >= 0 ? 1 : -1;
        try
        {
            for (int i = 0; i < listeners.length; i++)
            {
                IWidgetCreationListener listener = listeners[i];
                    if (listener != null)
                        listener.widgetCreated(event);
            }
        }
        finally
        {
            boolean compact = level < 0;
            level -= level >= 0 ? 1 : -1;
            if (compact && level == 0)
            {
                int index = 0;
                for (int i = 0; i < listeners.length; i++)
                {
                    if (listeners[i] != null)
                    {
                        listeners[index] = listeners[i];
                        index++;
                    }
                }
                for (int i = index; i < listeners.length; i++)
                {
                    listeners[i] = null;
                }
            }
        }
    }

    public int size()
    {
        if (listeners == null)
            return 0;
        int count = 0;
        for (int i = 0; i < listeners.length; i++)
        {
            if (listeners[i] != null)
                count++;
        }
        return count;
    }

    void remove(int index)
    {
        if (level == 0)
        {
            int end = listeners.length - 1;
            System.arraycopy(listeners, index + 1, listeners, index, end - index);
            index = end;
        }
        else
        {
            if (level > 0)
                level = -level;
        }
        listeners[index] = null;
    }

    public void unhook(IWidgetCreationListener listener)
    {
        if (listeners == null)
            return;
        for (int i = 0; i < listeners.length; i++)
        {
            if (listeners[i] == listener)
            {
                remove(i);
                return;
            }
        }
    }
}
