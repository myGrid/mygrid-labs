package net.sf.rcpforms.widgetwrapper.wrapper;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

/**
 * This type is a <b><i>new</i></b> (<code>1.1</code>) base-type for any control
 * that supports bean-like binding of its property -- rendering <code>SWTObservables</code>
 * obsolete. 
 * NOTE: THIS IS PROVISIONAL API AND NOT INTENDEND TO BE USED AT THE MOMENT   
 * 
 * @author Christian Spicher
 * @since 1.1
 */
public class RCPBeanControl extends RCPControl
{
    
    private PropertyChangeSupport changeSupport = null;

    public RCPBeanControl(final String labelText, final int style)
    {
        super(labelText, style);
    }
    
     
    ///////////////////////////////////////////////////////////////////////////////////
    ///  BEAN LIKE BINDING :
    ///////////////////////////////////////////////////////////////////////////////////

    
    private void initBeanSupport()
    {
        changeSupport = new PropertyChangeSupport(this);
        subInitBeanSupport();
    }
    
    /** May be overwritten to init additional listeners. If so, dont forget
     * to overwrite subUnlinkBeanSupport as well! */
    protected void subInitBeanSupport() {
        // none per default
    }
    
    /** Must remove everything attached in subInitBeanSupport. */
    protected void subUnlinkBeanSupport() {
        // none per default
    }
    
    @Override
    public void dispose()
    {
        subUnlinkBeanSupport();
        super.dispose();
    }
    
    
    protected void firePropertyChange(final String propertName, final Object newValue, final Object oldValue) {
        changeSupport.firePropertyChange(propertName, oldValue, newValue);
    }

    protected void firePropertyChange(final String propertName, final boolean newValue, final boolean oldValue) {
        changeSupport.firePropertyChange(propertName, oldValue, newValue);
    }

    protected void firePropertyChange(final String propertName, final int newValue, final int oldValue) {
        changeSupport.firePropertyChange(propertName, oldValue, newValue);
    }

     
    public void addPropertyChangeListener(final PropertyChangeListener listener)
    {
        initBeanSupport();
        changeSupport.addPropertyChangeListener(listener);
    }

    public void addPropertyChangeListener(final String propertyName, final PropertyChangeListener listener)
    {
        initBeanSupport();
        changeSupport.addPropertyChangeListener(propertyName, listener);
    }

    public void removePropertyChangeListener(final PropertyChangeListener listener)
    {
        if (changeSupport != null) {
            changeSupport.removePropertyChangeListener(listener);
        }
    }

    public void removePropertyChangeListener(final String propertyName, final PropertyChangeListener listener)
    {
        if (changeSupport != null) {
            changeSupport.removePropertyChangeListener(propertyName, listener);
        }
    }
        
    

}
