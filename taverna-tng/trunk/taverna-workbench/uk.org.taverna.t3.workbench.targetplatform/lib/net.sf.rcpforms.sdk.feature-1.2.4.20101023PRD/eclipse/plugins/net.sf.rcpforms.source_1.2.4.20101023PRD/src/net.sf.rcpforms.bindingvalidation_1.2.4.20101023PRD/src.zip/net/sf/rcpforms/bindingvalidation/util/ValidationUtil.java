/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.bindingvalidation.util;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;

public class ValidationUtil {
    
    public static List<IStatus> flattenStatus(final IStatus status) {
        return flattenStatus(status, IStatus.OK, IStatus.CANCEL);
    }
    
    /**
     * Flattens (Multi-)Stati to flat list. Adds only Stati whose status-code
     * is between <code>minSeverity</code> and <code>maxSeverity</code> (both
     * inclusive) 
     * 
     * @param status 
     * @param minSeverity 
     * @param maxSeverity 
     * 
     * @return list of flattened stati.
     */
    public static List<IStatus> flattenStatus(final IStatus status, final int minSeverity, final int maxSeverity) {
        ArrayList<IStatus> result = new ArrayList<IStatus>();
        privFlattenStatus(status, result, minSeverity, maxSeverity);
        return result;      
    }
    
    private static void privFlattenStatus(final IStatus status, final List<IStatus> list, final int minSeverity, final int maxSeverity) {
        if (status instanceof MultiStatus) {
            MultiStatus multi = (MultiStatus) status;
            IStatus[] children = multi.getChildren();
            for (IStatus child : children) {
                privFlattenStatus(child, list, minSeverity, maxSeverity);
            }
        } else {
            int code = status.getSeverity();
            if (code >= minSeverity && code <= maxSeverity) {
                list.add(status);
            }
        }
    }

}

