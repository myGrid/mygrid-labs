/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.widgetwrapper.wrapper;

import net.sf.rcpforms.bindingvalidation.BindingBaseTestCase;
import net.sf.rcpforms.widgetwrapper.builder.GridLayoutFactory;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPWidget;
import net.sf.rcpforms.widgetwrapper.wrapper.event.IWidgetCreationListener;
import net.sf.rcpforms.widgetwrapper.wrapper.event.WidgetCreationEvent;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * UI Test for testing bindings of a widget against supported types of nested model
 * values. The following is tested:
 * <ul>
 * <li>setting unique id
 * <li>setting custom property
 * </ul>
 * 
 * @author Remo Loetscher
 */
public class RCPWidgetTest extends BindingBaseTestCase
{
    private static final String LABEL = "Control:";
    private static final String ID = "test.id";
    
    public void testUID() throws Exception
    {
        RCPControl control = new RCPControl(LABEL, SWT.NONE, ID) {
            
            protected Widget createWrappedWidget(FormToolkit formToolkit)
            {
                return formToolkit.createButton(getSWTParent(), "Test", SWT.PUSH);
            }
        };
        assertEquals(ID, control.getUID());
        assertEquals(ID, control.getUIDString());
        assertEquals(ID, control.getCustomProperty(RCPWidget.UID));
        assertEquals(ID, control.getCustomProperty(String.class, RCPWidget.UID));
        builder.add(control);
        assertEquals(ID, control.getUID());
        assertEquals(ID, control.getUIDString());
        assertEquals(ID, control.getCustomProperty(RCPWidget.UID));
        assertEquals(ID, control.getCustomProperty(String.class, RCPWidget.UID));
        assertEquals(ID, control.getSWTWidget().getData(RCPWidget.UID));
        
    }    

    public void testSettingUID() throws Exception
    {
        RCPText widget = new RCPText(LABEL);
        widget.setUID(ID);
        assertEquals(ID, widget.getUID());
        assertEquals(ID, widget.getUIDString());
        assertEquals(ID, widget.getCustomProperty(RCPWidget.UID));
        assertEquals(ID, widget.getCustomProperty(String.class, RCPWidget.UID));
        builder.add(widget);
        assertEquals(ID, widget.getUID());
        assertEquals(ID, widget.getUIDString());
        assertEquals(ID, widget.getCustomProperty(RCPWidget.UID));
        assertEquals(ID, widget.getCustomProperty(String.class, RCPWidget.UID));
        assertEquals(ID, widget.getWrappedWidget().getData(RCPWidget.UID));
    }
    
    public void testCustomProperty()
    {
        String propKey = "key";
        Object propValue = Boolean.TRUE;
        RCPText widget = new RCPText(LABEL);
        widget.setCustomProperty(propKey, propValue);
        assertEquals(propValue, widget.getCustomProperty(propKey));
        assertEquals(propValue, widget.getCustomProperty(propValue.getClass(), propKey));
        builder.add(widget);
        assertEquals(propValue, widget.getCustomProperty(propKey));
        assertEquals(propValue, widget.getCustomProperty(propValue.getClass(), propKey));
        assertEquals(propValue, widget.getWrappedWidget().getData(propKey));
    }

    public void testUIDandCustomProperty()
    {
        String propKey = "key";
        Object propValue = Boolean.TRUE;
        RCPText widget = new RCPText(LABEL);
        widget.setCustomProperty(propKey, propValue);
        assertEquals(propValue, widget.getCustomProperty(propKey));
        assertEquals(propValue, widget.getCustomProperty(propValue.getClass(), propKey));
        widget.setUID(ID);
        assertEquals(ID, widget.getUID());
        assertEquals(ID, widget.getUIDString());
        assertEquals(ID, widget.getCustomProperty(RCPWidget.UID));
        assertEquals(ID, widget.getCustomProperty(String.class, RCPWidget.UID));
        builder.add(widget);
        assertEquals(propValue, widget.getCustomProperty(propKey));
        assertEquals(propValue, widget.getCustomProperty(propValue.getClass(), propKey));
        assertEquals(propValue, widget.getWrappedWidget().getData(propKey));
        assertEquals(ID, widget.getUID());
        assertEquals(ID, widget.getUIDString());
        assertEquals(ID, widget.getCustomProperty(RCPWidget.UID));
        assertEquals(ID, widget.getCustomProperty(String.class, RCPWidget.UID));
        assertEquals(ID, widget.getWrappedWidget().getData(RCPWidget.UID));
        
    }
    
    public void testSetUIDShortened()
    {
        RCPText widget = new RCPText("ShortenText").setUID("uid");
    }
//    public void testTooltip()
//    {
//        String toolTip = "HelloWorld-ToolTip!";
//        RCPText widget = new RCPText(LABEL);
//        widget.setTooltip(toolTip);
//        builder.add(widget);
//        assertEquals(toolTip, widget.getSWTControl().getToolTipText());
//    }
    
    public void testEnabledState()
    {
        boolean state = false;
        RCPText widget = new RCPText(LABEL);
        widget.setState(EControlState.ENABLED, state);
        assertEquals(state, widget.getRCPControl().getState(EControlState.ENABLED));
        builder.add(widget);
        assertEquals(state, widget.getRCPControl().getState(EControlState.ENABLED));
        assertEquals(state, widget.getSWTText().isEnabled());
    }
    
    public void testVisibleState()
    {
        boolean state = false;
        RCPText widget = new RCPText(LABEL);
        widget.setState(EControlState.VISIBLE, state);
        assertEquals(state, widget.getRCPControl().getState(EControlState.VISIBLE));
        builder.add(widget);
        assertEquals(state, widget.getRCPControl().getState(EControlState.VISIBLE));
        assertEquals(state, widget.getSWTText().isVisible());
    }
    
    public void testMandatoryState()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        assertNull(widget.getMainControl().requiredDecoration);
        widget.setState(EControlState.MANDATORY, state);
        assertEquals(state, widget.getRCPControl().getState(EControlState.MANDATORY));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.MANDATORY));
        builder.add(widget);
        assertNotNull(widget.getMainControl().requiredDecoration);
        assertEquals(state, widget.getRCPControl().getState(EControlState.MANDATORY));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.MANDATORY));

        //reset state and check that required deco is gone
        widget.setState(EControlState.MANDATORY, !state);
        assertNull(widget.getMainControl().requiredDecoration);
    }
    
    public void testInfoState()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        assertNull(widget.getMainControl().informationDecoration);
        widget.setState(EControlState.INFO, state);
        assertEquals(state, widget.getRCPControl().getState(EControlState.INFO));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.INFO));
        builder.add(widget);
        assertNotNull(widget.getMainControl().informationDecoration);
        assertEquals(state, widget.getRCPControl().getState(EControlState.INFO));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.INFO));

        //reset state and check that info deco is gone
        widget.setState(EControlState.INFO, !state);
        assertNull(widget.getMainControl().informationDecoration);
    }
    
    public void testRecommendedState()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        widget.setState(EControlState.RECOMMENDED, state);
        assertEquals(state, widget.getRCPControl().getState(EControlState.RECOMMENDED));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.RECOMMENDED));
        builder.add(widget);
        assertEquals(state, widget.getRCPControl().getState(EControlState.RECOMMENDED));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.RECOMMENDED));
    }
    
    public void testOtherState()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        widget.setState(EControlState.OTHER, state);
        assertNull(widget.getRCPControl().otherDecoration);
        assertEquals(state, widget.getRCPControl().getState(EControlState.OTHER));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.OTHER));
        builder.add(widget);
        assertNotNull(widget.getRCPControl().otherDecoration);
        assertEquals(state, widget.getRCPControl().getState(EControlState.OTHER));
        assertEquals(!state, widget.getRCPHyperlink().getState(EControlState.OTHER));
        
        //reset state and check that other deco is gone
        widget.setState(EControlState.OTHER, !state);
        assertNull(widget.getRCPControl().otherDecoration);
        
    }
    
    public void testCustomState()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        widget.setState(EControlState.CUSTOM_1, state);
        assertEquals(state, widget.getRCPControl().getState(EControlState.CUSTOM_1));
        assertEquals(state, widget.getRCPHyperlink().getState(EControlState.CUSTOM_1));
        builder.add(widget);
        assertEquals(state, widget.getRCPControl().getState(EControlState.CUSTOM_1));
        assertEquals(state, widget.getRCPHyperlink().getState(EControlState.CUSTOM_1));
    }
    
    public void testCustomLayoutData()
    {
        RCPText widget = new RCPText(LABEL);
        GridData gd = GridLayoutFactory.createDefaultLayoutData();
        gd.widthHint = 999;
        gd.heightHint = 999;
        widget.getMainControl().setLayoutData(gd);
        builder.add(widget);
        assertEquals(gd, widget.getRCPControl().getSWTText().getLayoutData());
        assertTrue(gd == widget.getRCPControl().getSWTText().getLayoutData());
    }
    
    public void testLabel()
    {
        RCPText widget = new RCPText(LABEL);

        assertEquals(LABEL, widget.getLabel());
        builder.add(widget);
        assertEquals(LABEL, widget.getLabel());
        assertEquals(LABEL, widget.getRCPHyperlink().getLabel());
    }
    
    public void testEmptyLabel()
    {
        RCPText widget = new RCPText("");
        assertTrue(widget.hasLabel());
        assertNotNull(widget.getRCPHyperlink());
        builder.add(widget);
        assertTrue(widget.hasLabel());
        assertNotNull(widget.getRCPHyperlink());
    }
    
    public void testNullLabel()
    {
        RCPText widget = new RCPText(null);
        assertFalse(widget.hasLabel());
        assertNotNull(widget.getRCPHyperlink());
        builder.add(widget);
        assertFalse(widget.hasLabel());
        assertNotNull(widget.getRCPHyperlink());
    }
    
    public void testWidgetCreationListener()
    {
        WidgetCreationListener wcl = new WidgetCreationListener();
        RCPSimpleText widget = new RCPSimpleText();
//        for(int i = 0; i < 20; ++i)
            widget.addWidgetCreationListener(wcl);
        builder.add(widget);
        assertTrue(wcl.callBack);
        assertEquals(widget.getSWTControl(), wcl.o);
        wcl.callBack = false;
//        for(int i = 0; i < 20; ++i)
            widget.removeWidgetCreationListener(wcl);
        builder.add(widget);
        assertFalse(wcl.callBack);
    }
}

class WidgetCreationListener implements IWidgetCreationListener{

    boolean callBack = false;
    Object o;
    public void widgetCreated(WidgetCreationEvent wce)
    {
        o = wce.getSource();
        callBack = true;
    }
    
}
