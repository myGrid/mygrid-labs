/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.complete;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.examples.complete.formparts.PersonFormPart;
import net.sf.rcpforms.examples.complete.models.PersonDataModel;
import net.sf.rcpforms.form.RCPForm;
import net.sf.rcpforms.modeladapter.util.Validate;

import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * This is the main class of the dispose and rebdinding sample which demonstrates how to dispose and rebind a formpart.
 * <p>
 * 
 * @author Remo Loetscher
 */
public class DisposeRebindStackForm extends RCPForm
{

    private static PersonFormPart pfp;
    private FormToolkit privateToolkit;
    /**
     * Constructor for StackForm
     */
    public DisposeRebindStackForm()
    {
        super("Dispose and Rebind Sample for RCPForms", pfp = new PersonFormPart());
    }

    public DisposeRebindStackForm(ValidationManager manager)
    {
        // create form with the given title and form parts
        super("Dispose and Rebind Sample for RCPForms", manager, new PersonFormPart());
    }

    @Override
    public void initializeUI()
    {
        // in initializeUI the form is created,
        // input-independent listeners, validators and stuff should be
        // initialized here
    }

    /**
     * creates the models needed for the form and attaches listeners which echo changes to stdout
     * 
     * @return created models
     */
    public static Object[] createModels()
    {
        // and models
        final PersonDataModel personModel = new PersonDataModel();

        // add some listeners to check how databinding works
        personModel.addPropertyChangeListener(new PropertyChangeListener()
        {
            public void propertyChange(PropertyChangeEvent evt)
            {
                System.out.println("Person model changed: " + personModel);
            }
        });

        // set models as input
        // either create ui first and then set input, or if we use
        // startTestShell(),
        // we must first set the input
        Object[] models = new Object[]{personModel};
        return models;
    }

    /**
     * start the form as SWT application
     * 
     * @param args ignored
     */
    public static void main(String[] args)
    {
        // create form
        Object[] models = createModels();
        // create the form, no ui is created yet
        final DisposeRebindStackForm rcpForm = new DisposeRebindStackForm();
        /*
         Realm.runWithDefault(SWTObservables.getRealm(display), new Runnable() {
            public void run() {
                IWizard wizard = new SampleWizard();
                WizardDialog dialog = new WizardDialog(null, wizard);
                dialog.open();
                // The SWT event loop
                Display display = Display.getCurrent();
                while (dialog.getShell() != null
                        && !dialog.getShell().isDisposed()) {
                    if (!display.readAndDispatch()) {
                        display.sleep();
                    }
                }
            }
        });

         */
        // set input, since form is not created the input is not bound yet, but
        // saved for createUI()
        rcpForm.setInput(models);

        // convenience method, creates a shell and creates the form ui in the
        // shell
        // since an input has been set before, the form is bound to the model
        // and ready to go
        rcpForm.startTestShell();
    }
    

    @Override
    protected FormToolkit createFormToolkit()
    {
        return privateToolkit = super.createFormToolkit();
    }
    
    public void prepareModelChange(){
        getValidationManager().unbindPart(pfp);
    }

    public void dispose()
    {
        this.prepareModelChange();
        pfp.dispose();
    }

    public void recreate()
    {
        PersonFormPart part = (PersonFormPart) getPart(0);
        Validate.notNull(privateToolkit);
        Object model = ((Object[])getInput())[0];
        part.createUI(privateToolkit, super.getScrolledForm().getBody());
        getValidationManager().bindPart(part, model);
        getValidationManager().updateValidationStatus(null);
    }

    public void revalidate()
    {
        getValidationManager().revalidate();
        getValidationManager().updateValidationStatus(null);
    }

}
