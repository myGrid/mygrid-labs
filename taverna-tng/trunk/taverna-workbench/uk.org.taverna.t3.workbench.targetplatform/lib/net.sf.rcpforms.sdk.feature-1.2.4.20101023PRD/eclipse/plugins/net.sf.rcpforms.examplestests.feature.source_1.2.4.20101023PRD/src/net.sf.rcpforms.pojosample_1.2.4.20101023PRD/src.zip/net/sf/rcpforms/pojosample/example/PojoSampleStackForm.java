/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.pojosample.example;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.form.RCPForm;
import net.sf.rcpforms.modeladapter.configuration.ModelAdapter;
import net.sf.rcpforms.modeladapter.util.Validate;
import net.sf.rcpforms.pojosample.PojoAdapter;

import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * This is the main class of a simple example for using pojo objects with
 * RCPForms and demonstrates an overview of a small subset of features available
 * in RCPForms. It is a recommended starting point to get an idea how to create
 * an user interface using RCPForms.
 * <p>
 * 
 * @author Remo Loetscher
 */
public class PojoSampleStackForm extends RCPForm
{

    private static PersonFormPart pfp;
    private FormToolkit privateToolkit;
    /**
     * Constructor for SandboxStackForm
     */
    public PojoSampleStackForm()
    {
        super("PojoSample for RCPForms", pfp = new PersonFormPart());
    }

    public PojoSampleStackForm(ValidationManager manager)
    {
        // create form with the given title and form parts
        super("SimpleSample for RCPForms", manager, new PersonFormPart());
    }

    @Override
    public void initializeUI()
    {
        // in initializeUI the form is created,
        // input-independent listeners, validators and stuff should be
        // initialized here
    }

    /**
     * creates the models needed for the form and attaches listeners which echo changes to stdout
     * 
     * @return created models
     */
    public static Object[] createModels()
    {
    	//register modeladapter
        ModelAdapter.registerAdapter(new PojoAdapter());
    	
        // and models
        final PersonPojoDataModel personModel = new PersonPojoDataModel();

        // set models as input
        // either create ui first and then set input, or if we use
        // startTestShell(),
        // we must first set the input
        Object[] models = new Object[]{personModel};
        return models;
    }

    /**
     * start the form as SWT application
     * 
     * @param args ignored
     */
    public static void main(String[] args)
    {
        // create form
        Object[] models = createModels();
        // create the form, no ui is created yet
        final PojoSampleStackForm rcpForm = new PojoSampleStackForm();
        // set input, since form is not created the input is not bound yet, but
        // saved for createUI()
        rcpForm.setInput(models);

        // convenience method, creates a shell and creates the form ui in the
        // shell
        // since an input has been set before, the form is bound to the model
        // and ready to go
        rcpForm.startTestShell();
    }
    

    @Override
    protected FormToolkit createFormToolkit()
    {
        return privateToolkit = super.createFormToolkit();
    }
    
    public void prepareModelChange(){
        getValidationManager().unbindPart(pfp);
    }

    public void dispose()
    {
        this.prepareModelChange();
        pfp.dispose();
    }

    public void recreate()
    {
        PersonFormPart part = (PersonFormPart) getPart(0);
        Validate.notNull(privateToolkit);
        Object model = ((Object[])getInput())[0];
        part.createUI(privateToolkit, super.getScrolledForm().getBody());
        getValidationManager().bindPart(part, model);
        getValidationManager().updateValidationStatus(null);
    }

    public void revalidate()
    {
        getValidationManager().revalidate();
        getValidationManager().updateValidationStatus(null);
    }

}
