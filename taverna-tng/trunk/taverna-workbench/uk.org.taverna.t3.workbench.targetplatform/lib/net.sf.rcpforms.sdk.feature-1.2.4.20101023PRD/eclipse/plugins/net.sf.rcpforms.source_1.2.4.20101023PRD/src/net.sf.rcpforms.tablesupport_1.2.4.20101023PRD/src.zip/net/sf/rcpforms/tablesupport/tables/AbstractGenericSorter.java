package net.sf.rcpforms.tablesupport.tables;

import org.eclipse.jface.viewers.ViewerSorter;

public abstract class AbstractGenericSorter extends ViewerSorter implements IGenericSorter
{

}
