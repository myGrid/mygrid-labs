package net.sf.rcpforms.examples.complete;

public interface IExpandablePart
{
    public void expandPart(boolean doExpand);
}
