package net.sf.rcpforms.examples.complete.formparts;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.examples.complete.IExpandablePart;
import net.sf.rcpforms.examples.complete.models.MasterDetailModel;
import net.sf.rcpforms.examples.complete.models.TestModel;
import net.sf.rcpforms.examples.complete.widgets.MasterDetail_DetailGroup;
import net.sf.rcpforms.modeladapter.configuration.BeanAdapter;
import net.sf.rcpforms.modeladapter.configuration.ModelAdapter;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleList;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class SandboxListMasterDetailFormPart extends RCPFormPart
implements IExpandablePart
{
    private MasterDetailModel model;
    private RCPSection mainSection;
    private MasterDetail_DetailGroup detailGroup = new MasterDetail_DetailGroup();
    private RCPSimpleList m_list = new RCPSimpleList(SWT.BORDER);
    private boolean minimizeSection;


    public SandboxListMasterDetailFormPart(boolean minimizeSection)
    {
        this();
        this.minimizeSection = minimizeSection;
    }

    public SandboxListMasterDetailFormPart()
    {
        super();
    }

    @Override
    public void bind(ValidationManager bm, Object modelBean)
    {
        this.model = (MasterDetailModel) modelBean;
        
        //special content provider for tracking list changes
        ModelAdapter adapterForInstance = ModelAdapter.getAdapterForInstance(modelBean);
        IStructuredContentProvider createDefaultContentProvider = adapterForInstance.createDefaultContentProvider();
        m_list.getViewer().setContentProvider(createDefaultContentProvider);
        m_list.getViewer().setInput(model.getList());
        
        bm.bindDetailValue(BeanAdapter.getInstance(), m_list, TestModel.class, new RCPControl[]{detailGroup.name,
                detailGroup.birthDate, detailGroup.age, detailGroup.overdrawAccount, detailGroup.childCount, detailGroup.accountBalance, detailGroup.gender},
                new String[]{TestModel.P_Name, TestModel.P_BirthDate, TestModel.P_Age,
                        TestModel.P_OverdrawAccount, TestModel.P_ChildCount,
                        TestModel.P_AccountBalance, TestModel.P_Gender});
    }

    @Override
    public void createUI(FormToolkit toolkit, Composite parent)
    {
        GridBuilder mainBuilder = new GridBuilder(toolkit, parent, 2);
        mainSection = new RCPSection("ListMasterDetail binding");
        GridBuilder section = mainBuilder.addContainer(mainSection, 2);
        
        if(minimizeSection)
            mainSection.getSWTSection().setExpanded(false);
        
        section.add(m_list);
        m_list.getViewer().setLabelProvider(new LabelProvider(){

            @Override
            public String getText(Object element)
            {
                // TODO Auto-generated method stub
                return ((TestModel)element).getName();
            }});
        
        detailGroup.createUI(toolkit, section);
        toolkit.paintBordersFor(parent);
    }

    @Override
    public void setState(EControlState state, boolean value)
    {
        mainSection.setState(state, value);
    }
    
    public void expandPart(boolean doExpand)
    {
        this.mainSection.getSWTSection().setExpanded(doExpand);
    }
    
    public static void main(String[] args)
    {
        final MasterDetailModel model = new MasterDetailModel();
        final RCPFormPart part = new SandboxListMasterDetailFormPart();
        RCPFormFactory.getInstance().startTestShell("SandboxListMasterDetailPart", part, model);
    }

}
