package net.sf.rcpforms.examples.complete.widgets.compound;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.examples.complete.models.PersonDataModel;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPCompound;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleText;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;

import org.eclipse.ui.forms.widgets.FormToolkit;

public class RCPPersonCompound extends RCPCompound {

    private RCPText name;
    private RCPSimpleText firstName;

    
	@Override
	public void createUI(FormToolkit formToolkit) {
		
		name = new RCPText("Name and firstname: ");
		name.setState(EControlState.READONLY, true);
		internalAdd(name);
        firstName = new RCPSimpleText();
        firstName.setState(EControlState.READONLY, true);
        internalAdd(firstName);
        
        // TODO Auto-generated method stub
        super.createUI(formToolkit);
//        
//        //add elements to container
//        GridBuilder compositeBuilder = new GridBuilder(formToolkit, getClientComposite(), 3);
//        //1st line
//        compositeBuilder.addLineGrabAndFill(name, 2);
//        //2nd line
//        compositeBuilder.addLine(firstName);
//        //3rd line
//        compositeBuilder.add(street);
//        compositeBuilder.add(streetNumber);
//        compositeBuilder.fillLine();
//        //4th line
//        compositeBuilder.addLine(city);
//        //5th line
//        compositeBuilder.addLineGrabAndFill(country, 2);
//        //6th line
//        compositeBuilder.addLine(birthdate);
	}
	
	public void bindCompound(ValidationManager vm, PersonDataModel model)
	{
		vm.bindValue(name, model, PersonDataModel.P_Name);
		vm.bindValue(firstName, model, PersonDataModel.P_FirstName);
	}

//    @Override
//    public RCPControl getMainControl()
//    {
//        return name;
//    }

}
