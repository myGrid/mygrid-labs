/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.common.model;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.lang.ref.WeakReference;

/**
 * Class JavaBeanWeakRef is the base class for all bean like data models.
 * <p>
 * The {@link PropertyChangeListener} will be registered as a weak reference (
 * {@link WeakReference}). This will allow the garbage collector to collect all
 * PropertyChangeListener (or models) which are only referenced in the
 * collection of PropertyChangeListener of this class. If the
 * PropertyChangeListener is cleared, which means {@link WeakReference#get() ==
 * <code>null</code>}, the weak reference is automatically removed from the list
 * of PropertyChangeListeners.
 * 
 * @author Remo Loetscher, based on Christian's contribution
 */
public class JavaBeanWeakRef extends JavaBean {

	/**
	 * @param listener
	 * @see java.beans.PropertyChangeSupport#addPropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public void addPropertyChangeListener(final PropertyChangeListener listener) {
		super.addPropertyChangeListener(new WeakPropertyChangeListener(
				listener, null));
	}

	/**
	 * @param propertyName
	 * @param listener
	 * @see JavaBean#addPropertyChangeListener(java.lang.String,
	 *      java.beans.PropertyChangeListener)
	 */
	public void addPropertyChangeListener(final String propertyName,
			final PropertyChangeListener listener) {
		super.addPropertyChangeListener(propertyName,
				new WeakPropertyChangeListener(listener, propertyName));
	}

	/**
	 * @param listener
	 * @see JavaBean#removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public void removePropertyChangeListener(
			final PropertyChangeListener listener) {
		super.removePropertyChangeListener(listener);
	}

	/**
	 * @param propertyName
	 * @param listener
	 * @see JavaBean#removePropertyChangeListener(java.lang.String,
	 *      java.beans.PropertyChangeListener)
	 */
	public void removePropertyChangeListener(final String propertyName,
			final PropertyChangeListener listener) {
		super.removePropertyChangeListener(propertyName, listener);
	}

	/**
	 * A WeakPropertyChangeListener wraps a custom PropertyChangeListener in a
	 * weak reference (<code>WeakReference</code>).This means that the garbage
	 * collector will remove a listener from memory if only the listener is
	 * registered.
	 * 
	 */
	private class WeakPropertyChangeListener implements PropertyChangeListener {
		private WeakReference<PropertyChangeListener> m_weakReference;
		private final String m_propertyName;

		public WeakPropertyChangeListener(final PropertyChangeListener wrapped,
				final String propertyName) {
			m_propertyName = propertyName;
			m_weakReference = new WeakReference<PropertyChangeListener>(wrapped);
		}

		private void unlink() {
			removePropertyChangeListener(this);
			if (m_propertyName != null) {
				removePropertyChangeListener(m_propertyName, this);
			}
		}

		public void propertyChange(final PropertyChangeEvent evt) {
			if (m_weakReference != null) {
				PropertyChangeListener referent = m_weakReference.get();
				if (referent != null) {
					referent.propertyChange(evt);
				} else {
					unlink();
				}
			}
		}

		@Override
		public boolean equals(final Object obj) {
			if (obj == m_weakReference) {
				return true;
			}
			if (m_weakReference != null) {
				PropertyChangeListener referent = m_weakReference.get();
				if (referent != null) {
					return referent.equals(obj);
				} else {
					unlink();
				}
			}
			return false;
		}

		@Override
		public int hashCode() {
			if (m_weakReference != null) {
				PropertyChangeListener referent = m_weakReference.get();
				if (referent != null) {
					return referent.hashCode();
				} else {
					unlink();
				}
			}
			return 0;
		}

	}

}
