/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.bindingvalidation.util;

import net.sf.rcpforms.common.model.JavaBean;

public class ControlStateDependencyBean extends JavaBean{
	
	public final static String PROP_VISIBLE = "stateVisible";
	public final static String PROP_ENABLED = "stateEnabled";
	public final static String PROP_READONLY = "stateReadonly";
	public final static String PROP_MANDATORY = "stateMandatory";
	public final static String PROP_RECOMMENDED = "stateRecommended";
	
	private Boolean m_stateVisible = Boolean.TRUE;
	private Boolean m_stateEnabled = Boolean.TRUE;
	private Boolean m_stateReadonly = Boolean.FALSE;
	private Boolean m_stateMandatory = Boolean.FALSE;
	private Boolean m_stateRecommended = Boolean.FALSE;
	
    public Boolean getStateVisible() {
    	return m_stateVisible;
    }
    
    public void setStateVisible(Boolean newValue) {
    	Boolean oldValue = getStateVisible();
    	m_stateVisible = newValue;    	
    	propertyChangeSupport.firePropertyChange(PROP_VISIBLE, oldValue, newValue);
    	
    	if(Boolean.FALSE.equals(newValue)) {
    		setStateMandatory(Boolean.FALSE);
    	}
    }
    
    public Boolean getStateEnabled() {
    	return m_stateEnabled;
    }
    
    public void setStateEnabled(Boolean newValue) {
    	Boolean oldValue = getStateEnabled();
    	m_stateEnabled = newValue;    	
    	propertyChangeSupport.firePropertyChange(PROP_ENABLED, oldValue, newValue);
    	
    	if(Boolean.FALSE.equals(newValue)) {
    		setStateMandatory(Boolean.FALSE);
    		setStateRecommended(Boolean.FALSE);
    	}
    }

    public Boolean getStateReadonly() {
    	return m_stateReadonly;
    }
    
    public void setStateReadonly(Boolean newValue) {
    	Boolean oldValue = getStateReadonly();
    	m_stateReadonly = newValue;    	
    	propertyChangeSupport.firePropertyChange(PROP_READONLY, oldValue, newValue);
    	
    	if(Boolean.TRUE.equals(newValue)) {
    		setStateMandatory(Boolean.FALSE);
    		setStateRecommended(Boolean.FALSE);
    	}
    }

    
    public Boolean getStateRecommended() {
    	return m_stateRecommended;
    }
    
    public void setStateRecommended(Boolean newValue) {
    	Boolean oldValue = getStateRecommended();
    	m_stateRecommended = newValue;    	
    	propertyChangeSupport.firePropertyChange(PROP_RECOMMENDED, oldValue, newValue);
    	if(Boolean.TRUE.equals(newValue)) {
    		setStateVisible(Boolean.TRUE);
    		setStateEnabled(Boolean.TRUE);
    		setStateReadonly(Boolean.FALSE);
    		setStateMandatory(Boolean.FALSE);
    	}
    }
    
    public Boolean getStateMandatory() {
    	return m_stateMandatory;
    }
    
    public void setStateMandatory(Boolean newValue) {
    	Boolean oldValue = getStateMandatory();
    	m_stateMandatory = newValue;    	
    	propertyChangeSupport.firePropertyChange(PROP_MANDATORY, oldValue, newValue);
    	if(Boolean.TRUE.equals(newValue)) {
    		setStateVisible(Boolean.TRUE);
    		setStateEnabled(Boolean.TRUE);
    		setStateReadonly(Boolean.FALSE);
    		setStateRecommended(Boolean.FALSE);
    	}
    }
}
