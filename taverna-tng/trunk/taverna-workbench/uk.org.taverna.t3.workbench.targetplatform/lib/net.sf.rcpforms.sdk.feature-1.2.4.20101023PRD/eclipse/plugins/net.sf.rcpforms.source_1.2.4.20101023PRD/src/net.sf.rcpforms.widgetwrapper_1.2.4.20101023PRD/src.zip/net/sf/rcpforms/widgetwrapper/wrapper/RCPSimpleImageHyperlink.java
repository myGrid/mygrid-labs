/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.widgetwrapper.wrapper;

import java.util.HashSet;
import java.util.Set;

import net.sf.rcpforms.common.util.Validate;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.forms.events.IHyperlinkListener;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.ImageHyperlink;

/**
 * wraps a {#link {@link ImageHyperlink} with a label and a picture.
 * 
 * @author Remo Loetscher
 */
public class RCPSimpleImageHyperlink extends RCPControl
{
    private Set<IHyperlinkListener> listenerSet = null;
    private Image hyperLinkImage;
    /**
     * creates a text control with the given text as content
     */
    public RCPSimpleImageHyperlink(String text)
    {
        this(text, null, SWT.NULL);
    }
    
    public RCPSimpleImageHyperlink(String text, int style)
    {
        this(text, null, style);
    }
    
    public RCPSimpleImageHyperlink(String text, Image image)
    {
        this(text, image, SWT.NULL);
    }

    public RCPSimpleImageHyperlink(String text, Image image, int style)
    {
        super(text, style);
        this.hyperLinkImage = image;
    }

    public final ImageHyperlink getSWTImageHyperlink()
    {
        return getTypedWidget();
    }

    @Override
    protected Widget createWrappedWidget(FormToolkit formToolkit)
    {
        return getFormToolkit().createImageHyperlink(getSWTParent(), getStyle());
    }
    
    @Override
    public void createUI(FormToolkit formToolkit)
    {
        super.createUI(formToolkit);
        if(getLabel() != null)
            getSWTImageHyperlink().setText(getLabel());
        if(hyperLinkImage != null)
            getSWTImageHyperlink().setImage(hyperLinkImage);
        this.hookHyperlinkListener();
    }

    private void hookHyperlinkListener()
    {
        if(listenerSet != null)
        {
            for(IHyperlinkListener listener : listenerSet)
                getSWTImageHyperlink().addHyperlinkListener(listener);
        }
    }

    public void addHyperlinkListener(IHyperlinkListener listener)
    {
        Validate.notNull(listener);

        // initialize lazy to save memory
        if (listenerSet == null)
            listenerSet = new HashSet<IHyperlinkListener>();

        if (!listenerSet.contains(listener))
        {
            //if swt widget is created append listener to it
            if(getSWTImageHyperlink() != null)
                getSWTImageHyperlink().addHyperlinkListener(listener);
            this.listenerSet.add(listener);
        }
    }
    
    public void removeHyperlinkListener(IHyperlinkListener listener)
    {
        Validate.notNull(listener);
        if (this.listenerSet != null
                && this.listenerSet.contains(listener))
        {
            if(getSWTImageHyperlink() != null)
                getSWTImageHyperlink().removeHyperlinkListener(listener);
            this.listenerSet.remove(listener);
        }
    }
}
