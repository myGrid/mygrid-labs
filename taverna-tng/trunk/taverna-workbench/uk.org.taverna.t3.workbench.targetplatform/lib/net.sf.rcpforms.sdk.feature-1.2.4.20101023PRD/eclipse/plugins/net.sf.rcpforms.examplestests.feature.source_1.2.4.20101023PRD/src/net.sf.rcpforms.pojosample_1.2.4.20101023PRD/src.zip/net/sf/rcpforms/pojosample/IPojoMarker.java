package net.sf.rcpforms.pojosample;


/**
 * Markerinterface
 *
 */
public interface IPojoMarker {

}
