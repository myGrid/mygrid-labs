/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.examples.app.multipageeditor;

import net.sf.rcpforms.examples.complete.models.AddressModel;
import net.sf.rcpforms.examples.complete.models.NestedAddressModel;
import net.sf.rcpforms.form.IRCPFormEditorInput;
import net.sf.rcpforms.form.RCPFormEditorPart;

import org.eclipse.core.runtime.IProgressMonitor;

public class AddressFormEditorPart extends RCPFormEditorPart<SandboxAddressForm>
{
    public AddressFormEditorPart(SandboxAddressForm form)
    {
        super(form);
    }

    @Override
    public void doSave(IProgressMonitor monitor)
    {
        this.setDirty(false);
    }

    @Override
    public void doSaveAs()
    {
    }

    @Override
    public boolean isSaveAsAllowed()
    {
        return false;
    }
    
    @Override
    protected void initializeDirtyChangeListener(IRCPFormEditorInput oldInput,
                                                 IRCPFormEditorInput newInput)
    {
        super.initializeDirtyChangeListener(oldInput, newInput);
        //support dirty states for nested properties
        if(oldInput != null)
        {
            for(Object o : oldInput.getModels())
            {
                if(o instanceof AddressModel)
                {
                   this.removeDirtyChangeListener(o);
                   this.removeDirtyChangeListener(((AddressModel)o).getAddress());
                   this.removeDirtyChangeListener(((NestedAddressModel)((AddressModel)o).getAddress()).getCountry());
                }
            }
        }
        
        for(Object o : newInput.getModels())
        {
            if(o instanceof AddressModel)
            {
               this.addDirtyChangeListener(o);
               this.addDirtyChangeListener(((AddressModel)o).getAddress());
               this.addDirtyChangeListener(((NestedAddressModel)((AddressModel)o).getAddress()).getCountry());
            }
        }
    }
}
