/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Christian Spicher - initial API and implementation
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */
package net.sf.rcpforms.widgetwrapper.wrapper;

import org.eclipse.swt.SWT;
import org.eclipse.swt.browser.Browser;
import org.eclipse.swt.browser.ProgressEvent;
import org.eclipse.swt.browser.ProgressListener;
import org.eclipse.swt.browser.StatusTextEvent;
import org.eclipse.swt.browser.StatusTextListener;
import org.eclipse.swt.browser.TitleEvent;
import org.eclipse.swt.browser.TitleListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Widget;

import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * <h2>Bean-like Binding properties supported:</h2>
 * <p>
 * <ul>
 * <li>{@link #PROPERTY_TEXT}</li>
 * <li>{@link #PROPERTY_URL}</li>
 * <li>{@link #PROPERTY_PROGRESS}</li>
 * <li>{@link #PROPERTY_PAGE_TITLE}</li>
 * <li>{@link #PROPERTY_STATUS_TEXT}</li>
 * <li>{@link #PROPERTY_CURSOR}</li>
 * <li>{@link #PROPERTY_FONT}</li>
 * <li>{@link #PROPERTY_FOREGROUND_COLOR}</li>
 * <li>{@link #PROPERTY_BACKGROUND_MODE}</li>
 * <li>{@link #PROPERTY_BACKGROUND_IMAGE}</li>
 * <li>{@link #PROPERTY_BACKGROUND_COLOR}</li>
 * <li>{@link #PROPERTY_TOOLTIP_TEXT}</li> *
 * </ul>
 * <p>
 * 
 * @author Christian Spicher
 * @since 1.2
 */
public class RCPSimpleBrowser extends RCPBeanControl
{

    /** For beanlike Binding of the <b>html-text</b> of this browser widget.
     * </br> Type: <code>String</code> */
    public static final String PROPERTY_TEXT = "text";
    
    /** For beanlike Binding of the <b>url</b> of this browser widget.
     * </br> Type: <code>String</code> */
     public static final String PROPERTY_URL = "url";
    
     /** For beanlike Binding of the <b>progress</b> of the page <b>loading</b> in permills (<code>0..1000</code>).
      * </br> Type: <code>int</code> */
    public static final String PROPERTY_PROGRESS = "progress";

    /** For beanlike Binding of the <b>title</b> of the loaded url by this browser widget.
     * </br> Type: <code>String</code> */
    public static final String PROPERTY_PAGE_TITLE = "pageTitle";
    
    /** For beanlike Binding of the <b>status text</b> of the currently loaded page by this browser widget.
     * </br> Type: <code>String</code> */
    public static final String PROPERTY_STATUS_TEXT = "statusText";

    /** For beanlike Binding of <b>cursor</b> on the currently this browser widget.
     * </br> Type: <code>org.eclipse.swt.graphics.Cursor</code> */
    public static final String PROPERTY_CURSOR = "cursor";

    /** For beanlike Binding of <b>font</b> on this browser widget.
     * </br> Type: <code>org.eclipse.swt.graphics.Font</code> */
    public static final String PROPERTY_FONT = "font";

    /** For beanlike Binding of <b>foreground-color</b> on this browser widget.
     * </br> Type: <code>org.eclipse.swt.graphics.Color</code> */
    public static final String PROPERTY_FOREGROUND_COLOR = "foreground";

    /** For beanlike Binding of <b>background-mode</b> on this browser widget.
     * </br> Type: <code>int</code> */
    public static final String PROPERTY_BACKGROUND_MODE = "backgroundMode";

    /** For beanlike Binding of <b>background-image</b> on this browser widget.
     * </br> Type: <code>org.eclipse.swt.graphics.Image</code> */
    public static final String PROPERTY_BACKGROUND_IMAGE = "backgroundImage";

    /** For beanlike Binding of {@link RCPSimpleBrowser} on this browser widget.
     * </br> Type: <code>org.eclipse.swt.graphics.Color</code> */
    public static final String PROPERTY_BACKGROUND_COLOR = "background";

    /** For beanlike Binding of <b>tool-tip-text</b> on this browser widget.
     * </br> Type: <code>String</code> */
    public static final String PROPERTY_TOOLTIP_TEXT = "toolTipText";
    
    private static final int PROGRESS_MAX = 1000;
    
    private Browser browser;
    private int progressPermille = 0;
    private String pageTitle;
    private String statusText;
 
    public RCPSimpleBrowser(final int style)
    {
        super(null, style);
    }

    public RCPSimpleBrowser()
    {
        this(SWT.DEFAULT);
    }
    
    
    

    @Override
    protected Widget createWrappedWidget( final FormToolkit toolkit)
    {
        browser = getFormToolkitEx().createBrowser(getSWTParent(), getStyle());
        //TODO what for? bind progress on progress property
        browser.addProgressListener(new ProgressListener()
        {
            private int current;
            public void completed(final ProgressEvent event)
            {
                RCPSimpleBrowser.this.firePropertyChange(RCPSimpleBrowser.PROPERTY_PROGRESS, RCPSimpleBrowser.PROGRESS_MAX, current);             
            }
            
            public void changed(final ProgressEvent event)
            {
                int newcurrent = event.current;
                int total = event.total;
                current = total <= 0 ? PROGRESS_MAX : ( PROGRESS_MAX * newcurrent / total);
            }
        });
        return browser;
    }

    /**
     * @return the wrapped SWT-Widget, a {@link Browser}.
     */
    public Browser getSWTBrowser()
    {
        return browser;
    }
    
    
    ///////////////////////////////////////////////////////////////////////////////////
    ///  BEAN LIKE ACCESSORS :
    ///////////////////////////////////////////////////////////////////////////////////

    /**
     * As {@link Browser#setText(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public boolean setText(final String html)
    {
        String oldValue = browser.getText();
        boolean result = setText_NoEvent(html);
        firePropertyChange(PROPERTY_TEXT, html, oldValue);
        return result;
    }

    /**
     * As {@link Browser#setUrl(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setUrl(final String url)
    {
        String oldValue = browser.getUrl();
//        System.out.println("RCPSimpleBrowser.setUrl('"+url+"')");
        setUrl_NoEvent(url);
        firePropertyChange(PROPERTY_URL, url, oldValue);
    }
    
    /**
     * As {@link Browser#setToolTipText(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setToolTipText(final String tooltipText)
    {
        String oldValue = browser.getToolTipText();
        setToolTipText_NoEvent(tooltipText);
        firePropertyChange(PROPERTY_TOOLTIP_TEXT, tooltipText, oldValue);
    }

    /**
     * As {@link Browser#setBackground(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setBackground(final Color background)
    {
        Color oldValue = browser.getBackground();
        setBackground_NoEvent(background);
        firePropertyChange(PROPERTY_BACKGROUND_COLOR, background, oldValue);
    }
    
    /**
     * As {@link Browser#setBackgroundImage(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setBackgroundImage(final Image image)
    {
        Image oldValue = browser.getBackgroundImage();
        setBackgroundImage_NoEvent(image);
        firePropertyChange(PROPERTY_BACKGROUND_IMAGE, image, oldValue);
    }

    /**
     * As {@link Browser#setBackgroundMode(String)} but additionally an event is fired, updating any bound
     * Models.
     * Value can be
     * <ul>
     *   <li><code>SWT.INHERIT_NONE</code></li>
     *   <li><code>SWT.INHERIT_DEFAULT</code></li>
     *   <li><code>SWT.INHERTIT_FORCE</code></li>
      * </ul>
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setBackgroundMode(final int mode)
    {
        int oldValue = browser.getBackgroundMode();
        setBackgroundMode_NoEvent(mode);
        firePropertyChange(PROPERTY_BACKGROUND_MODE, mode, oldValue);
    }

    /**
     * As {@link Browser#setForeground(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setForeground(final Color foreground)
    {
        Color oldValue = browser.getForeground();
        setForeground_NoEvent(foreground);
        firePropertyChange(PROPERTY_FOREGROUND_COLOR, foreground, oldValue);
    }
    
    /**
     * As {@link Browser#setFont(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setFont(final Font font)
    {
        Font oldValue = browser.getFont();
        setFont_NoEvent(font);
        firePropertyChange(PROPERTY_FONT, font, oldValue);
    }
    
    /**
     * As {@link Browser#setCursor(String)} but additionally an event is fired, updating any bound
     * Models.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     **/
    public void setCursor(final Cursor cursor)
    {
        Cursor oldValue = browser.getCursor();
        setCursor_NoEvent(cursor);
        firePropertyChange(PROPERTY_CURSOR, cursor, oldValue);
    }
    
    @Override
    protected void subInitBeanSupport()
    {
        browser.addProgressListener(selfProgressListener);
        browser.addStatusTextListener(selfStatusListener);
        browser.addTitleListener(selfTitleListener);
    }

    @Override
    protected void subUnlinkBeanSupport()
    {
        if (browser != null && !browser.isDisposed())
        {
            browser.addProgressListener(selfProgressListener);
            browser.addStatusTextListener(selfStatusListener);
            browser.addTitleListener(selfTitleListener);
        }
    }
    
    public void setProgress(final int permille)
    {
        firePropertyChange(PROPERTY_PROGRESS, permille, progressPermille);
        progressPermille = permille;
    }
    
    public int getProgress() {
        return progressPermille;
    }
    
    
    public String getPageTitle()
    {
        return pageTitle;
    }

    public void setPageTitle(final String pageTitle)
    {
        firePropertyChange(PROPERTY_PAGE_TITLE, pageTitle, this.pageTitle);
        this.pageTitle = pageTitle;
    }

    public String getStatusText()
    {
        return statusText;
    }

    public void setStatusText(final String statusText)
    {
        firePropertyChange(PROPERTY_STATUS_TEXT, statusText, this.statusText);
        this.statusText = statusText;
    }

  
    ///////////////////////////////////////////////////////////////////////////////////
    ///  BEAN SUPPORTED LISTENERS :
    ///////////////////////////////////////////////////////////////////////////////////



    private final TitleListener selfTitleListener = new TitleListener()
    {
        
        public void changed(final TitleEvent event)
        {
            setPageTitle(event.title);
        }
    };
    
    private final StatusTextListener selfStatusListener = new StatusTextListener()
    {
        
        public void changed(final StatusTextEvent event)
        {
           setStatusText(event.text);
        }
    };
    
   private final ProgressListener selfProgressListener = new ProgressListener()
    {
        public void completed(final ProgressEvent event)
        {
            setProgress(1000);
        }
        
        public void changed(final ProgressEvent event)
        {
            int total = event.total > 0 ? event.total : 100;
            int current = event.current <= total && event.current >= 0 ? event.current : 0;
            int value = (1000 * current) / total;
            setProgress(value);
        }
    };


    ///////////////////////////////////////////////////////////////////////////////////
    /// WRAPPED METHODS :
    ///////////////////////////////////////////////////////////////////////////////////

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.
     * {@link Browser#addProgressListener(ProgressListener) addProgressListener(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void addProgressListener(final ProgressListener listener)
    {
        browser.addProgressListener(listener);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getBackground()
     * getBackground()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public Color getBackground()
    {
        return browser.getBackground();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getBackgroundImage()
     * getBackgroundImage()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public Image getBackgroundImage()
    {
        return browser.getBackgroundImage();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getBackgroundMode()
     * getBackgroundMode()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public int getBackgroundMode()
    {
        return browser.getBackgroundMode();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getCursor()
     * getCursor()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public Cursor getCursor()
    {
        return browser.getCursor();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getFont() getFont()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public Font getFont()
    {
        return browser.getFont();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getForeground()
     * getForeground()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public Color getForeground()
    {
        return browser.getForeground();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getText() getText()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public String getText()
    {
        return browser.getText();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getToolTipText()
     * getToolTipText()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public String getToolTipText()
    {
        return browser.getToolTipText();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#getUrl() getUrl()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public String getUrl()
    {
        return browser.getUrl();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#isBackEnabled()
     * isBackEnabled()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public boolean isBackEnabled()
    {
        return browser.isBackEnabled();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#isForwardEnabled()
     * isForwardEnabled()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public boolean isForwardEnabled()
    {
        return browser.isForwardEnabled();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#refresh() refresh()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void refresh()
    {
        browser.refresh();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.
     * {@link Browser#removeProgressListener(ProgressListener) removeProgressListener(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void removeProgressListener(final ProgressListener listener)
    {
        browser.removeProgressListener(listener);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#setBackground(Color)
     * setBackground(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void setBackground_NoEvent(final Color color)
    {
        browser.setBackground(color);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.
     * {@link Browser#setBackgroundImage(Image) setBackgroundImage(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void setBackgroundImage_NoEvent(final Image image)
    {
        browser.setBackgroundImage(image);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.
     * {@link Browser#setBackgroundMode(int) setBackgroundMode(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void setBackgroundMode_NoEvent(final int mode)
    {
        browser.setBackgroundMode(mode);
    }


    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#setCursor(Cursor)
     * setCursor(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void setCursor_NoEvent(final Cursor cursor)
    {
        browser.setCursor(cursor);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#setFont(Font)
     * setFont(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void setFont_NoEvent(final Font font)
    {
        browser.setFont(font);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#setForeground(Color)
     * setForeground(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void setForeground_NoEvent(final Color color)
    {
        browser.setForeground(color);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#setText(String)
     * setText(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public boolean setText_NoEvent(final String html)
    {
        return browser.setText(html);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.
     * {@link Browser#setToolTipText(String) setToolTipText(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void setToolTipText_NoEvent(final String string)
    {
        browser.setToolTipText(string);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#setUrl(String)
     * setUrl(...)}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public boolean setUrl_NoEvent(final String url)
    {
        return browser.setUrl(url);
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#stop() stop()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void stop()
    {
        browser.stop();
    }

    /**
     * Convenience for {@link #getSWTBrowser() getSWTBrowser()}.{@link Browser#update() update()}.
     * 
     * @throws NullPointerException if swt-widget was not yet
     *             {@link #createWrappedWidget(FormToolkit) created}.
     */
    public void update()
    {
        browser.update();
    }

}
