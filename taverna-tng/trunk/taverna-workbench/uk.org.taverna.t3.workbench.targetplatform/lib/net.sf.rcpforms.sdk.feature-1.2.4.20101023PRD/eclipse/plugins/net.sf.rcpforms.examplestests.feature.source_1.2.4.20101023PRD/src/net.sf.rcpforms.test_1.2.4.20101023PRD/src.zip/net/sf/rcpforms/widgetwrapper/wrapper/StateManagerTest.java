/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.widgetwrapper.wrapper;

import java.util.Set;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.widgets.Display;

import net.sf.rcpforms.bindingvalidation.BindingBaseTestCase;
import net.sf.rcpforms.widgetwrapper.statehandling.IWidgetStateController;
import net.sf.rcpforms.widgetwrapper.statehandling.WidgetStateManager;

/**
 * UI Test for testing bindings of a widget against supported types of nested model
 * values. The following is tested:
 * <ul>
 * <li>vetoable state controller: setting enablestate is prohibited
 * </ul>
 * 
 * @author Remo Loetscher
 */
public class StateManagerTest extends BindingBaseTestCase
{
    private static final String LABEL = "StateControllerControl:";
    private IWidgetStateController myController;
    static final Color newMandatoryBG = Display.getCurrent().getSystemColor(SWT.COLOR_BLUE);
    
    @Override
    public void setUp() throws Exception
    {
        super.setUp();
        myController =  new IWidgetStateController(){

            public int reviewState(RCPControl rcpControl, int state)
            {
                //do not allow to enable control
                if(EControlState.isMember(EControlState.ENABLED, state))
                    return (~state) & state;
                return state;
            }};
        WidgetStateManager.setWidgetStateController(myController);
    }
    
    

    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
        WidgetStateManager.setWidgetStateController(null);
    }



    public void testWidgetStateManagerInitialization()
    {
        Set<Class<? extends RCPControl>> stateManagers = WidgetStateManager.getRegisteredWidgetStateManager();
        assertEquals(2, stateManagers.size());
        for(Class<?> c : stateManagers)
        {
            assertTrue(c == RCPControl.class || c == RCPSection.class);
        }
    }
    
    public void testUpdateLayoutFlag()
    {
        WidgetStateManager manager = WidgetStateManager.getInstance(RCPControl.class);
        assertNotNull(manager);
        assertTrue(manager.isLayoutUpdateEnabled());
        manager.setIsLayoutUpdateEnabled(false);
        assertFalse(manager.isLayoutUpdateEnabled());
    }
    
    public void testEnabledState()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        
        //default implementation is that widgets are enabled
        assertEquals(state, widget.getRCPControl().getState(EControlState.ENABLED));
        
        //try to enable widget
        widget.setState(EControlState.ENABLED, state);
        assertEquals(!state, widget.getRCPControl().getState(EControlState.ENABLED));
        
        //try to disable widget
        widget.setState(EControlState.ENABLED, !state);
        assertEquals(!state, widget.getRCPControl().getState(EControlState.ENABLED));
        
        builder.add(widget);
        
        //try to enable widget
        widget.setState(EControlState.ENABLED, state);
        assertEquals(!state, widget.getRCPControl().getState(EControlState.ENABLED));
        assertEquals(!state, widget.getSWTText().isEnabled());
        
        //try to disable widget
        widget.setState(EControlState.ENABLED, !state);
        assertEquals(!state, widget.getRCPControl().getState(EControlState.ENABLED));
        assertEquals(!state, widget.getSWTText().isEnabled());
    }
    
    public void testEnabledStateWithoutSettingState()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        
        //Default state is enabled
        //widget.setState(EControlState.ENABLED, state);
        builder.add(widget);
        
        assertEquals(!state, widget.getRCPControl().getState(EControlState.ENABLED));
        assertEquals(!state, widget.getSWTText().isEnabled());
    }
    
    public void testEnabledStateWithoutStateController()
    {
        boolean state = true;
        RCPText widget = new RCPText(LABEL);
        
        WidgetStateManager.setWidgetStateController(null);
        
        widget.setState(EControlState.ENABLED, state);
        
        builder.add(widget);
        
        assertEquals(state, widget.getRCPControl().getState(EControlState.ENABLED));
        assertEquals(state, widget.getSWTText().isEnabled());
        
        widget.setState(EControlState.ENABLED, !state);
        assertEquals(!state, widget.getRCPControl().getState(EControlState.ENABLED));
        assertEquals(!state, widget.getSWTText().isEnabled());
    }
    
    public void testCustomWidgetStateManager()
    {
        RCPText test = new RCPText("CustomStateManager");
        MyWidgetStateManager mwsm = new MyWidgetStateManager();
        assertNotNull(WidgetStateManager.getInstance(RCPSimpleText.class));
        builder.add(test);
        
        mwsm.stateUpdated = false;
        int stateManagerConter = WidgetStateManager.getRegisteredWidgetStateManager().size();
        //register custom state manager for rcpsimpletext
        WidgetStateManager.registerWidgetStateManager(RCPSimpleText.class, mwsm);
        
        assertEquals(stateManagerConter + 1, WidgetStateManager.getRegisteredWidgetStateManager().size());
        assertTrue(WidgetStateManager.getRegisteredWidgetStateManager().contains(RCPSimpleText.class));
        assertEquals(WidgetStateManager.getInstance(RCPSimpleText.class), mwsm);
        test.setState(EControlState.READONLY, true);
        assertTrue(mwsm.stateUpdated);
        mwsm.stateUpdated = false;

        //test setting background color
        test.setState(EControlState.MANDATORY, true);
        assertTrue(mwsm.stateUpdated);
        assertEquals(newMandatoryBG, test.getSWTText().getBackground());
        
        //unregister custom state manager for rcpsimpletext
        assertEquals(mwsm, WidgetStateManager.registerWidgetStateManager(RCPSimpleText.class, null));
        assertEquals(stateManagerConter, WidgetStateManager.getRegisteredWidgetStateManager().size());
    }
    
}

class MyWidgetStateManager extends WidgetStateManager
{
    boolean stateUpdated = false;
    
    @Override
    protected void setStateBackground(RCPControl rcpControl)
    {
        // TODO Auto-generated method stub
        super.setStateBackground(rcpControl);
    }
    @Override
    public void updateState(RCPControl rcpControl, int state)
    {
        // TODO Auto-generated method stub
        super.updateState(rcpControl, state);
        stateUpdated = true;
        if(EControlState.isMember(EControlState.MANDATORY, state))
        {
            rcpControl.getSWTControl().setBackground(StateManagerTest.newMandatoryBG);
        }
    }
    
    
}
