
package net.sf.rcpforms.examples.wizards;

import net.sf.rcpforms.examples.complete.DateRangeValidator;
import net.sf.rcpforms.examples.complete.formparts.SandboxGeneralFormPart;
import net.sf.rcpforms.examples.complete.formparts.Sandbox3FormPart;
import net.sf.rcpforms.examples.complete.models.AddressModel;
import net.sf.rcpforms.examples.complete.models.TestModel;
import net.sf.rcpforms.form.RCPForm;
import net.sf.rcpforms.form.RCPFormTitleValidatedWizardPage;
import net.sf.rcpforms.form.RCPFormWizardPage;
import net.sf.rcpforms.form.RCPSimpleForm;

import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.wizard.Wizard;
import org.eclipse.ui.INewWizard;
import org.eclipse.ui.IWorkbench;

/**
 * shows how to embed RCPForms as wizard pages into wizards
 * 
 * @author Marco van Meegen
 */

public class ExampleTitleValidatedFormWizard extends Wizard implements INewWizard
{
    private RCPSimpleForm form1;

    private RCPSimpleForm form2;

    private RCPFormTitleValidatedWizardPage formWizardPage1;

    private RCPFormTitleValidatedWizardPage formWizardPage2;

    public ExampleTitleValidatedFormWizard()
    {
        super();
        // create generic forms using parts
        form1 = new RCPSimpleForm("Sandbox2Part Title", new SandboxGeneralFormPart());
        formWizardPage1 = new RCPFormTitleValidatedWizardPage("PAGE1", form1);
        final Sandbox3FormPart part = new Sandbox3FormPart();
        form2 = new RCPSimpleForm("Sandbox3Part Title", part)
        {
            // add a date range validator to this part
            @Override
            public void initializeUI()
            {
                getValidationManager().addValidator(part, new DateRangeValidator());
            }
        };
        formWizardPage2 = new RCPFormTitleValidatedWizardPage("PAGE2", form2);
    }

    /**
     * Adding the page to the wizard.
     */

    public void addPages()
    {
        // wrap forms into a page and add
//        addPage(new RCPFormWizardPage("PAGE1", form1));
//        addPage(new RCPFormWizardPage("PAGE2", form2));
        addPage(formWizardPage1);
        addPage(formWizardPage2);
    }

    /**
     * This method is called when 'Finish' button is pressed in the wizard. We will create an
     * operation and run it using wizard as execution context.
     */
    public boolean performFinish()
    {
        return true;
    }

    public void init(IWorkbench workbench, IStructuredSelection selection)
    {
        // usually you would want to set the input from outside the wizard,
        // define your setInput method as below, the models passed in will contain the changed
        // models on wizard exit
        setInput(new Object[]{new TestModel(), new AddressModel()});
    }

    /**
     * set input consisting of an array of {TestModel, AddressModel}
     */
    public void setInput(Object input)
    {
        Object[] inputArray = (Object[]) input;
        form1.setInput(new Object[]{inputArray[0]});
        form2.setInput(new Object[]{inputArray[1]});
    }

}