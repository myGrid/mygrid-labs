package net.sf.rcpforms.examples.snippets;

import static org.eclipse.swt.SWT.FULL_SELECTION;
import static org.eclipse.swt.SWT.LEFT;
import static org.eclipse.swt.SWT.SINGLE;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.WidgetBeanValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.common.model.JavaBean;
import net.sf.rcpforms.form.RCPForm;
import net.sf.rcpforms.modeladapter.converter.ValidatorConverterStrategy;
import net.sf.rcpforms.tablesupport.tables.ColumnConfiguration;
import net.sf.rcpforms.tablesupport.tables.ECellEditorType;
import net.sf.rcpforms.tablesupport.tables.TableUtil;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPHyperlinkLabel;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleButton;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleText;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPTable;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;

import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.core.databinding.observable.list.WritableList;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.ColumnViewerEditor;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationEvent;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationListener;
import org.eclipse.jface.viewers.ColumnViewerEditorActivationStrategy;
import org.eclipse.jface.viewers.ColumnViewerEditorDeactivationEvent;
import org.eclipse.jface.viewers.FocusCellOwnerDrawHighlighter;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerEditor;
import org.eclipse.jface.viewers.TableViewerFocusCellManager;
import org.eclipse.jface.viewers.ViewerColumn;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.TableCursor;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.KeyListener;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class TestRCP
{
    public static void main(String[] args)
    {
        final Display display = Display.getDefault();
        final Shell shell = new Shell(display);
        shell.setLayout(new FillLayout());
        
        Realm.runWithDefault(SWTObservables.getRealm(Display.getDefault()), new Runnable()
        {
            public void run()
            {
                TestRCP.FormPart part = new TestRCP.FormPart();
                RCPForm form = new RCPForm("Editable Table", new WidgetBeanValidationManager("TestRCP"), part);
                WritableList listModel = new WritableList();
                listModel.add(new TestRCP.Model("a1","a2", "a3", "a4"));
                listModel.add(new TestRCP.Model("b1","b2", "b3", "b4"));
                listModel.add(new TestRCP.Model("c1","c2", "c3", "c4"));
                
                RCPTestModel model = new RCPTestModel();
                model.listModel = listModel;
                form.setInput(new Object[]{model});
                
                form.createUI(shell);
            }
        });
        
        shell.setLayout (new FillLayout());

        shell.open();
        shell.pack(true);
        while (!shell.isDisposed())
        {
            if (!display.readAndDispatch())
            {
                display.sleep();
            }
        }
        display.dispose();  
    }

    public static class FormPart extends RCPFormPart
    {
        private RCPTable m_table;
        private TableViewer m_tableViewer;
		private RCPText text;
		private RCPSimpleButton button;
        private WidgetBeanValidationManager wb;
        private RCPTestModel model;

        public FormPart()
        {
            m_table = new RCPTable("", FULL_SELECTION | SINGLE);
        }

        public void createUI(FormToolkit formToolkit, Composite parent)
        {
            GridBuilder builder = new GridBuilder(formToolkit, parent, 3);
            text = new RCPText("bind editable state direct to text-widget: ");
            button = new RCPSimpleButton("change tooltip");
            builder.add(text);
            builder.add(button);
            button.getSWTButton().addSelectionListener(new SelectionAdapter(){

                @Override
                public void widgetSelected(SelectionEvent e)
                {
                    updateTooltip();
                }});
            builder.addLine(m_table);
            ColumnConfiguration[] colConfigs = createColumnConfigurations();
            m_tableViewer = TableUtil.configureTableViewer((TableViewer) m_table.getViewer(), colConfigs, Model.class, false, false);
//            ColumnViewerEditor columnViewerEditor = m_tableViewer.getColumnViewerEditor();

//            ViewerColumn part = m_tableViewer.getViewerColumn(3);
            setFocus();
            createTableCursor(m_tableViewer);
//            CellEditor cellEditor = m_tableViewer.getCellEditors()[colConfigs.length-1];
            // focus on the cell not the whole line while editing
//            final TableViewerFocusCellManager mgr = new TableViewerFocusCellManager(m_tableViewer, new FocusCellOwnerDrawHighlighter(m_tableViewer));
            // enable mouse click selection
//            ColumnViewerEditorActivationStrategy actSupport = new ColumnViewerEditorActivationStrategy(m_tableViewer)
//            {
//                protected boolean isEditorActivationEvent(ColumnViewerEditorActivationEvent event)
//                {
//                    return event.eventType == ColumnViewerEditorActivationEvent.TRAVERSAL
//                            || event.eventType == ColumnViewerEditorActivationEvent.MOUSE_CLICK_SELECTION
//                            || event.eventType == ColumnViewerEditorActivationEvent.PROGRAMMATIC;
//                }
//            };
            // enable keyboard tabbing
//            TableViewerEditor.create(m_tableViewer, mgr, actSupport, TableViewerEditor.TABBING_HORIZONTAL | TableViewerEditor.TABBING_MOVE_TO_ROW_NEIGHBOR | TableViewerEditor.TABBING_VERTICAL | TableViewerEditor.KEYBOARD_ACTIVATION);
//            createTableCursor(m_tableViewer);
        }

        protected void updateTooltip()
        {
            model.setToolTip("\"change tooltip\" pressed!");
            wb.updateModelToForm();
        }

        private void createTableCursor(final TableViewer viewer) {
        	// create a TableCursor to navigate around the table
            final TableCursor cursor = new TableCursor(viewer.getTable(), SWT.NONE);
           
            viewer.getColumnViewerEditor().addEditorActivationListener(new ColumnViewerEditorActivationListener(){

				@Override
				public void afterEditorActivated(
						ColumnViewerEditorActivationEvent event) {
					System.out.println("afterEditorActivated");
					
				}

				@Override
				public void afterEditorDeactivated(
						ColumnViewerEditorDeactivationEvent event) {
					
					Event e = new Event();
					e.keyCode = SWT.ARROW_DOWN;
					e.doit = true;
					cursor.notifyListeners(SWT.KeyDown, e);
					TableItem row = cursor.getRow();
                    int column = cursor.getColumn();
                    viewer.editElement(row.getData(), column);
                    System.out.println("up/down2");
					System.out.println("afterEditorDeactivated");
				}

				@Override
				public void beforeEditorActivated(
						ColumnViewerEditorActivationEvent event) {
					event.cancel = true;
					System.out.println("beforeEditorActivated");
				}

				@Override
				public void beforeEditorDeactivated(
						ColumnViewerEditorDeactivationEvent event) {
					System.out.println("beforeEditorDeactivated");
					
				}});
            cursor.setVisible(true);
            cursor.addKeyListener(new KeyAdapter(){

                public void keyPressed(KeyEvent e)
                {
                    if(e.keyCode == SWT.ARROW_DOWN || e.keyCode == SWT.ARROW_UP)
                    {
//                    	TableItem row = cursor.getRow();
//                        int column = cursor.getColumn();
//                        viewer.editElement(row.getData(), column);
//                        System.out.println("up/down");
                    }
                }});
            
            cursor.addMouseListener(new MouseAdapter()
            {

                public void mouseDoubleClick(MouseEvent e)
                {
                    TableItem row = cursor.getRow();
                    int column = cursor.getColumn();
                    viewer.editElement(row.getData(), column);
                }
            });
            
            cursor.addSelectionListener(new SelectionAdapter()
            {
                @Override
                public void widgetDefaultSelected(SelectionEvent e)
                {
                    TableItem row = cursor.getRow();
                    int column = cursor.getColumn();
                    viewer.editElement(row.getData(), column);
                }
            });

		}

		private ColumnConfiguration[] createColumnConfigurations()
        {
            return new ColumnConfiguration[]
                    {
                    new ColumnConfiguration("Prop 1", Model.P_PROP_1, 150, LEFT, true, null),
                    new ColumnConfiguration("Prop 2", Model.P_PROP_2, 100, LEFT, true, null),
                    new ColumnConfiguration("Prop 3", Model.P_PROP_2, 150, LEFT, true, null),
                    new ColumnConfiguration("Prop 4", Model.P_PROP_4, 150, LEFT, true, ECellEditorType.TEXT)
                    };
        }

        public void bind(ValidationManager bm, Object modelBean)
        {
        	model = (RCPTestModel) modelBean;
        	wb = (WidgetBeanValidationManager) bm;
        	wb.bindValue(text, model, RCPTestModel.P_TOOLTIP);
        	//bind state direct to swt widget
//        	wb.bindValueForWidgetProperty(text, "editable", new ValidatorConverterStrategy(), modelBean, RCPTestModel.P_EDITABLE);
        	//bind tooltip provided from model
        	wb.bindValueForWidgetProperty(text, "toolTipText", new ValidatorConverterStrategy(), modelBean, RCPTestModel.P_TOOLTIP);
        	wb.bindValueForWidgetProperty(text.getRCPHyperlink(), "toolTipText", new ValidatorConverterStrategy(), modelBean, RCPTestModel.P_TOOLTIP);
        	
        	m_tableViewer.setInput(model.listModel);
        }

        public void setFocus()
        {
            m_table.getSWTTable().setFocus();
        }

        @Override
        public void setState(EControlState state, boolean value)
        {
        }
    }

    ////////////////////////////////////////////////////////////////////////////
    // Model
    public static class Model
    {

        // property change support
        private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

        public void addPropertyChangeListener(PropertyChangeListener listener)
        {
            propertyChangeSupport.addPropertyChangeListener(listener);
        }
        public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener)
        {
            propertyChangeSupport.addPropertyChangeListener(propertyName, listener);
        }
        public void removePropertyChangeListener(PropertyChangeListener listener)
        {
            propertyChangeSupport.removePropertyChangeListener(listener);
        }
        public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener)
        {
            propertyChangeSupport.removePropertyChangeListener(propertyName, listener);
        }

        private String m_prop1;
        private String m_prop2;
        private String m_prop3;
        private String m_prop4;

        public static final String P_PROP_1 = "prop1";
        public static final String P_PROP_2 = "prop2";
        public static final String P_PROP_3 = "prop3";
        public static final String P_PROP_4 = "prop4";
        
        public Model(String prop1, String prop2, String prop3, String prop4)
        {
            m_prop1 = prop1;
            m_prop2 = prop2;
            m_prop3 = prop3;
            m_prop4 = prop4;
        }
        public String getProp1()
        {
            return m_prop1;
        }
        public void setProp1(String prop1)
        {
            m_prop1 = prop1;
        }
        public String getProp2()
        {
            return m_prop2;
        }
        public void setProp2(String prop2)
        {
            m_prop2 = prop2;
        }
        public String getProp3()
        {
            return m_prop3;
        }
        public void setProp3(String prop3)
        {
            m_prop3 = prop3;
        }
        public String getProp4()
        {
            return m_prop4;
        }
        public void setProp4(String prop4)
        {
            Object oldValue = m_prop4;
            m_prop4 = prop4;
            propertyChangeSupport.firePropertyChange(P_PROP_4, oldValue, prop4);
        }
    } // class Model
} // class TestRCP

class RCPTestModel extends JavaBean
{
    public static final String P_EDITABLE = "editable";
    
    public static final String P_TOOLTIP = "toolTip";

    private Boolean m_editable = Boolean.FALSE;
    
    private String m_toolTip = "This is a model based tooltip";

    WritableList listModel;
    
    public Boolean getEditable()
    {
        return (Boolean) m_editable;
    }

    public void setEditable(Boolean value)
    {
        Object oldValue = m_editable;
        m_editable = value;
        propertyChangeSupport.firePropertyChange(P_EDITABLE, oldValue, value);
    }
    
    public String getToolTip()
    {
        return (String) m_toolTip;
    }

    public void setToolTip(String value)
    {
        Object oldValue = m_toolTip;
        m_toolTip = value;
        propertyChangeSupport.firePropertyChange(P_TOOLTIP, oldValue, value);
    }
	
}
