package net.sf.rcpforms.examples.complete;

import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.rcpforms.modeladapter.configuration.BeanAdapter;
import net.sf.rcpforms.modeladapter.converter.IPropertyChain;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;

/**
 * Generic table sorter. Sorts the viewer input using {@link org.eclipse.jface.viewers.ViewerSorter}
 * . Extracts the value from datamodel by using the given property. if (and only if) both objects
 * are of type comparable than calls compareTo on the first object if sorting direction is
 * descending or the second object if direction is ascending. Otherwise it uses comparing logic from
 * {@link org.eclipse.jface.viewers.ViewerSorter#compare(Viewer, Object, Object)}
 * 
 * <h3><u>Usage:</u></h3></br>
 * Simply add one instance to each TableColumn as <code><b>SelectionListener</b></code>:
 * <pre>
 *   <font color='darkmagenta'>final</font> <i>GenericTableSorter2</i> sorter = <font color='darkmagenta'>new</font> <i>GenericTableSorter2</i>(tableViewer, somePropertyName);
 *   tableColumn.<b>addSelectionListener(sorter)</b>;
 * </pre>
 * Upon selection on the <code>tableColumn</code>'s header it installs itself as <code>ViewerSorter</code>.
 * 
 * @author Loetscher Remo
 * @author Spicher Christian (improved, Nov.2009)
 * @version 1.2 - fixed property path on multi-properties
 *              - added SelectionListener
 *              - fixed sorting bug when sorting by clicking on column A, then B, then A again (remembered its state, now down again)
 *              - added support for 3 (or more) chained sorters in a FIFO List (aka sorter history) 
 */
public class GenericTableSorter2 extends ViewerSorter implements SelectionListener
{
    protected static final int CHAINABLE_SORTERS_COUNT = 2; 
    // TODO remove this counter and method finalize (debug purposes)
    private static int s_instanceCounter = 0;
    
    private static final Logger LOG = Logger.getLogger(GenericTableSorter2.class.getName());

    private boolean m_descendingOrder = true;

    private String m_property;

    private final Table m_table;

    private final TableViewer m_tableViewer;
    
    private IPropertyChain m_propertyChain;
    private Class<?> m_cachedType;

    private final boolean m_emptyStringHighest;
    
    private Vector<GenericTableSorter2> m_previous = new Vector<GenericTableSorter2>(CHAINABLE_SORTERS_COUNT + 1);

    public GenericTableSorter2(final TableViewer tableViewer, final String property) {
        this(tableViewer, property, false);
    }
    
    /**
     * Instantiates a new generic table sorter2.
     * 
     * @param tableViewer the table viewer being sorted
     * @param property  property of the column being sorted
     * @param emptyStringHighest if <code>true</code> then empty strings will be treated as higher values
     *        than any non-empty strings --&gt; they will get at the end of the table!
     */
    public GenericTableSorter2(final TableViewer tableViewer, final String property, final boolean emptyStringHighest)
    {
        m_tableViewer = tableViewer;
        m_emptyStringHighest = emptyStringHighest;
        m_table = tableViewer.getTable();
        m_property = property;
        m_propertyChain = null;
        m_cachedType = null;
        s_instanceCounter++;
    }

    public void switchSortDirection()
    {
        // switch sorting order
        m_descendingOrder = !m_descendingOrder;

    }
    
    public void setSortDirection(final boolean descending) {
        m_descendingOrder = descending;
    }

    public boolean isDescendingOrder()
    {
        return m_descendingOrder;
    }

    @SuppressWarnings("unchecked")
    @Override
    public int compare(final Viewer viewer, final Object e1, final Object e2)
    {
        for (final GenericTableSorter2 chainedSorter : m_previous) {
            final int res = chainedSorter.doCompare(viewer, e1, e2);
            if (res != 0) { // this sorter did make the difference:
                return res;
            }
        }
        return 0; // none of the 3 chained sorters could make any difference
    }
    
    protected int doCompare(final Viewer viewer, final Object e1, final Object e2) {
        int returnValue = 0;
        final Object value1 = this.getPropertyValue(e1, m_property);
        final Object value2 = this.getPropertyValue(e2, m_property);

        // only use comparable if both values are instanceof comparable. if one
        // value is null: super.compare() will be called
        final boolean useComparableInterface = value1 instanceof Comparable
                && value2 instanceof Comparable;

        if (useComparableInterface)
        {
            returnValue = ((Comparable) value1).compareTo(value2);
            if (m_emptyStringHighest && value1 instanceof String && value2 instanceof String) {
                // if at least one of them is an empty string, so simply invert result:
                if (value1 != null && ((String) value1).length() == 0) {
                    returnValue = - returnValue;
                } else if (value2 != null && ((String) value2).length() == 0) {
                    returnValue = - returnValue;
                }
            } else {
                returnValue = ((Comparable) value1).compareTo(value2);
            }
        }
        else
        {
            returnValue = super.compare(viewer, value1, value2);
        }
        return m_descendingOrder ? -returnValue : returnValue;
    }

    @Override
    public boolean isSorterProperty(final Object element, final String property)
    {
        return this.m_property.equals(property);
    }

    @Override
    public void sort(final Viewer viewer, final Object[] elements)
    {
        super.sort(viewer, elements);
    }

    private Object getPropertyValue(final Object object, final String property)
    {
        try
        {
            final Class<? extends Object> itsType = object.getClass();
            if (m_propertyChain == null || m_cachedType == null || m_cachedType.isAssignableFrom(itsType) ) {
                m_propertyChain = BeanAdapter.getInstance().getPropertyChain(object.getClass(), property);
                m_cachedType = itsType;
            }
            return m_propertyChain.getValue(object);
        }
        catch (final Throwable ex)
        {
            LOG.log(Level.SEVERE, "Error getting value for property " + property + "!", ex); //$NON-NLS-1$ //$NON-NLS-2$
            return null;
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////
    ///  INTERFACE SelectionListener :
    ///////////////////////////////////////////////////////////////////////////////////

    public void widgetDefaultSelected(final SelectionEvent e) {
        // ignore
    }

    public void widgetSelected(final SelectionEvent e) {
        
        final TableColumn myColumn = (TableColumn) e.widget;
        final ViewerSorter currentSorter = m_tableViewer.getSorter();
        if (currentSorter != null && currentSorter != this && currentSorter instanceof GenericTableSorter2) {
            // chain previous up:
            final GenericTableSorter2 other = (GenericTableSorter2) currentSorter;
            m_previous.clear();
            other.m_previous.remove(this);
            m_previous.addAll(other.m_previous);
            other.m_previous.clear();
            // set myself at 1st place:
            if (m_previous.size() == CHAINABLE_SORTERS_COUNT) {
                //m_previous.remove(m_previous.size() - 1);
                m_previous.remove(0);
            }
            //m_previous.insertElementAt(this, 0);
            m_previous.insertElementAt(this, m_previous.size());
        }
        final TableColumn currentSortedColumn = m_table.getSortColumn();
        
        // set sort indicator to the table header
        if (currentSortedColumn == myColumn) {
            // switch sorting direction
            switchSortDirection();
        } else {
            setSortDirection(false);
            m_table.setSortColumn(myColumn);
        }
        m_table.setSortDirection(isDescendingOrder() ? SWT.UP : SWT.DOWN);
        
        // set sorter or only refresh
        if (currentSorter != this) {
            if (m_previous.size() == 0) {
                m_previous.add(this);
            }
            m_tableViewer.setSorter(this);
        } else {
            m_tableViewer.refresh();
        }
    }
    
    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        s_instanceCounter--;
//      System.out.println("deleting "+ GenericTableSorter2.class.getSimpleName() + ", " + s_instanceCounter
//       + " left");
    }
}

