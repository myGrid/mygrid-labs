
/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.complete.models;

import java.util.Arrays;
import java.util.Date;

import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.examples.complete.models.TestModel.Gender;

import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.core.databinding.observable.list.WritableList;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.swt.widgets.Display;

/**
 * Class TableModel represents the presentation model for the table part. WritableList is used,
 * since notification is built-in and much more efficient than bean indexed property notification.
 * 
 * @author Marco van Meegen
 * @author Remo Loetscher
 */
public class MasterDetailModel
{

    /** list of elements to display in the table */
    private WritableList m_list;
    
    public MasterDetailModel()
    {
        this(SWTObservables.getRealm(Display.getDefault()));
        TestModel[] list = {
                new TestModel("Mueller", new Date(10000000000L), true, 0, 1000.0, Gender.UNKNOWN, true),
                new TestModel("Meier1", new Date(20000000000L), false, 2, 500.0, Gender.MALE, true),
                new TestModel("Meier2", new Date(100000000000L), false, 2, 123.0, Gender.FEMALE, false),
                new TestModel("Meier3", new Date(40000000000L), false, 2, 11000.0, Gender.UNKNOWN, true),
                new TestModel("Meier4", new Date(30000000000L), false, 2, 2.0, Gender.UNKNOWN, false)};
        for(int i = 0 ; i < list.length; ++i)
        {
            list[i].setAge(i + 20);
        }
        m_list.addAll(Arrays.asList(list));
    }

    /**
     * create writable lists using given realm
     */
    public MasterDetailModel(Realm realm)
    {
        Validate.notNull(realm, "Realm must not be null");
        m_list = new WritableList(realm);
    }

    /**
     * @return Returns the list.
     */
    public WritableList getList()
    {
        return m_list;
    }

    @Override
    public String toString()
    {
        StringBuffer result = new StringBuffer();
        result.append("MasterDetailModel.list[\n");
        for (Object element : m_list)
        {
            result.append("  " + element.toString() + "\n");
        }
        result.append("]");
        return result.toString();
    }

}
