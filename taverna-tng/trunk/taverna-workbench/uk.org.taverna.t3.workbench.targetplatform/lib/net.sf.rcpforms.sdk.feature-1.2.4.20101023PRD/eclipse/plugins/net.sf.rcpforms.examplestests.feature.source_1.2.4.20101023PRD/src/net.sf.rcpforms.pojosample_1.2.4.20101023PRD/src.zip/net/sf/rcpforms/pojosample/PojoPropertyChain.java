/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.pojosample;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;

import net.sf.rcpforms.modeladapter.converter.IPropertyChain;
import net.sf.rcpforms.modeladapter.util.Validate;

public class PojoPropertyChain implements IPropertyChain
{
    
    String[] properties;

    private Class<?> metaClazz;

    public PojoPropertyChain(Object beanMeta, Object... properties)
    {
        Validate.isTrue(beanMeta instanceof Class);
        //FIXME add nested property support
        Validate.isTrue(properties != null && properties.length == 1, "Nested properties support is not yet available!");
        this.metaClazz = (Class<?>) beanMeta;
        this.properties = new String[properties.length];
        System.arraycopy(properties, 0, this.properties, 0, properties.length);
    }  
    
    public Object getModelMeta()
    {
        return metaClazz;
    }

    public Class<?> getType()
    {
    	return getPropertyDescriptor().getPropertyType();
    }

    public Object getValue(Object model)
    {
    	Object result = null;
    	PropertyDescriptor pd = getPropertyDescriptor();
    	if(pd != null)
    	{
            Method method = pd.getReadMethod();
            try {
				result = method.invoke(model, new Object[]{});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    	
    	return result;
    }

    public void setValue(Object model, Object value)
    {
    	PropertyDescriptor pd = getPropertyDescriptor();
    	if(pd != null)
    	{
            Method method = pd.getWriteMethod();
            try {
				method.invoke(model, new Object[]{value});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	}
    }
    
    @Override
    public String toString()
    {
        String result = "PropChain(" + metaClazz.getName(); //$NON-NLS-1$
        for (String prop : properties)
        {
            result += "." + prop; //$NON-NLS-1$
        }
        return result + ")"; //$NON-NLS-1$
    }

    @Override
    public int hashCode()
    {
        return toString().hashCode();
    }
    
    @Override
    public boolean equals(Object obj)
    {
        boolean result = false;
        if(this == obj)
        {
        	result = true;
        }else if (obj instanceof PojoPropertyChain)
        {
            PojoPropertyChain propChain = (PojoPropertyChain) obj;
            if (propChain.getModelMeta() == getModelMeta()
                    && propChain.properties.length == properties.length)
            {
                result = true;
                for (int i = 0; i < properties.length; i++)
                {
                    if (!properties[i].equals(propChain.properties[i]))
                    {
                        result = false;
                        break;
                    }
                }
            }
        }
        return result;
    }

    private PropertyDescriptor getPropertyDescriptor() {
		PropertyDescriptor descriptor = null;

		
		BeanInfo beanInfo = null;
		try {
			beanInfo = Introspector.getBeanInfo(metaClazz);
			PropertyDescriptor[] descriptors = beanInfo.getPropertyDescriptors();
			//TODO add nested property support
			for (PropertyDescriptor propertyDescriptor : descriptors) {
				if (properties[0].equals(propertyDescriptor.getName())) {
					descriptor = propertyDescriptor;
				}
			}
		} catch (IntrospectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return descriptor;
	}
}
