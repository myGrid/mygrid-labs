/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.examples.app.multipageeditor;

import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.form.RCPForm;

public class SandboxTableForm extends RCPForm
{

    public SandboxTableForm(String title, RCPFormPart... parts)
    {
        super(title, parts);
    }

}
