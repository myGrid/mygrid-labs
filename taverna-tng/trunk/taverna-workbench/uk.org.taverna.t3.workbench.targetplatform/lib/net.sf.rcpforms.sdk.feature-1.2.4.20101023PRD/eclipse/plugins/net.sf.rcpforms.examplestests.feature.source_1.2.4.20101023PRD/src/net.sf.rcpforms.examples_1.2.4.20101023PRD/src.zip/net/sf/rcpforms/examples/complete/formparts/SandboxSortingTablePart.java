/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.complete.formparts;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.examples.complete.GenericTableSorter2;
import net.sf.rcpforms.examples.complete.IExpandablePart;
import net.sf.rcpforms.examples.complete.models.IntegerModel;
import net.sf.rcpforms.tablesupport.tables.ColumnConfiguration;
import net.sf.rcpforms.tablesupport.tables.ECellEditorType;
import net.sf.rcpforms.tablesupport.tables.RCPTableData;
import net.sf.rcpforms.tablesupport.tables.TableUtil;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPTable;

import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class SandboxSortingTablePart extends RCPFormPart
implements IExpandablePart
{
    private RCPSection mainSection;

    private RCPTable m_TableSortingSupport;

    private TableViewer m_TableViewerSortingSupport;

    private boolean minimizeSection;

    public SandboxSortingTablePart()
    {
        m_TableSortingSupport = new RCPTable("Table with history sorting support:");
    }

    public SandboxSortingTablePart(boolean minimizeSection)
    {
        this();
        this.minimizeSection = minimizeSection;
    }

    private static GenericTableSorter2[] createAdvancedGenericTableSorters(TableViewer viewer, int length)
    {
        //String[] properties = new String[]{TestModel.P_Name, TestModel.P_BirthDate, TestModel.P_Gender, TestModel.P_OverdrawAccount, TestModel.P_ChildCount, TestModel.P_AccountBalance};
        String[] properties = new String[]{IntegerModel.P_A_PROP, IntegerModel.P_B_PROP, IntegerModel.P_C_PROP, IntegerModel.P_D_PROP};
        Validate.isTrue(length == properties.length);
        GenericTableSorter2[] gts = new GenericTableSorter2[length];
                                                          
        for(int i = 0; i < gts.length; ++i)
        {
            gts[i] = new GenericTableSorter2(viewer, properties[i]);
        }
        return gts;
    }

    @Override
    public void createUI(FormToolkit formToolkit, Composite parent)
    {
        GridBuilder builder = new GridBuilder(formToolkit, parent, 1);
        mainSection = new RCPSection("Sandbox Sorting Table Section");
        GridBuilder sectionBuilder = builder.addContainer(mainSection, 2);

        if(minimizeSection)
            mainSection.getSWTSection().setExpanded(false);
        
        // create normal Table with table cursor support
        sectionBuilder.add(m_TableSortingSupport);
        
        RCPTableData tableData = new RCPTableData();
        boolean editable = false;
        ColumnConfiguration[] colConfig = {
                new ColumnConfiguration("A", IntegerModel.P_A_PROP, 50, SWT.LEFT, false,
                        editable ? ECellEditorType.TEXT : null).setGrabHorizontal(true),
                new ColumnConfiguration("B", IntegerModel.P_B_PROP, 50, SWT.LEFT, false,
                        editable ? ECellEditorType.TEXT : null).setGrabHorizontal(true),
                new ColumnConfiguration("C", IntegerModel.P_C_PROP, 50, SWT.LEFT, false,
                        editable ? ECellEditorType.TEXT : null).setGrabHorizontal(true),
                new ColumnConfiguration("D", IntegerModel.P_D_PROP, 50, SWT.LEFT, false,
                        editable ? ECellEditorType.TEXT : null).setGrabHorizontal(true)};
        
        tableData.columnConfigurations = colConfig;
        tableData.enableSeparateCheckboxColumn = false;
        tableData.enableTableCursorSupport = true;
        tableData.enableAutoresizing = true;
        tableData.columnSorter = createAdvancedGenericTableSorters((TableViewer) m_TableSortingSupport.getViewer(), tableData.columnConfigurations.length);
        
        m_TableViewerSortingSupport = TableUtil.configureTableViewer((TableViewer) m_TableSortingSupport.getViewer(), IntegerModel.class, tableData);
        m_TableViewerSortingSupport.setContentProvider(new ArrayContentProvider());

    }

    @Override
    public void bind(ValidationManager context, Object modelBean)
    {
        m_TableViewerSortingSupport.setInput(IntegerModel.createModel());
    }


    public static void main(String[] args)
    {
        final IntegerModel model = new IntegerModel();
        final RCPFormPart part = new SandboxSortingTablePart();
        RCPFormFactory.getInstance().startTestShell("SandboxSortingTablePart", part, model);
    }

    @Override
    public void setState(EControlState state, boolean value)
    {
        mainSection.setState(state, value);
    }
    
    public void expandPart(boolean doExpand)
    {
        this.mainSection.getSWTSection().setExpanded(doExpand);
    }
}
