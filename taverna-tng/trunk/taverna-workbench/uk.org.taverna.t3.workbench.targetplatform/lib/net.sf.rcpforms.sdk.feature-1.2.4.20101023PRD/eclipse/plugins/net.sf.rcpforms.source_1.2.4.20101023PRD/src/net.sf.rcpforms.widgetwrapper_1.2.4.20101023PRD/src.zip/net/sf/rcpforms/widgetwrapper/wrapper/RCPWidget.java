/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.widgetwrapper.wrapper;

import java.util.HashMap;

import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.widgetwrapper.builder.IFormToolkitEx;
import net.sf.rcpforms.widgetwrapper.util.WidgetUtil;
import net.sf.rcpforms.widgetwrapper.wrapper.event.IWidgetCreationListener;
import net.sf.rcpforms.widgetwrapper.wrapper.event.WidgetCreationEvent;
import net.sf.rcpforms.widgetwrapper.wrapper.internal.RCPWidgetCreateListenerTable;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.events.DisposeListener;
import org.eclipse.swt.widgets.Widget;
import org.eclipse.ui.forms.widgets.FormToolkit;

/**
 * An RCPWidget wraps an SWT widget to enhance it by the following features:
 * <ul>
 * <li>two phase ui creation, widget hierarchy construction phase (constructor) is different from
 * control creation phase ({@link #createUI(FormToolkit)}
 * <li>Creation is rooted via a toolkit, thus by changing the toolkit you can change the overall
 * looks as colors, margins, fonts
 * <li>State Management: wrapped controls offer enhanced control states like READONLY, MANDATORY,
 * RECOMMENDED ({@link RCPControl#setState(EControlState, boolean)}, {@link EControlState} and
 * improve state rendering and behavior of swt states like VISIBLE,ENABLED
 * <li>state binding via a uniform interface; you can bind the widget state to a property and it
 * will automatically refresh on each change
 * <li>hierarchical state management: if a parents state is changed, children states will be updated
 * too, e.g. a disabled parent will not need required field decorations anymore
 * <li>decouple physical containment from logical containment, e.g. a child of a RCPSection will
 * automatically be added as a child to the Section Composite, significantly reducing programming
 * errors and easing enhancement with new widgets
 * <li>default style: if you pass {@link SWT#DEFAULT} as a style during construction of a RCPWidget,
 * a default style is taken from the FormToolkit passed; this avoids hardcoding defaults into the
 * application.
 * </ul>
 * 
 * @author Marco van Meegen
 * @author Remo Loetscher
 */
public class RCPWidget
{
    /**
     * Property for saving the universal id of this widget.
     */
    public static final String UID = "rcpforms.uid";
    
    private Widget wrappedWidget;
    
    protected RCPWidgetCreateListenerTable eventTable;
    
    /** This map serves to store client specific values set and read by
     * {@link #setCustomProperty()} and {@link #getCustomProperty(String)}. 
     * These custom-properties do not have any effect. */
    private HashMap<String, Object> customPropertyMap = null;

    private DisposeListener disposeListener = new DisposeListener()
    {
        public void widgetDisposed(DisposeEvent e)
        {
            // if swt widget is disposed, cleanup any listeners
            onDispose();
        }
    };

    /**
     * internal id of the control, internally used for debug logging, maybe used for GUI testing
     * tools
     */
    private String id;

    /**
     * text label to apply to the control; mainly used for control like Group, Button which include
     * a label, but also set on a {@link RCPLabeledControl} as the text of the label control.
     */
    private String label;

    private int style;

    /**
     * the toolkit used to create this display; colors and other resources are accessed via the
     * toolkit
     */
    protected FormToolkit formToolkit = null;

    public RCPWidget()
    {

    }

    /**
     * create a widget with the given labelText (if the widget has a text, e.g. a button)
     * 
     * @param labelText labelText to set for the widget, maybe be null if no label text needed or
     *            widget does not support a label text
     * @param style SWT style to create widget with; subclasses may add some style, e.g. RCPCheckbox
     *            will add SWT.CHECK style; maybe SWT.DEFAULT which calls the FormToolkit method
     *            without handling a style, thus enabling the Formtoolkit to define the default
     */
    public RCPWidget(String labelText, int style)
    {
        this(labelText, style, null);
    }
    
    /**
     * create a widget with the given labelText (if the widget has a text, e.g. a button)
     * 
     * @param labelText labelText to set for the widget, maybe be null if no label text needed or
     *            widget does not support a label text
     * @param style SWT style to create widget with; subclasses may add some style, e.g. RCPCheckbox
     *            will add SWT.CHECK style; maybe SWT.DEFAULT which calls the FormToolkit method
     *            without handling a style, thus enabling the Formtoolkit to define the default
     * @param uid Unique ID for this widget. After widget creation ({@link RCPWidget#doCreateUI(FormToolkit)})id will be set to the widgets data store using the {@link RCPWidget#UID} property.
     */
    public RCPWidget(String labelText, int style, Object uid)
    {
        this.label = labelText;
        this.id = labelText != null ? labelText : generateId();
        Validate.notNull(id);
        if(uid != null)
        {
            customPropertyMap = initPropertyMap();
            customPropertyMap.put(UID, uid);
        }
        this.style = style;
    }

    /**
     * @return a unique id
     */
    private String generateId()
    {
        return super.toString();
    }

    protected Widget getWrappedWidget()
    {
        return wrappedWidget;
    }

    /**
     * simplified way for widget handling if exactly one swt control is wrapped; you only need to
     * override this method to create the control using the formtoolkit.
     * <p>
     * ATTENTION: Since RCPWidgets support SWT.DEFAULT as flag that no style was specified, but
     * FormToolkit does not, this must be handled here ! Do not call super(), it will throw an
     * exception.
     * 
     * @param formToolkit toolkit to use to create the widget
     * @return created widget, createUI will automatically initialize it correctly to work with the
     *         wrappers
     */
    protected Widget createWrappedWidget(FormToolkit formToolkit)
    {
        Validate.isTrue(false, this.getClass().getName() + " must override createWrappedWidget()"); //$NON-NLS-1$
        return null;
    }

    /**
     * internal use only, if a widget is already existing and should be wrapped.
     */
    protected void setWrappedWidget(Widget widget)
    {
        this.wrappedWidget = widget;
    }

    @SuppressWarnings("unchecked")
    public final <T> T getTypedWidget()
    {
        return (T) getWrappedWidget();
    }

    /**
     * typed convenience method to retrieve the swt widget
     * 
     * @return swt widget
     * @throws IllegalStateException if widget is not available or disposed
     */
    public final Widget getSWTWidget()
    {
        return getTypedWidget();
    }

    /**
     *explicitly dispose the associated widget; do not do cleanup here !
     * <p>
     * cleanup will be done in {@link #onDispose()}
     * 
     * @see org.eclipse.swt.widgets.Widget#dispose()
     */
    public void dispose()
    {
        if (wrappedWidget != null)
        {
            wrappedWidget.dispose();
            //free for gc
            wrappedWidget = null;
        }
    }

    /**
     * called when the associated swt widget is disposed; must clean up all listeners and local
     * resources
     * 
     * @see org.eclipse.swt.widgets.Widget#dispose()
     */
    protected void onDispose()
    {
    }

    /**
     * @return the label text passed in the constructor, maybe null
     */
    public String getLabel()
    {
        return label;
    }

    /**
     * @return the internal id passed in the constructor, always != null, should be unique for each
     *         control
     * @deprecated use uid constructor for setting and {@link RCPWidget#getUID()}
     */
    public String getId()
    {
        return id;
    }
    
    /**
     * Returns string representation of the uid. If the uid object is a string object it will return the object itself. On all other objects the String representation {@link Object#toString()}
     * will be returned. If the uid is not set or is null, an empty string ("") will be returned.
     * @return string representation of the uid object
     */
    public String getUIDString()
    {
        Object returnUID = null;
        //get uid object
        if (getWrappedWidget() != null)
        {
            returnUID = getWrappedWidget().getData(RCPWidget.UID);
        }else
        {
            returnUID = customPropertyMap == null ? null : customPropertyMap.get(UID);
        }
        //return string representation of the uid
        if(returnUID != null)
        {
            return returnUID instanceof String ? (String) returnUID : returnUID.toString();
        }else
        {
            return "";
        }
    }
    
    /**
     * @return the unique identifier for this widget or null if none is set
     */
    public Object getUID()
    {
        if (getWrappedWidget() != null)
        {
            return getWrappedWidget().getData(RCPWidget.UID);
        }else
        {
            return customPropertyMap == null ? null : customPropertyMap.get(UID);
        }
    }
    
    /**
     * Set new uid. If wrapped widget is already created the uid will be set directly on the data-structure of the widget using the {@link RCPWidget#UID} property:
     * {@link Widget#setData(RCPWidget#UID, Object)}. If the wrapped widget is not yet created the uid will be cached and set to the Widget data when {@link RCPWidget#doCreateUI(FormToolkit)} is called.
     * @param new uid
     * @return rcpwidget itself. Useful for compact coding like: RCPText text = new RCPText("Foo").setUID(uid);
     */
    public <THIS extends RCPWidget> THIS setUID(Object uid)
    {
        if (getWrappedWidget() != null)
        {
            getWrappedWidget().setData(RCPWidget.UID);
        }else
        {
         // not yet spawned, cache it in own map:
            if (customPropertyMap == null)
            {
                customPropertyMap = initPropertyMap();
            }
            customPropertyMap.put(UID, uid);
        }
        return (THIS) this;
    }
    
    /**
     * Sets a value for any client-implementation specific property, further called
     *  a <i>custom property</i>. The value set is not verified in any way nor does
     *  it have any side effects. This mechanism only serves as a convenient way
     *  for client implementations to associate any values to this widget.
     *  <p>
     *  This is a wrapping to the mechanism <code>setData</code> of <i>SWT-Widgets</i>;
     *  Any settings are cached until the SWT-widget is created. At this moment, the
     *  values are stored directly in the SWT-widget via <code>setData</code> and the
     *  local cache is cleared. 
     *  <p>
     *  <u>Note:</u> does not have any side-effects!
     * 
     * @param key 
     * @param value 
     * @since 1.1.0
     * @author spicherc   (Oct 20, 2009)
     */
    public void setCustomProperty(final String key, final Object value) {
        Validate.notNull(key, "key");
        Validate.isTrue(key.length() > 0, "key.length > 0");
        if (getWrappedWidget() != null)
        {
            // already spawned, so write through:
            getWrappedWidget().setData(key, value);
        } else {
            // not yet spawned, cache it in own map:
            if (customPropertyMap == null && value != null)
            {
                customPropertyMap = initPropertyMap();
            }
            if (value == null)
            {
                // remove from map:
                customPropertyMap.remove(key);
                if (customPropertyMap.isEmpty())
                {
                    customPropertyMap = null; // clean up if this was the last property
                }
            } else {
                customPropertyMap.put(key, value);
            }
        }
    }
    
    private static HashMap<String, Object> initPropertyMap()
    {
        return new HashMap<String, Object>(5);
    }
    
    /**
     * Returns the value previously set by {@link #setCustomProperty(String, Object)}
     * with the same <code>key</code>. Has no side effects and does not check anything
     * except for the key may not be <code>null</code>.
     * <p>
     * <u>Note:</u> previously set data on the wrapped SWT-widget 
     * ({@link org.eclipse.swt.widgets.Widget#setData(String, Object)}) is returned
     * as well!
     * 
     * @param key the key assigned to this <i>custom property</i>, must not be <code>null</code>
     * 
     * @return the value of this <i>custom property</i> 
     * @since 1.1.0
     * @author spicherc   (Oct 20, 2009)
     */
    public Object getCustomProperty(final String key) {
        Validate.notNull(key, "key");
        Validate.isTrue(key.length() > 0, "key.length > 0");
        if (getWrappedWidget() != null)
        {
            // read through:  (cash is empty anyway)
            return getWrappedWidget().getData(key);
        } else {
            // if map == null --> no client props set yet
            return customPropertyMap == null ? null : customPropertyMap.get(key);
        }
    }

    /**
     * Similar to {@link #getCustomProperty(String)} but conveniently casts the resulting
     * value to the specified type <code>customPropertyType</code>
     * <p>
     * <u>Note:</u> previously set data on the wrapped SWT-widget 
     * ({@link org.eclipse.swt.widgets.Widget#setData(String, Object)}) is returned
     * as well!
 
     * @param customPropertyType the type the value of this <i>custom property</i> is of, may 
     * not be <code>null</code> 
     * @param key may not be <code>null</code>
     * 
     * @return value assigned to this <code>key</code> casted to the specified type
     * @throws IllegalArgumentException if the parameter to this <code>key</code> is known
     *         but not of requested type <code>customPropertyType</code>. (Note: is
     *         <b>not</b> of type ClassCastException which is an Exception while
     *         IllegalArgumentException is an Error... so, try-catch must not be
     *         put around every <code>getCustomProperty</code> call.)
     * @since 1.1.0
     * @author spicherc   (Oct 20, 2009)
     */
    public <T> T getCustomProperty(final Class<T> customPropertyType, final String key) {
        Validate.notNull(customPropertyType, "customPropertyType");
        Object result = getCustomProperty(key);
        if (result != null && !customPropertyType.isAssignableFrom(result.getClass()))
        {
            throw new IllegalArgumentException("can't cast custom property '"+key+"': is not of type "
                    + customPropertyType.getName() + " but of type " + result.getClass());
        }
        return (T) result;// note: this cast will NOT cause any classcastexception even if
        // result is not of type T!  (being dropped by java compiler)
    }

    /**
     * creates the swt control associated with this widget. Parent must have been set before.
     * 
     * @param formToolkit formToolkit to use for creating the swt control. For most widgets the
     *            FormToolkit must implement {@link IFormToolkitEx} interface which enhances the
     *            toolkit with all creation methods needed by RCPForms widgets.
     */
    public void createUI(FormToolkit formToolkit)
    {
        doCreateUI(formToolkit);
    }

    /**
     * does the pure widget creation using createWrappedWidget, initializes the formtoolkit but does
     * not care about children.
     * If a uid is set the uid object will be set to the created wrapped widget here.
     * If a subclass override this method it has to call this method or set the uid by itself on the wrapped widget.
     * Note also if no super call is done events ({@link WidgetCreationEvent}) for {@link IWidgetCreationListener} have to be fired manually.
     * 
     * @param formToolkit toolkit to use
     */
    protected void doCreateUI(FormToolkit formToolkit)
    {
        Validate.notNull(formToolkit);
        this.formToolkit = formToolkit;
        wrappedWidget = createWrappedWidget(formToolkit);
        WidgetUtil.ensureValid(this);
        if (wrappedWidget != null)
        {
            wrappedWidget.addDisposeListener(disposeListener);
            moveCustomPropertiesToWidget();
            //notify listener for widget creation
            if (eventTable != null)
                fireWidgetCreationEvent(new WidgetCreationEvent(wrappedWidget));
        }
        
    }
    

    protected void fireWidgetCreationEvent(WidgetCreationEvent widgetCreationEvent)
    {
        if (eventTable != null)
            eventTable.sendEvent(widgetCreationEvent);
    }

    protected void moveCustomPropertiesToWidget()
    {
        //if no properties are set: nothing to do here.
        if(customPropertyMap == null)
            return;
        
        if(customPropertyMap.containsKey(UID))
        {
            //set uid as first data object on the widget
            getWrappedWidget().setData(UID, customPropertyMap.get(UID));
            customPropertyMap.remove(UID);
        }
        //add all other properties
        if(!customPropertyMap.isEmpty())
        {
            for(String key : customPropertyMap.keySet())
            {
                getWrappedWidget().setData(key, customPropertyMap.get(key));
            }
        }

        customPropertyMap.clear();
    }

    /**
     * number of layout cells (controls) occupied by this widget, cell spans are not accounted for.
     * usually 2 for labeled widgets, otherwise 1
     * 
     * @return number of layout cells
     */
    public int getNumberOfControls()
    {
        return 1;
    }

    /**
     * for some widgets there is no create method in FormToolkit. These need an extended formtoolkit
     * which can be retrieved with this method.
     * 
     * @return extended form toolkit
     * @throws IllegalArgumentException if the toolkit passed does not implement IFormToolkitEx
     */
    public final IFormToolkitEx getFormToolkitEx()
    {
        Validate.notNull(formToolkit,
                "createUI has not been called yet, thus form toolkit not available"); //$NON-NLS-1$
        Validate
                .isTrue(
                        formToolkit instanceof IFormToolkitEx,
                        "The widget you created needs an extended FormToolkit. Make sure your FormToolkit implements IFormToolkitEx."); //$NON-NLS-1$
        return (IFormToolkitEx) formToolkit;
    }

    /**
     * retrieves the formtoolkit this widget was created with. colors, fonts etc. must be maintained
     * in the formtoolkit.
     * 
     * @return form toolkit
     * @throws IllegalArgumentException if the toolkit passed does not implement IFormToolkitEx
     */
    protected final FormToolkit getFormToolkit()
    {
        Validate.notNull(formToolkit,
                "createUI has not been called yet, thus form toolkit not available"); //$NON-NLS-1$
        return formToolkit;
    }

    /**
     * @return swt style which was passed in constructor, ATTENTION: maybe SWT.DEFAULT; if you want
     *         the resolved default style, use getSWTWidget().getStyle()
     * @see org.eclipse.swt.widgets.Widget#getStyle()
     */
    public int getStyle()
    {
        return style;
    }
    
    /**
     * @param listener adds a listener which is called after a successful creation of the {@link RCPWidget#wrappedWidget} which means that the swt resource was allocated. If this listener is called {@link WidgetUtil#isValid(RCPWidget)} is true, until widget is disposed.
     */
    public void addWidgetCreationListener(IWidgetCreationListener listener)
    {
        if (eventTable == null)
            eventTable = new RCPWidgetCreateListenerTable();
        eventTable.hook(listener);
    }

    /**
     * @param listener removes a listener which is called after a successful creation of the {@link RCPWidget#wrappedWidget}. 
     */
    public void removeWidgetCreationListener(IWidgetCreationListener listener)
    {
        if (listener == null)
            SWT.error(SWT.ERROR_NULL_ARGUMENT);
        if (eventTable == null)
            return;
        eventTable.unhook(listener);
    }
}
