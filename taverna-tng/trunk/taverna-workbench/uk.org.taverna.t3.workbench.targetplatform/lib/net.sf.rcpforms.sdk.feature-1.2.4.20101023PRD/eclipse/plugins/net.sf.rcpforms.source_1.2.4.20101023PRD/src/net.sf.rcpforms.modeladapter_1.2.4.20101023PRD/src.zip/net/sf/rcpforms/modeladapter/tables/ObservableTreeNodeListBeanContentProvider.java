/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.modeladapter.tables;

import java.beans.PropertyChangeListener;

import org.eclipse.jface.viewers.TreeNode;

/**
 * Content Provider which observes a writable list of {@link TreeNode} Objects for changes. It attaches to all beans in
 * the list and refreshes the viewer if a property of the bean changes.
 * FIXME remsy updates in single model elements don't work at the moment.
 * 
 * @author Remo Loetscher
 */

public class ObservableTreeNodeListBeanContentProvider
    extends ObservableTreeListBeanContentProvider
{

    public ObservableTreeNodeListBeanContentProvider()
    {
        super();
        listenerSupport = new TreeNodeListenerSupport(beanListener);
    }

    @Override
    public Object[] getChildren(Object parentElement)
    {
        return ((TreeNode)parentElement).getChildren();
    }

    @Override
    public Object getParent(Object element)
    {
        return ((TreeNode)element).getParent();
    }

    @Override
    public boolean hasChildren(Object element)
    {
        return ((TreeNode)element).hasChildren();
    }
    
    protected void handleBeanPropertyChange(Object bean, String propertyName)
    {
        viewer.update(new TreeNode(bean), new String[]{propertyName});
    }

}

class TreeNodeListenerSupport extends ListenerSupport
{

    public TreeNodeListenerSupport(PropertyChangeListener listener)
    {
        super(listener);
    }

    @Override
    public void hookListener(Object target)
    {
        if(target instanceof TreeNode)
            super.hookListener(((TreeNode)target).getValue());
        else
            super.hookListener(target);
    }

    @Override
    public void unhookListener(Object target)
    {
        if(target instanceof TreeNode)
            super.unhookListener(((TreeNode)target).getValue());
        else
            super.unhookListener(target);
    }
}