package net.sf.rcpforms.examples.complete.formparts;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.common.NullValue;
import net.sf.rcpforms.common.util.Validate;
import net.sf.rcpforms.examples.complete.IExpandablePart;
import net.sf.rcpforms.examples.complete.models.MasterDetailModel;
import net.sf.rcpforms.examples.complete.models.TestModel;
import net.sf.rcpforms.examples.complete.models.TestModel.Gender;
import net.sf.rcpforms.examples.complete.widgets.MasterDetail_DetailGroup;
import net.sf.rcpforms.modeladapter.configuration.BeanAdapter;
import net.sf.rcpforms.tablesupport.tables.ColumnConfiguration;
import net.sf.rcpforms.tablesupport.tables.ECellEditorType;
import net.sf.rcpforms.tablesupport.tables.RCPTableData;
import net.sf.rcpforms.tablesupport.tables.TableUtil;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleTable;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;

public class SandboxTableMasterDetailFormPart extends RCPFormPart
implements IExpandablePart
{
    private MasterDetailModel model;
    private RCPSection mainSection;
    private MasterDetail_DetailGroup detailGroup = new MasterDetail_DetailGroup();
    
    private RCPSimpleTable m_Table = new RCPSimpleTable(SWT.SINGLE);
    private TableViewer m_TableViewer;
    private boolean minimizeSection;


    public SandboxTableMasterDetailFormPart(boolean minimizeSection)
    {
        this();
        this.minimizeSection = minimizeSection;
    }

    public SandboxTableMasterDetailFormPart()
    {
        super();
    }

    @Override
    public void bind(ValidationManager bm, Object modelBean)
    {
        this.model = (MasterDetailModel) modelBean;
        m_TableViewer.setInput(model.getList());
        bm.bindDetailValue(BeanAdapter.getInstance(), m_Table, TestModel.class, new RCPControl[]{detailGroup.name,
            detailGroup.birthDate, detailGroup.age, detailGroup.overdrawAccount, detailGroup.childCount, detailGroup.accountBalance, detailGroup.gender},
            new String[]{TestModel.P_Name, TestModel.P_BirthDate, TestModel.P_Age,
                    TestModel.P_OverdrawAccount, TestModel.P_ChildCount,
                    TestModel.P_AccountBalance, TestModel.P_Gender});
    }

    @Override
    public void createUI(FormToolkit toolkit, Composite parent)
    {
        GridBuilder mainBuilder = new GridBuilder(toolkit, parent, 2);
        mainSection = new RCPSection("TableMasterDetail binding");
        GridBuilder section = mainBuilder.addContainer(mainSection, 2);
        
        if(minimizeSection)
            mainSection.getSWTSection().setExpanded(false);
        
        section.add(m_Table);
        RCPTableData td = new RCPTableData();
        td.enableSeparateCheckboxColumn = false;
        td.enableTableCursorSupport = false;
        td.columnConfigurations = createColumnConfigurations(false);
       
        m_TableViewer = TableUtil.configureTableViewer((TableViewer) m_Table.getViewer(), TestModel.class, td);
        
        detailGroup.createUI(toolkit, section);
        
        toolkit.paintBordersFor(parent);
    }

    private static ColumnConfiguration[] createColumnConfigurations(boolean editable)
    {
        // this configures the table with the attributes to display;
        // automatic conversion will be applied using the standard data binding converters
        // which are used in text fields too
        Object[] values = new Object[Gender.values().length + 1];
        // add null value
        values[0] = NullValue.getInstance();
        System.arraycopy(Gender.values(), 0, values, 1, values.length - 1);
        ColumnConfiguration[] columnConfigurations = {
                new ColumnConfiguration("Name", TestModel.P_Name, 100, SWT.LEFT, false,
                        editable ? ECellEditorType.TEXT : null).setGrabHorizontal(true)};
        Validate.noNullElements(columnConfigurations,
                "ColumnConfigurations must not have null elements");
        return columnConfigurations;
    }
    
    @Override
    public void setState(EControlState state, boolean value)
    {
        mainSection.setState(state, value);
    }
    
    public void expandPart(boolean doExpand)
    {
        this.mainSection.getSWTSection().setExpanded(doExpand);
    }
    
    public static void main(String[] args)
    {
        final MasterDetailModel model = new MasterDetailModel();
        final RCPFormPart part = new SandboxTableMasterDetailFormPart();
        RCPFormFactory.getInstance().startTestShell("SandboxTableMasterDetailPart", part, model);
    }

}
