package net.sf.rcpforms.examples.complete.models;

import net.sf.rcpforms.common.model.JavaBean;

public class IntegerModel extends JavaBean
{
    
    public static final String P_A_PROP = "aprop";
    
    public static final String P_B_PROP = "bprop";

    public static final String P_C_PROP = "cprop";

    public static final String P_D_PROP = "dprop";
    
    private Integer aprop; 
    private Integer bprop; 
    private Integer cprop; 
    private Integer dprop;
    
    
    public IntegerModel()
    {
        super();
    }

    public IntegerModel(Integer aprop, Integer bprop, Integer cprop, Integer dprop)
    {
        super();
        this.aprop = aprop;
        this.bprop = bprop;
        this.cprop = cprop;
        this.dprop = dprop;
    }
    
    public Integer getAprop()
    {
        return aprop;
    }
    public void setAprop(Integer value)
    {
        Object oldValue = aprop;
        aprop = value;
        propertyChangeSupport.firePropertyChange(P_A_PROP, oldValue, value);
        this.aprop = value;
    }
    public Integer getBprop()
    {
        return bprop;
    }
    public void setBprop(Integer value)
    {
        Object oldValue = bprop;
        bprop = value;
        propertyChangeSupport.firePropertyChange(P_B_PROP, oldValue, value);
        this.bprop = value;
    }
    public Integer getCprop()
    {
        return cprop;
    }
    public void setCprop(Integer value)
    {
        Object oldValue = cprop;
        cprop = value;
        propertyChangeSupport.firePropertyChange(P_C_PROP, oldValue, value);
        this.cprop = value;
    }
    public Integer getDprop()
    {
        return dprop;
    }
    public void setDprop(Integer value)
    {
        Object oldValue = dprop;
        dprop = value;
        propertyChangeSupport.firePropertyChange(P_D_PROP, oldValue, value);
        this.dprop = value;
    }
    public static Object[] createModel()
    {
        IntegerModel[] model = new IntegerModel[]{
                new IntegerModel(1, 1, 1, 4),
                new IntegerModel(1, 1, 2, 3),
                new IntegerModel(1, 2, 3, 2),
                new IntegerModel(1, 2, 4, 1),
                new IntegerModel(2, 3, 1, 4),
                new IntegerModel(2, 3, 2, 3),
                new IntegerModel(2, 4, 3, 2),
                new IntegerModel(2, 4, 4, 1),
                new IntegerModel(3, 1, 1, 4),
                new IntegerModel(3, 1, 2, 3),
                new IntegerModel(3, 2, 3, 2),
                new IntegerModel(3, 2, 4, 1),
                new IntegerModel(4, 3, 1, 4),
                new IntegerModel(4, 3, 2, 3),
                new IntegerModel(4, 4, 3, 2),
                new IntegerModel(4, 4, 4, 1),
        };
        
        return model;
    } 
}
