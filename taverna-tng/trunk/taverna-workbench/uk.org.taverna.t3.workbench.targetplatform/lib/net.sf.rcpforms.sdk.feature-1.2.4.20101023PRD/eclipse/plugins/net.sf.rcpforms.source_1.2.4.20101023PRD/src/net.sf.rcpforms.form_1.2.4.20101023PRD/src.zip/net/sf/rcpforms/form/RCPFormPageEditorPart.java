/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.form;

import org.eclipse.swt.custom.BusyIndicator;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.editor.FormEditor;
import org.eclipse.ui.forms.editor.IFormPage;

/**
 * Class RCPFormEditorPart embeds an RCPForm into an Eclipse Editor.
 * Use this class if you have a {@link FormEditor} and you need lazy instantiation of the several editor pages.
 */

public abstract class RCPFormPageEditorPart<T extends RCPForm> extends RCPFormEditorPart<T> implements IFormPage
{

    private FormEditor editor;
    private int index;
    private String id;
    
    /**
     * A constructor that creates the page and initializes it with the editor.
     * 
     * @param editor
     *            the parent editor
     * @param id
     *            the unique identifier
     * @param title
     *            the page title
     */
    public RCPFormPageEditorPart(FormEditor editor, T form, String id, String title) {
        this(form, id, title);
        initialize(editor);
    }
    /**
     * The constructor. The parent editor need to be passed in the
     * <code>initialize</code> method if this constructor is used.
     * 
     * @param id
     *            a unique page identifier
     * @param title
     *            a user-friendly page title
     */
    public RCPFormPageEditorPart(T form, String id, String title) {
        super(form);
        this.id = id;
        setPartName(title);
    }


    @Override
    public void createPartControl(final Composite parent)
    {
        BusyIndicator.showWhile(parent.getDisplay(), new Runnable() {
            public void run() {
                RCPFormPageEditorPart.super.createPartControl(parent);
            }
        });
        
    }
    public boolean canLeaveThePage()
    {
//        IStatus status = (IStatus) form.getValidationManager().getValidationState().getValue();
//        return status.getSeverity() == IStatus.OK;
        return true;
    }

    public FormEditor getEditor()
    {
        return this.editor;
    }

    public String getId()
    {
        return this.id;
    }

    public int getIndex()
    {
        return this.index;
    }

    public IManagedForm getManagedForm()
    {
        return form.getManagedForm();
    }

    public Control getPartControl()
    {
        return form.getManagedForm() != null ? form.getManagedForm().getForm() : null;
    }

    public void initialize(FormEditor editor)
    {
        this.editor = editor;
    }

    public boolean isActive()
    {
        return this.equals(editor.getActivePageInstance());
    }

    public boolean isEditor()
    {
        return false;
    }

    public abstract boolean selectReveal(Object object);
//    {
//        // TODO Auto-generated method stub
//        return false;
//    }

    public void setActive(boolean active)
    {
        if (active) {
            // We are switching to this page - refresh it
            // if needed.
            form.getManagedForm().refresh();
        }
        
    }

    public void setIndex(int index)
    {
        this.index = index;
    }
    
    
}
