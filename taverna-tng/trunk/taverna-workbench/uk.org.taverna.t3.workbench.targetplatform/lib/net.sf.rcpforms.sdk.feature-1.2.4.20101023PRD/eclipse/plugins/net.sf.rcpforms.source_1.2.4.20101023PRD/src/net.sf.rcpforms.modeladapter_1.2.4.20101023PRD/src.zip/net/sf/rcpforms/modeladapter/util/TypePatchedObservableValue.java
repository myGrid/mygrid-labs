package net.sf.rcpforms.modeladapter.util;

import org.eclipse.core.databinding.observable.IChangeListener;
import org.eclipse.core.databinding.observable.IStaleListener;
import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.core.databinding.observable.value.IValueChangeListener;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * Due to the fact that <code>BeansObservables.observeDetailValue</code> returns a
 * {@link IObservableValue} with a pre-calculated return type (given by {@link #getValueType()})
 * that often is not precise enough, this class should fix that issue by simply wrapping any
 * <code>IObservableValue</code> but changing <code>getValueType</code> this way:
 * 
 * <pre>
 * <span style='color:darkmagenta'>public</span> Object getValueType()
 * {
 *     <span style='color:darkmagenta'>try</span>
 *     {
 *         Object value = <b><span style='color:blue'>wrapped</span>.getValue()</b>;  <span style='color:darkgreen'>// try read actual value</span>
 *         <span style='color:darkmagenta'>if</span> (value != <span style='color:darkmagenta'>null</span>)
 *         {
 *             <span style='color:darkmagenta'>return</span> value.getClass();  <span style='color:darkgreen'>// give actual type if possible</span>
 *         }
 *     }
 *     <span style='color:darkmagenta'>catch</span> (Exception ex)
 *     {
 *         <span style='color:darkgreen'>// ignore</span>
 *     }
 *     <span style='color:darkgreen'>// if actual type was not computable, fall back to existing value:</span>
 *     <span style='color:darkmagenta'>return</span> <span style='color:blue'>wrapped</span>.getValueType();
 * }
 * 
 * </pre>
 * 
 * Thus, the existing type information is only used as a fallback if no actual type
 * is readable yet. But whenever further info -- i.e. the actual value -- is available,
 * that type info is used instead.
 * 
 * @author Christian Spicher
 * @since 1.1
 */

public class TypePatchedObservableValue implements InvocationHandler
{
    private final IObservableValue m_wrapped;

    public static IObservableValue Wrap(final IObservableValue observableValue) {
        //FIXME Bundle Classloading mechanism HOWTO...
//        try
//        {
//            Class loadClass = Activator.getDefault().getBundle().loadClass(observableValue.getClass().getName());
//            ClassLoader classLoader = loadClass.getClassLoader();
//        }
//        catch (ClassNotFoundException e)
//        {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
        ClassLoader classLoader = observableValue.getClass().getClassLoader();
        return (IObservableValue) Proxy.newProxyInstance(classLoader, new Class[] {IObservableValue.class}, new TypePatchedObservableValue(observableValue));
    }
    
    public TypePatchedObservableValue(final IObservableValue wrapped) {
        m_wrapped = wrapped;
    }

    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable
    {
        if (method.getName().equals("getValueType") && method.getParameterTypes().length == 0)// && method.getReturnType() != null)
        {
            // used fixed-method:
            return getValueType(m_wrapped);
        }
        // else: simply call wrap:
        return method.invoke(m_wrapped, args);
    }
    
    /** Fixes value-type issues by reading actual type if available 
     */
    private static Object getValueType(final IObservableValue wrapped) {
        try {
            Object value = wrapped.getValue();
            if (value != null) {
                return value.getClass();
            }
        } catch (Exception ex) {
            // ignpore
        }
        return wrapped.getValueType();
    }    

}