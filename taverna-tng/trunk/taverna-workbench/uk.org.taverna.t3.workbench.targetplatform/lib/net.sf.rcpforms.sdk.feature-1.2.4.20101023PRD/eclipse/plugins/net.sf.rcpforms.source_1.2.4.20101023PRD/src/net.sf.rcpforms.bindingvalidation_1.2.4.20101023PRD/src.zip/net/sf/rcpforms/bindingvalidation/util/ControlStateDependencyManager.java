/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.bindingvalidation.util;

import java.util.ArrayList;
import java.util.HashMap;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.modeladapter.converter.RequiredValidator;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;

public class ControlStateDependencyManager extends RequiredValidator {
	
	private HashMap<Object, ControlStateDependencyBean> m_beanMap = new HashMap<Object, ControlStateDependencyBean>();
	
	public ControlStateDependencyManager(Object bean, Object... properties) {

		super(properties);
		
		for(Object p: properties) {
			ControlStateDependencyBean csdBean = new ControlStateDependencyBean();
			m_beanMap.put(p, csdBean);
		}
		
		setDecorateField(false);
		setShowMessage(false);
	}
	
	private ControlStateDependencyBean getController(Object property) {
		return m_beanMap.get(property);
	}
	
	 /**
     * Binds the widget to the widget state bean of the given property.
     * @param vm ValidationManager used for binding
     * @param control control which has to be bound to the model property
     * @param property property for binding
     */
	public void bind(ValidationManager vm, RCPControl control, String property) {
		this.bindStates(vm, control, property);
	}
	
	/**
	 * Convenience method which binds property to model and the widget states to the state bean.
	 * @param vm ValidationManager used for binding
	 * @param control control which has to be bound to the model property
	 * @param model model to bind the property
	 * @param property property for binding
	 */
	public void bindValue(ValidationManager vm, RCPControl control, Object model, String property)
	{
	    vm.bindValue(control, model, property);
	    this.bindStates(vm, control, property);
	}
	
	/**
     * Binds the states {@link EControlState#VISIBLE}, {@link EControlState#ENABLED},
     * {@link EControlState#READONLY}, {@link EControlState#MANDATORY}, {@link EControlState#RECOMMENDED}
     * to the widget state bean.
     * This method is intended to be overwritten by clients to change or add bindings.
     * 
     * @param vm ValidationManager used for binding
     * @param control control which has to be bound to the model property
     * @param property property for binding
     */
	protected void bindStates(ValidationManager vm, RCPControl control, String property)
    {
        vm.bindState(control, EControlState.VISIBLE, getController(property),
                ControlStateDependencyBean.PROP_VISIBLE);
        vm.bindState(control, EControlState.ENABLED, getController(property),
                ControlStateDependencyBean.PROP_ENABLED);
        vm.bindState(control, EControlState.READONLY, getController(property),
                ControlStateDependencyBean.PROP_READONLY);
        vm.bindState(control, EControlState.MANDATORY, getController(property),
                ControlStateDependencyBean.PROP_MANDATORY);
        vm.bindState(control, EControlState.RECOMMENDED, getController(property),
                ControlStateDependencyBean.PROP_RECOMMENDED);
    }

	public void setVisibleState(String property, boolean newValue) {
		getController(property).setStateVisible(newValue);
	}

	public void setEnableState(String property, boolean newValue) {
		getController(property).setStateEnabled(newValue);
	}

	public void setReadonlyState(String property, boolean newValue) {
		getController(property).setStateReadonly(newValue);
	}

	public void setRecommendedState(String property, boolean newValue) {
		getController(property).setStateRecommended(newValue);
	}

	public void setMandatoryState(String property, boolean newValue) {
		getController(property).setStateMandatory(newValue);
	}
		
    public Object[] getInvalidProperties(Object model)
    {
    	ArrayList<Object> props = new ArrayList<Object>(); 
    	
        Object[] missing = super.getInvalidProperties(model);
        for(Object o: missing) {
        	if(Boolean.TRUE.equals(getController(o).getStateMandatory())) {
        		props.add(o);
        	}
        }
        
        return props.toArray();
    }
    
    public void dispose() {
    }
}
