package net.sf.rcpforms.examples.complete.models;

import net.sf.rcpforms.common.model.JavaBean;

public class SimpleBean extends JavaBean{
    public static final String P_TEXT = "text";
    
    private String text;
    public String getText()
    {
        return text;
    }
    
    public void setText(String newValue)
    {
        String oldValue = text;
        text = newValue;
        propertyChangeSupport.firePropertyChange(P_TEXT, oldValue, text);
    }
    
}