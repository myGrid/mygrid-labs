/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Marco van Meegen - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.examples.complete;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.LinkedList;
import java.util.List;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.examples.complete.formparts.ControlStateDependencyFormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxGeneralFormPart;
import net.sf.rcpforms.examples.complete.formparts.Sandbox3FormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxDualListSelectionPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxIconTextFormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxLayoutFormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxListMasterDetailFormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxListPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxMasterDetailFormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxRangeSampleFormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxSortingTablePart;
import net.sf.rcpforms.examples.complete.formparts.SandboxTableMasterDetailFormPart;
import net.sf.rcpforms.examples.complete.formparts.SandboxTablePart;
import net.sf.rcpforms.examples.complete.models.AddressModel;
import net.sf.rcpforms.examples.complete.models.IntegerRangeTestModel;
import net.sf.rcpforms.common.model.JavaBean;
import net.sf.rcpforms.examples.complete.models.IntegerModel;
import net.sf.rcpforms.examples.complete.models.MasterDetailModel;
import net.sf.rcpforms.examples.complete.models.NestedAddressModel;
import net.sf.rcpforms.examples.complete.models.SimpleBean;
import net.sf.rcpforms.examples.complete.models.TableModel;
import net.sf.rcpforms.examples.complete.models.TestModel;
import net.sf.rcpforms.form.RCPForm;
import net.sf.rcpforms.modeladapter.converter.AbstractModelValidator;
import net.sf.rcpforms.widgetwrapper.builder.ColumnLayoutFactory;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;

import org.eclipse.core.databinding.observable.ChangeEvent;
import org.eclipse.core.databinding.observable.IChangeListener;
import org.eclipse.core.databinding.observable.list.WritableList;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.ColumnLayout;

/**
 * This is the main class of the example, demonstrating an overview of all features available in
 * RCPForms. It is a good start to get an idea how to do things using RCPForms.
 * <p>
 * 
 * @author vanmeegenm
 * @author Remo Loetscher
 */
public class SandboxStackForm extends RCPForm
{
    static final List<PartToModelMapping> partList = new LinkedList<PartToModelMapping>();
    
    static{
        //create datamodels
        partList.add(new PartToModelMapping(new SandboxGeneralFormPart(), new TestModel()));
        partList.add(new PartToModelMapping(new Sandbox3FormPart(), new AddressModel()));
        TableModel tableModel = new TableModel();
        partList.add(new PartToModelMapping(new SandboxTablePart(true), tableModel));
        partList.add(new PartToModelMapping(new SandboxListPart(true), tableModel));
        partList.add(new PartToModelMapping(new SandboxDualListSelectionPart(true), new TableModel()));
        partList.add(new PartToModelMapping(new SandboxRangeSampleFormPart(true), new IntegerRangeTestModel()));
        partList.add(new PartToModelMapping(new SandboxIconTextFormPart(true), new JavaBean()));
        partList.add(new PartToModelMapping(new SandboxLayoutFormPart(true), new SimpleBean()));
        AddressModel masterDetailModel = new AddressModel();
        masterDetailModel.setAddress(new NestedAddressModel());
        masterDetailModel.getAddress().setCity("SampleCity");
        masterDetailModel.getAddress().setZipCode(1234);
        partList.add(new PartToModelMapping(new SandboxMasterDetailFormPart(true), masterDetailModel));
        partList.add(new PartToModelMapping(new SandboxTableMasterDetailFormPart(true), new MasterDetailModel()));
        partList.add(new PartToModelMapping(new SandboxListMasterDetailFormPart(true), new MasterDetailModel()));
        partList.add(new PartToModelMapping(new ControlStateDependencyFormPart(true), new TestModel()));
        partList.add(new PartToModelMapping(new SandboxSortingTablePart(true), new IntegerModel()));
       
    }
    
    @SuppressWarnings("unchecked")
    private static <T> T getFormPart(Class<T> partClass)
    {
        for(PartToModelMapping partEntry : partList)
        {
            if(partClass.equals(partEntry.part.getClass()))
                return (T) partEntry.part;
        }
        return null;
    }
    
    private static Object getFormPartModel(Class<?> partClass)
    {
        for(PartToModelMapping partEntry : partList)
        {
            if(partClass.equals(partEntry.part.getClass()))
                return partEntry.model;
        }
        return null;
    }
    
    private static RCPFormPart[] getFormParts()
    {
        int i = 0;
        RCPFormPart[] parts = new RCPFormPart[partList.size()];
        for(PartToModelMapping partEntry : partList)
        {
            parts[i++] = partEntry.part;
        }
        return parts;
    }
    

    static JavaBean addPropertyChangeListener(final String name, final JavaBean model)
    {
        model.addPropertyChangeListener(new PropertyChangeListener()
        {
            public void propertyChange(PropertyChangeEvent evt)
            {
                System.out.println("Model \"" + name + "\" has changed: " + model);
            }
        });
        return model;
    }
    
    static WritableList addListChangeListener(final String name, final WritableList list)
    {
        list.addChangeListener(new IChangeListener()
        {
            public void handleChange(ChangeEvent event)
            {
                System.out.println("list model changed: " + name);
            }
        });
        return list;
    }

    /**
     * Constructor for SandboxStackForm
     */
    public SandboxStackForm()
    {
        // create form with the given title and form parts
        this(null);
    }
    
    public SandboxStackForm(ValidationManager vm)
    {
        super("RCPForm Sandbox Example", vm, getFormParts());
//        super("RCPForm Sandbox Example", vm);

    }

    
    @Override
    public void createUI(Composite parent)
    {
//        setFormParts(getFormParts());
        super.createUI(parent);
    }

    public void initializeUI()
    {
        // in initializeUI the form is created,
        // input-independent listeners, validators and stuff should be initialized here
        getValidationManager().addValidator(getFormPart(Sandbox3FormPart.class), new DateRangeValidator());

        // initializations which span multiple parts must be done here
        getFormPart(Sandbox3FormPart.class).getEnableButton().getSWTButton().addSelectionListener(
                new SelectionStateAdapter(getValidationManager(), EControlState.ENABLED));
                

        // initializations which span multiple parts must be done here
        getFormPart(Sandbox3FormPart.class).getVisibleButton().getSWTButton().addSelectionListener(
                new SelectionStateAdapter(getValidationManager(), EControlState.VISIBLE));
        
        getFormPart(Sandbox3FormPart.class).getExpandButton().getSWTButton().addSelectionListener(new SelectionAdapter(){
            public void widgetSelected(SelectionEvent e)
            {
                SandboxStackForm.this.expandSections(((Button)e.widget).getSelection());
            }});
    }
    
    

    @Override
    protected void initBodyLayout()
    {
        super.initBodyLayout();
//        ColumnLayout layout = new ColumnLayout();
//        layout.horizontalSpacing = 25;
//        layout.verticalSpacing = 25;
//        layout.minNumColumns = 2;
//        getManagedForm().getForm().getBody().setLayout(layout);
    }

    public void setFocus()
    {
        getFormPart(SandboxGeneralFormPart.class).setFocus();
    }
    
    protected void expandSections(boolean doExpand)
    {
        for(PartToModelMapping partEntry : SandboxStackForm.partList)
        {
            if(partEntry.part instanceof IExpandablePart)
            {
                ((IExpandablePart)partEntry.part).expandPart(doExpand);
            }
        }
        this.getScrolledForm().reflow(true);
    }

    /**
     * creates the models needed for the form and attaches listeners which echo changes to stdout
     * 
     * @return created models
     */
    public static Object[] createModels()
    {
        // and models
        Object[] models = new Object[partList.size()];
        int i = 0;
        for(PartToModelMapping partEntry : partList)
        {
            models[i++] = partEntry.model;
            if(partEntry.model instanceof JavaBean)
            {
                // add some listeners to check how databinding works
                addPropertyChangeListener(partEntry.part.getClass().getName(), (JavaBean)partEntry.model); 
            }
        }
       
        final AddressModel addressM = (AddressModel)getFormPartModel(Sandbox3FormPart.class);
        addPropertyChangeListener(addressM.getAddress().getClass().getName(), addressM.getAddress());
//        addPropertyChangeListener(addressM.getAddress().getCountry().getClass().getName(), addressM.getAddress().getCountry());

        final TableModel tableM = (TableModel) getFormPartModel(SandboxTablePart.class);
        addListChangeListener(tableM.getClass().getName() + ": list changed", tableM.getList());
        addListChangeListener(tableM.getClass().getName() + ": checked list changed", tableM.getSelectedList());

        return models;
    }

    /**
     * start the form as SWT application
     * 
     * @param args ignored
     */
    public static void main(String[] args)
    {
        // create form
        Object[] models = createModels();
        // create the form, no ui is created yet
        final SandboxStackForm rcpForm = new SandboxStackForm();
        // set input, since form is not created the input is not bound yet, but saved for createUI()
        rcpForm.setInput(models);

        // convenience method, creates a shell and creates the form ui in the shell
        // since an input has been set before, the form is bound to the model and ready to go
        rcpForm.startTestShell();
    }

}

class PartToModelMapping
{
    RCPFormPart part;
    Object model;
    
    PartToModelMapping(RCPFormPart formPart, Object formPartModel)
    {
        this.part = formPart;
        this.model = formPartModel;
    }
}

class SelectionStateAdapter extends SelectionAdapter
{
    EControlState state;
    ValidationManager vm;
    
    public SelectionStateAdapter(ValidationManager vm, EControlState state)
    {
        this.state = state;
        this.vm = vm;
    }
    
    @Override
    public void widgetSelected(SelectionEvent e)
    {
        boolean newState = !((Button) e.widget).getSelection();
        for(PartToModelMapping partEntry : SandboxStackForm.partList)
        {
            if(!(partEntry.part instanceof Sandbox3FormPart))
            {
                partEntry.part.setState(state, newState);
            }
        }
        vm.revalidate();
    }
}
