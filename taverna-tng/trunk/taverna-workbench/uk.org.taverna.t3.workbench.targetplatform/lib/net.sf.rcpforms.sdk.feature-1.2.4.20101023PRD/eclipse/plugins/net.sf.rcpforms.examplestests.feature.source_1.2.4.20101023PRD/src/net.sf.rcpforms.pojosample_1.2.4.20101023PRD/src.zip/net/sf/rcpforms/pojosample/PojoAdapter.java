/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.pojosample;

import net.sf.rcpforms.modeladapter.configuration.EnumRangeAdapter;
import net.sf.rcpforms.modeladapter.configuration.IRangeAdapter;
import net.sf.rcpforms.modeladapter.configuration.ModelAdapter;
import net.sf.rcpforms.modeladapter.converter.BeanConverterRegistry;
import net.sf.rcpforms.modeladapter.converter.IPropertyChain;
import net.sf.rcpforms.modeladapter.util.Validate;

import org.eclipse.core.databinding.beans.PojoObservables;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.IStructuredContentProvider;

public class PojoAdapter extends ModelAdapter
{

    public PojoAdapter()
    {
        super(new BeanConverterRegistry());
    }

    @Override
    public boolean canAdaptClass(Object metaClass)
    {
        return IPojoMarker.class.isAssignableFrom((Class<?>) metaClass);
    }

    @Override
    public IStructuredContentProvider createDefaultContentProvider()
    {
        return new ArrayContentProvider();
    }

    @Override
    public Object getMetaClass(Object modelInstanceToAdapt)
    {
        Validate.isTrue(!(modelInstanceToAdapt instanceof Class),
            "Please pass an instance of the class, not the class itself"); //$NON-NLS-1$
        return modelInstanceToAdapt.getClass();
    }

    @Override
    public IObservableValue getObservableValue(Object modelInstance, IPropertyChain propertyChain)
    {
        PojoPropertyChain chain = (PojoPropertyChain) propertyChain;
        //FIXME add nested property support
        return PojoObservables.observeValue(modelInstance, chain.properties[0]);
    }

    @Override
    public IPropertyChain getPropertyChain(Object metaClass, Object... properties)
    {
        return new PojoPropertyChain(metaClass, properties);
    }

    @SuppressWarnings("unchecked")
    @Override
    public IRangeAdapter getRangeAdapter(IPropertyChain propertyChain)
    {
        Validate.isTrue(propertyChain instanceof PojoPropertyChain);
        PojoPropertyChain chain = (PojoPropertyChain) propertyChain;
        if (chain.getType().isEnum())
        {
            return new EnumRangeAdapter((Class<? extends Enum<?>>) chain.getType());

        }
        return null;
    }

    @Override
    public void validatePropertyPath(Object metaClass, String propertyPath, boolean writable)
    {
        // TODO Auto-generated method stub
    }

}
