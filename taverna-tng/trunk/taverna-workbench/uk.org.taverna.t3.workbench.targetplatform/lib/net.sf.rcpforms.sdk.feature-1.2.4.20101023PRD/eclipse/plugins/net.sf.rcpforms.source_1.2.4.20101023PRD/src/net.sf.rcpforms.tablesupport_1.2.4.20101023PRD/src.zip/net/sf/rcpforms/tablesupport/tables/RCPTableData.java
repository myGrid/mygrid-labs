/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.tablesupport.tables;

import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.ViewerSorter;
import org.eclipse.swt.SWT;

/**
 * Configuration Object to customize table creation
 * 
 * @author Remo Loetscher
 */
public class RCPTableData
{
    /**
     * Enables automatically resizing of the columns. Available space will be distributed to all
     * columns but total width of all columns will not be greater then table widht. If columns have
     * to be resized programmatically set this flag to false.
     * Default value: true
     */
    public boolean enableAutoresizing = true;

    /**
     * If cursor support is enabled table can be browsed by keyboard and cell editing (if available)
     * will be activating by clicking \<enter\>.
     * Default value: true
     */
    public boolean enableTableCursorSupport = true;

    /**
     * If creating a table with {@link SWT#CHECK} style, setting this to true will create an empty
     * first column with the check boxes instead of the swt standard of inserting the checkbox into
     * the first column.
     * Default value: true
     */
    public boolean enableSeparateCheckboxColumn = true;

    /**
     * Configures the columns and cell editors. See {@link ColumnConfiguration} for further
     * information.
     * Default value: null
     */
    public ColumnConfiguration[] columnConfigurations = null;

    /**
     * If this flag is null, {@link TableUtil#configureTableViewer()} will create own Sorters for
     * each column which has to provide sorting functionality (
     * {@link ColumnConfiguration#enableColumnSorting(boolean)}). The created sorters will be stored
     * in the array. If column has no sorting functionality, a null value will be stored at the
     * column index. If the flag is set, the preconfigured Viewer sorters are used if
     * {@link ColumnConfiguration#enableColumnSorting(boolean)} is true. If a (column) index holds a
     * null value but {@link ColumnConfiguration#enableColumnSorting(boolean)} is true, a default
     * sorter will be added, otherwise the sorter for this column will be ignored. If
     * {@link RCPTableData#columnSorter} is not null before calling
     * {@link TableUtil#configureTableViewer()}, API user has to guarantee that the array length is
     * equal to {@link RCPTableData#columnConfigurations#length}.
     * Default value: null
     */
    public ViewerSorter[] columnSorter = null;

    /**
     * This flag will be set by {@link TableUtil#configureTableViewer()}. Any existing date before
     * calling {@link TableUtil#configureTableViewer()} will be overwritten!
     * Default value: null and should not be changed!
     */
    public TableViewerColumn[] viewerColumn = null;

}
