/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 *******************************************************************************/

package net.sf.rcpforms.examples.app.multipageeditor;

import java.util.logging.Logger;

import net.sf.rcpforms.examples.complete.models.AddressModel;
import net.sf.rcpforms.examples.complete.models.NestedAddressModel;
import net.sf.rcpforms.form.IRCPFormEditorInput;
import net.sf.rcpforms.form.RCPFormPageEditorPart;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;

public class AddressFormPageEditorPart extends RCPFormPageEditorPart<SandboxAddressForm>
{
    private static final Logger LOG = Logger.getLogger(AddressFormPageEditorPart.class.getName());

    
    public AddressFormPageEditorPart(SandboxAddressForm form)
    {
        super(form, "AddressFormPageEditorPart", "Lazy initialized AddressPart");
    }

    @Override
    public void doSave(IProgressMonitor monitor)
    {
        this.setDirty(false);
    }

    @Override
    public void doSaveAs()
    {
    }

    @Override
    public boolean isSaveAsAllowed()
    {
        return false;
    }
    
    @Override
    protected void initializeDirtyChangeListener(IRCPFormEditorInput oldInput,
                                                 IRCPFormEditorInput newInput)
    {
        super.initializeDirtyChangeListener(oldInput, newInput);
        //support dirty states for nested properties
        if(oldInput != null)
        {
            for(Object o : oldInput.getModels())
            {
                if(o instanceof AddressModel)
                {
                   this.removeDirtyChangeListener(o);
                   this.removeDirtyChangeListener(((AddressModel)o).getAddress());
                   this.removeDirtyChangeListener(((NestedAddressModel)((AddressModel)o).getAddress()).getCountry());
                }
            }
        }
        
        for(Object o : newInput.getModels())
        {
            if(o instanceof AddressModel)
            {
               this.addDirtyChangeListener(o);
               this.addDirtyChangeListener(((AddressModel)o).getAddress());
               this.addDirtyChangeListener(((NestedAddressModel)((AddressModel)o).getAddress()).getCountry());
            }
        }
    }
    
    

    @Override
    public void createPartControl(Composite parent)
    {
        LOG.info("createPartControl for object \"" + this.getClass().getName() + "\" called!");
        super.createPartControl(parent);
    }

    @Override
    public boolean selectReveal(Object object)
    {
        // TODO Auto-generated method stub
        return false;
    }
    
    
    public void init(IEditorSite site, IEditorInput input) throws PartInitException
    {
        super.init(site, ((MultipageCompositeEditorInput) input).getAddressEditorInput());
    }
}
