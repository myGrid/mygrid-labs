/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */
package net.sf.rcpforms.tablesupport.tables;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.jface.viewers.Viewer;

/**
 * Generic table sorter. Sorts the viewer input using {@link org.eclipse.jface.viewers.ViewerSorter}
 * . Extracts the value from datamodel by using the given property. if (and only if) both objects
 * are of type comparable than calls compareTo on the first object if sorting direction is
 * descending or the second object if direction is ascending. Otherwise it uses comparing logic from
 * {@link org.eclipse.jface.viewers.ViewerSorter#compare(Viewer, Object, Object)}
 * 
 * @author Loetscher Remo
 */
public class GenericTableSorter extends AbstractGenericSorter
{
    private static final Logger LOG = Logger.getLogger(GenericTableSorter.class.getName());

    private boolean descendingOrder = true;

    private String property;

    public GenericTableSorter(String property)
    {
        this.property = property;
    }

    public void switchSortDirection()
    {
        // switch sorting order
        descendingOrder = !descendingOrder;

    }

    public boolean isDescendingOrder()
    {
        return descendingOrder;
    }

    @SuppressWarnings("unchecked")
    @Override
    public int compare(Viewer viewer, Object e1, Object e2)
    {
        int returnValue = 0;
        Object value1 = this.getPropertyValue(e1, property);
        Object value2 = this.getPropertyValue(e2, property);

        // only use comparable if both values are instanceof comparable. if one
        // value is null: super.compare() will be called
        boolean useComparableInterface = value1 instanceof Comparable
                && value2 instanceof Comparable;

        if (useComparableInterface)
        {
            returnValue = ((Comparable) value1).compareTo(value2);
        }
        else
        {
            returnValue = super.compare(viewer, value1, value2);
        }
        return descendingOrder ? -returnValue : returnValue;
    }

    @Override
    public boolean isSorterProperty(Object element, String property)
    {
        return this.property.equals(property);
    }

    @Override
    public void sort(Viewer viewer, Object[] elements)
    {
        super.sort(viewer, elements);
    }

    protected Object getPropertyValue(Object object, String property)
    {
        Object result = null;
        try
        {
            PropertyDescriptor pd = new PropertyDescriptor(property, object.getClass());
            Method readMethod = pd.getReadMethod();
            result = readMethod.invoke(object, new Object[]{});
        }
        catch (Exception ex)
        {
            LOG.log(Level.SEVERE, "Error getting value for property " + property + "!", ex); //$NON-NLS-1$ //$NON-NLS-2$
        }
        return result;
    }
}
