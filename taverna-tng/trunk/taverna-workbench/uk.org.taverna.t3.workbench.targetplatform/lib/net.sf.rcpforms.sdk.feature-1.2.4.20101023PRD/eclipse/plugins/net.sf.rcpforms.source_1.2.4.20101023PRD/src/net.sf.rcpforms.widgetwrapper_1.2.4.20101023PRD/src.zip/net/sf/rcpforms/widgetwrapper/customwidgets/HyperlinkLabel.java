/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.widgetwrapper.customwidgets;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.ui.forms.widgets.Hyperlink;

/**
 * A hyperlink which can be used as normal label.
 * If {@link HyperlinkLabel#setUseAsHyperlink(boolean)} is set to false the hyperlink renders as simple label.
 * @author Remo Loetscher
 *
 */
public class HyperlinkLabel extends Hyperlink
{
    //FIXME what is the correct moment for dispose these cursors?
    private static final Cursor handCursor = new Cursor(Display.getCurrent(), SWT.CURSOR_HAND);
    private static final Cursor arrowCursor = new Cursor(Display.getCurrent(), SWT.CURSOR_ARROW);

    private boolean isHyperlinkModeEnabled = false;
    
    public HyperlinkLabel(Composite parent, int style)
    {
        super(parent, style);
    }

    public boolean getUseAsHyperlink()
    {
        return isHyperlinkModeEnabled;
    }

    /**
     * @param useAsHyperlink enable or disable hyperlink functionality
     */
    public void setUseAsHyperlink(boolean useAsHyperlink)
    {
        isHyperlinkModeEnabled = useAsHyperlink;
        super.setUnderlined(useAsHyperlink);
        if (useAsHyperlink)
            setCursor(handCursor);
        else
            setCursor(arrowCursor);
    }
    @Override
    protected void handleActivate(Event e)
    {
        if (isHyperlinkModeEnabled)
            super.handleActivate(e);
    }

    @Override
    protected void handleExit(Event e)
    {
        if (isHyperlinkModeEnabled)
            super.handleExit(e);
    }

    @Override
    protected void handleEnter(Event e)
    {
        if (isHyperlinkModeEnabled)
            super.handleEnter(e);
    }

}
