
package net.sf.rcpforms.test.formpart;

import java.util.Date;

import net.sf.rcpforms.bindingvalidation.ValidationManager;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormFactory;
import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.modeladapter.configuration.BeanAdapter;
import net.sf.rcpforms.modeladapter.converter.AbstractModelValidator;
import net.sf.rcpforms.modeladapter.converter.RequiredValidator;
import net.sf.rcpforms.widgetwrapper.builder.GridBuilder;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPCombo;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPRadioButton;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSection;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleButton;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleLabel;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleText;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPWidget;

import org.eclipse.core.runtime.IStatus;
import org.eclipse.jface.viewers.ContentViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.Section;

public class PersonFormPart extends RCPFormPart
{

    private boolean enableValidation = true;
    
    public static final String BIRTHDATE_LABEL = "Birthdate:";

    public static final String COUNTRY_LABEL = "Country:";
    
    public static final String COUNTRY_DETAIL_LABEL = "Country(Detail):";

    public static final String CITY_LABEL = "City:";

    public static final String STREET_NUMBER_LABEL = "Street/Number:";

    public static final String FIRSTNAME_LABEL = "Firstname:";

    public static final String NAME_LABEL = "PersonFormPartName:";
    
    public static final String TRUE_RADIO_LABEL = "true:";

    public static final String FALSE_RADIO_LABEL = "false:";
    
    /**
     * Class DateFutureValidator is an example for a custom validator
     * 
     * @author Remo Loetscher
     */
    public static final class DateFutureValidator extends AbstractModelValidator
    {
        @Override
        public Object[] getProperties()
        {
            return new String[]{PersonDataModel.P_Birthdate};
        }

        @Override
        public IStatus validate(Object value)
        {
            PersonDataModel model = (PersonDataModel) value;
            IStatus result = ok();
            if (model.getBirthdate() != null && model.getBirthdate().after(new Date()))
            {
                result = error("Birthdate has to be in the past!");
            }
            return result;
        }
    }

    private RCPSection section;

    public RCPText name;

    public RCPText firstName;

    public RCPText street;

    public RCPText streetNumber;

    public RCPText city;

    public RCPCombo country;
    
    public RCPText countryDetail;

    public RCPText birthdate;
    
    public RCPRadioButton trueRadio, falseRadio;
    
    public RCPSimpleButton checkBox;

    private GridBuilder formPartBuilder;

    private GridBuilder sectionBuilder;
    
    public PersonFormPart()
    {
        this(true);
    }
    
    public PersonFormPart(boolean enableValidation)
    {
        super();
        this.enableValidation = enableValidation;
    }

    @Override
    public void bind(ValidationManager bm, Object modelBean)
    {
        bm.bindValue(name, modelBean, PersonDataModel.P_Name);
        bm.bindValue(firstName, modelBean, PersonDataModel.P_FirstName);
        bm.bindValue(street, modelBean, PersonDataModel.P_Street);
        bm.bindValue(streetNumber, modelBean, PersonDataModel.P_StreetNumber);
        bm.bindValue(city, modelBean, PersonDataModel.P_City);
        bm.bindValue(country, modelBean, PersonDataModel.P_Country);
        //let test case do detailbinding
        //bm.bindDetailValue(BeanAdapter.getInstance(), country, Country.class, new RCPControl[]{countryDetail}, new String[]{Country.P_NAME});
        bm.bindValue(birthdate, modelBean, PersonDataModel.P_Birthdate);

        // add required validator
        if(enableValidation)
            bm.addValidator(this, new RequiredValidator(PersonDataModel.P_Name,
                PersonDataModel.P_FirstName, PersonDataModel.P_Birthdate));

        // add date validator
        if(enableValidation)
            bm.addValidator(this, new DateFutureValidator());
    }

    @Override
    public void createUI(FormToolkit toolkit, Composite parent)
    {
        // create RCPForm elements
        section = new RCPSection("This title will be invisible", Section.NO_TITLE);
        name = new RCPText(NAME_LABEL);
        name.setState(EControlState.MANDATORY, true);
        firstName = new RCPText(FIRSTNAME_LABEL);
        firstName.setState(EControlState.MANDATORY, true);
        street = new RCPText(STREET_NUMBER_LABEL);
        streetNumber = new RCPText(null);
        city = new RCPText(CITY_LABEL);
        country = new RCPCombo(COUNTRY_LABEL);
        countryDetail = new RCPText(COUNTRY_DETAIL_LABEL);
        countryDetail.setState(EControlState.READONLY, true);
        birthdate = new RCPText(BIRTHDATE_LABEL);
        birthdate.setState(EControlState.MANDATORY, true);
        
        trueRadio = new RCPRadioButton("");
        falseRadio = new RCPRadioButton("");
        checkBox = new RCPSimpleButton("", SWT.CHECK);

        // add elements to container
        formPartBuilder = new GridBuilder(toolkit, parent, 2);
        sectionBuilder = formPartBuilder.addContainer(section, 4);
        // 1st line
        sectionBuilder.addLineGrabAndFill(name, 3);
        // 2nd line
        sectionBuilder.addLine(firstName);
        // 3rd line
        sectionBuilder.add(street);
        sectionBuilder.add(streetNumber);
        sectionBuilder.fillLine();
        // 4th line
        sectionBuilder.addLine(city);
        // 5th line
        sectionBuilder.addLine(country);
        // 6th line
        sectionBuilder.addLine(birthdate, 10);
        //details section
        sectionBuilder.addLineGrabAndFill(countryDetail, 3);
        //radio buttons
        sectionBuilder.add(new RCPSimpleLabel(TRUE_RADIO_LABEL));
        sectionBuilder.add(trueRadio);
        sectionBuilder.add(new RCPSimpleLabel(FALSE_RADIO_LABEL));
        sectionBuilder.add(falseRadio);
        sectionBuilder.add(checkBox);
        sectionBuilder.fillLine();
        
    }
    
    public ContentViewer getCountryViewer()
    {
        return country.getViewer();
    }

    @Override
    public void setState(EControlState state, boolean value)
    {
        section.setState(state, value);
    }
    
    public void dispose()
    {
        for(RCPWidget widget : formPartBuilder.getCreatedControls())
        {
            System.err.println(widget);
            widget.dispose();
        }
        
    }
    
    public static void main(String[] args)
    {
        PersonDataModel model = new PersonDataModel();
        PersonFormPart formPart = new PersonFormPart();
        RCPFormFactory.getInstance().startTestShell("Test-Person FormPart", formPart, model);
    }

}
