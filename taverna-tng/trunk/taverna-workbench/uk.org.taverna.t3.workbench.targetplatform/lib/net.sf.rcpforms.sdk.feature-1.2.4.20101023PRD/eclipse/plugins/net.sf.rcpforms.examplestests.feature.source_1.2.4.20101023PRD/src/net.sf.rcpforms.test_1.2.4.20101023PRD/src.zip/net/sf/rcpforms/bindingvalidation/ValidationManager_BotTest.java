/*******************************************************************************
 * This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Remo Loetscher - initial API and implementation
 *
 ******************************************************************************
 */

package net.sf.rcpforms.bindingvalidation;

import net.sf.rcpforms.bindingvalidation.forms.RCPFormPart;
import net.sf.rcpforms.modeladapter.configuration.BeanAdapter;
import net.sf.rcpforms.modeladapter.configuration.ModelAdapter;
import net.sf.rcpforms.modeladapter.converter.IModelValidator;
import net.sf.rcpforms.modeladapter.converter.IValidatorConverterStrategy;
import net.sf.rcpforms.modeladapter.converter.MethodValidator;
import net.sf.rcpforms.modeladapter.converter.ValidatorConverterStrategy;
import net.sf.rcpforms.test.formpart.Country;
import net.sf.rcpforms.test.formpart.PersonDataModel;
import net.sf.rcpforms.test.formpart.PersonFormPart;
import net.sf.rcpforms.widgetwrapper.wrapper.EControlState;
import net.sf.rcpforms.widgetwrapper.wrapper.IViewer;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPControl;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPSimpleButton;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPText;
import net.sf.rcpforms.widgetwrapper.wrapper.RCPWidget;
import net.sf.rcpforms.widgetwrapper.wrapper.radio.RadioGroupManager;
import net.sf.swtbot.widgets.SWTBotButton;
import net.sf.swtbot.widgets.SWTBotText;

import org.eclipse.core.databinding.Binding;
import org.eclipse.core.databinding.UpdateValueStrategy;
import org.eclipse.core.databinding.conversion.IConverter;
import org.eclipse.core.databinding.observable.list.IObservableList;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Event;

/**
 * FIXME add testlogic
 * UI Test for testing all bindings and conversions of a widget against supported types of model
 * values. The following is tested:
 * <ul>
 * <li>propagation of property changes to widget
 * <li>propagation of widget changes by user to model
 * <li>null value handling
 * </ul>
 * 
 * @author Remo Loetscher
 */
public class ValidationManager_BotTest extends BindingBaseTestCase
{
    
    private PersonDataModel model;
    private PersonFormPart formPart;
    TestValidator val = new TestValidator();

    @Override
    public void setUp() throws Exception
    {
        super.setUp();
        model = new PersonDataModel();
        formPart = new PersonFormPart(false);
        // create form part ui in shell
        formPart.createUI(toolkit, getShell());
        // ATTENTION: DO NOT USE formPart.bind() since this is not intended to be used from clients!
        validationManager.bindPart(formPart, model);
        val.validated = false;
        val.validationResult = Status.OK_STATUS;
    }


    @Override
    public void tearDown() throws Exception
    {
        super.tearDown();
        validationManager.unbindPart(formPart);
        formPart.dispose();
    }


    public void testaddValidator() throws Exception
    {
        validationManager.addValidator(formPart, val);
        validationManager.updateValidationStatus(null);
        assertTrue(val.validated);
    }

    
    public void testbindDetailValue1() throws Exception
    {
        //validationManager.bindDetailValue(bean, masterProperty, rcpWidgets, detailProperties)
        model.setCountry(Country.GERMANY);
        validationManager.bindDetailValue(model, PersonDataModel.P_Country, new RCPControl[]{formPart.countryDetail}, new String[]{Country.P_NAME});
        assertEquals(model.getCountry().getName(), formPart.countryDetail.getSWTText().getText());
        model.setCountry(null);
        assertNull(model.getCountry());
        assertEquals("", formPart.countryDetail.getSWTText().getText());
    }

    
    public void testbindDetailValue2() throws Exception
    {
        //validationManager.bindDetailValue(adapter, wrapperWithViewer, modelClass, rcpWidgets, detailProperties)
        Binding[] bindDetailValue = validationManager.bindDetailValue(BeanAdapter.getInstance(), formPart.country, Country.class, new RCPControl[]{formPart.countryDetail}, new String[]{Country.P_NAME});
        model.setCountry(Country.GERMANY);
        assertEquals(model.getCountry().getName(), formPart.countryDetail.getSWTText().getText());
        model.setCountry(null);
        assertNull(model.getCountry());
        assertEquals("", formPart.countryDetail.getSWTText().getText());
        //remove and dispose bindings
        for(Binding b : bindDetailValue)
        {
            validationManager.removeBinding(formPart, b);
            b.dispose();
        }
    }

    
    public void testbindDetailValue3() throws Exception
    {
        //validationManager.bindDetailValue(adapter, wrapperWithViewer, modelClass, rcpWidgets, detailProperties, validatorAndConverterStrategies)
        Binding[] bindDetailValue = validationManager.bindDetailValue(BeanAdapter.getInstance(), formPart.country, Country.class, new RCPControl[]{formPart.countryDetail}, new String[]{Country.P_NAME}, new IValidatorConverterStrategy[]{new TestConverterValidatorStrategy()});
        model.setCountry(Country.GERMANY);
        assertEquals(model.getCountry().getName(), formPart.countryDetail.getSWTText().getText());
        model.setCountry(null);
        assertNull(model.getCountry());
        assertEquals("", formPart.countryDetail.getSWTText().getText());
        //remove and dispose bindings
        for(Binding b : bindDetailValue)
        {
            validationManager.removeBinding(formPart, b);
            b.dispose();
        }
    }

    
    public void testbindInvertedState1() throws Exception
    {
        //validationManager.bindInvertedState(rcpControl, state, observable)
        //create observable
        BeanAdapter adapter = BeanAdapter.getInstance();
        IObservableValue observable = adapter.getObservableValue(model, adapter.getPropertyChain(model.getClass(), PersonDataModel.P_BooleanFlag));
        
        Binding binding = validationManager.bindInvertedState(formPart.name, EControlState.READONLY, observable);
        //check initial state. boolean property is initialzed with false
        assertTrue(formPart.name.hasState(EControlState.READONLY));
        
        model.setBooleanFlag(true);
        assertFalse(formPart.name.hasState(EControlState.READONLY));
        
        model.setBooleanFlag(false);
        assertTrue(formPart.name.hasState(EControlState.READONLY));
        binding.dispose();
        validationManager.removeBinding(formPart, binding);
        //set origin state
        formPart.name.setState(EControlState.READONLY, false);
        model.setBooleanFlag(false);
    }

    
    public void testbindInvertedState2() throws Exception
    {
        //validationManager.bindInvertedState(rcpWidget, state, bean, properties)
        Binding binding = validationManager.bindInvertedState(formPart.name, EControlState.READONLY, model, PersonDataModel.P_BooleanFlag);
        //check initial state. boolean property is initialzed with false
        assertTrue(formPart.name.hasState(EControlState.READONLY));
        
        model.setBooleanFlag(true);
        assertFalse(formPart.name.hasState(EControlState.READONLY));
        
        model.setBooleanFlag(false);
        assertTrue(formPart.name.hasState(EControlState.READONLY));
        binding.dispose();
        validationManager.removeBinding(formPart, binding);
        //set origin state
        formPart.name.setState(EControlState.READONLY, false);
        model.setBooleanFlag(false);
    }

    
//    public void testbindPart() throws Exception
//    {
//        validationManager.bindPart(formPart, model);
//    }

    
    public void testbindRadioToBoolean() throws Exception
    {
        //validationManager.bindRadioToBoolean(trueRadioButton, falseRadioButton, bean, properties);
        Binding bindRadioToBoolean = validationManager.bindRadioToBoolean(formPart.trueRadio, formPart.falseRadio, model, PersonDataModel.P_BooleanFlag);
        model.setBooleanFlag(false);
        assertTrue(formPart.falseRadio.getSWTButton().getSelection());
        assertFalse(formPart.trueRadio.getSWTButton().getSelection());
        //FIXME swtbot cannot find checkbox button: net.sf.swtbot.widgets.WidgetNotFoundException: Could not find widget with text true:
//        SWTBotButton button = bot.button(PersonFormPart.TRUE_RADIO);
//        button.click();
//        formPart.trueRadio.getSWTButton().setSelection(true);
//        this.dummyClick(formPart.trueRadio.getSWTButton());
        model.setBooleanFlag(true);
        assertTrue(formPart.trueRadio.getSWTButton().getSelection());
        assertFalse(formPart.falseRadio.getSWTButton().getSelection());
        assertTrue(model.getBooleanFlag());
        
        //remove and dispose binding
        validationManager.removeBinding(formPart, bindRadioToBoolean);
        bindRadioToBoolean.dispose();
    }

//    public void testbindSelection() throws Exception
//    {
//        validationManager.bindSelection(wrapperWithViewer, modelWritableList);
//    }

    
//    public void testbindSelection() throws Exception
//    {
//        validationManager.bindSelection(wrapperWithViewer, observableValue);
//    }

    
//    public void testbindSelection() throws Exception
//    {
//        validationManager.bindSelection(adapter, wrapperWithViewer, modelWritableList);
//    }

    
//    public void testbindSelection() throws Exception
//    {
//        validationManager.bindSelection(adapter, wrapperWithViewer, observableValue)
//    }

    
//    public void testbindState() throws Exception
//    {
//        validationManager.bindState(rcpControl, state, observable);
//    }

    
    public void testbindState() throws Exception
    {
        //validationManager.bindState(rcpWidget, state, bean, properties);
        //validationManager.bindInvertedState(rcpWidget, state, bean, properties)
        Binding binding = validationManager.bindState(formPart.name, EControlState.READONLY, model, PersonDataModel.P_BooleanFlag);
        //check initial state. boolean property is initialzed with false
        assertFalse(formPart.name.hasState(EControlState.READONLY));
        
        model.setBooleanFlag(true);
        assertTrue(formPart.name.hasState(EControlState.READONLY));
        
        model.setBooleanFlag(false);
        assertFalse(formPart.name.hasState(EControlState.READONLY));
        binding.dispose();
        validationManager.removeBinding(formPart, binding);
        //set origin state
        formPart.name.setState(EControlState.READONLY, false);
        model.setBooleanFlag(false);
    }

    
    public void testbindValue1() throws Exception
    {
        //validationManager.bindValue(rcpWidget, observable);
        //create observable
        BeanAdapter adapter = BeanAdapter.getInstance();
        IObservableValue observable = adapter.getObservableValue(model, adapter.getPropertyChain(model.getClass(), PersonDataModel.P_BooleanFlag));
        Binding bindValue = validationManager.bindValue(formPart.checkBox, observable);
        model.setBooleanFlag(false);
        assertFalse(formPart.checkBox.getSWTButton().getSelection());
        model.setBooleanFlag(true);
        assertTrue(formPart.checkBox.getSWTButton().getSelection());
        
        //remove and dispose binding
        validationManager.removeBinding(formPart, bindValue);
        bindValue.dispose();
    }

    
    public void testbindValue2() throws Exception
    {
        //validationManager.bindValue(widgetObservableValue, bean, properties);
        model.setName("FooBar");
        assertEquals(model.getName(), formPart.name.getSWTText().getText());
        model.setName(null);
        assertEquals("", formPart.name.getSWTText().getText());
        
//        SWTBotText tester = bot.textWithLabel(PersonFormPart.NAME_LABEL);
//        tester.setText("WidgetText");
        formPart.name.getSWTText().setText("WidgetText");
        assertEquals(model.getName(), "WidgetText");
//        tester.setText("");
        formPart.name.getSWTText().setText("");
        assertNull(model.getName());
    }

    
//    public void testbindValue() throws Exception
//    {
//        validationManager.bindValue(adapter, rcpWidget, observable);
//    }

    
//    public void testbindValue() throws Exception
//    {
//        validationManager.bindValue(rgManager, bean, properties);
//    }

    
//    public void testbindValue() throws Exception
//    {
//        validationManager.bindValue(rcpWidget, bean, properties);
//    }

    
//    public void testbindValue() throws Exception
//    {
//        validationManager.bindValue(widgetObservableValue, validatorConverterStrategy, bean, properties);
//    }

    
//    public void testbindValue() throws Exception
//    {
//        validationManager.bindValue(rcpWidget, validatorConverterStrategy, bean, properties);
//    }

    
//    public void testbindValue() throws Exception
//    {
//        validationManager.bindValue(widgetObservableValue, modelToTargetConverter, targetToModelConverter, bean, properties);
//    }

    
//    public void testenableValidation() throws Exception
//    {
//        validationManager.enableValidation(enableValidation);
//    }

    
    public void testgetValidationState() throws Exception
    {
        IObservableValue validationState = validationManager.getValidationState();
        assertNotNull(validationState);
        
        //validation without widgets
        assertEquals(((Status)validationState.getValue()).getSeverity(), IStatus.OK);
        TestValidator testValidator = new TestValidator(new Status(IStatus.WARNING, "id", "warning"));
        validationManager.addValidator(formPart, testValidator);
        IStatus resultState = validationManager.revalidate();
        assertTrue(testValidator.validated);
        //if no widget is found at all -> validation state is not used --> State is ok
        assertEquals(resultState.getSeverity(), IStatus.OK);
        validationManager.removeValidator(formPart, testValidator);
        
        //validation with widget
        assertEquals(((Status)validationState.getValue()).getSeverity(), IStatus.OK);
        testValidator = new PropertyTestValidator(new Status(IStatus.WARNING, "id", "warning"));
        validationManager.addValidator(formPart, testValidator);
        resultState = validationManager.revalidate();
        assertTrue(testValidator.validated);
        //widget name is found -> validation state will be changed and new state is warning
        assertEquals(resultState.getSeverity(), IStatus.WARNING);
        validationManager.removeValidator(formPart, testValidator);
    }

    
    public void testgetValidatorCount() throws Exception
    {
        assertEquals(validationManager.getValidatorCount(formPart), 0);
        validationManager.addValidator(formPart, val);
        assertEquals(validationManager.getValidatorCount(formPart), 1);
        validationManager.removeValidator(formPart, val);
        assertEquals(validationManager.getValidatorCount(formPart), 0);
    }

    
//    public void testregisterWidgetForProperty() throws Exception
//    {
//        validationManager.registerWidgetForProperty(formPart, rcpWidget, model, properties);
//    }

    
//    public void testremoveBinding() throws Exception
//    {
//        validationManager.removeBinding(formPart, binding);
//    }

    
//    public void testremoveValidator() throws Exception
//    {
//        validationManager.removeValidator(formPart, va(formPartor);
//    }

    
//    public void testunbindAllParts() throws Exception
//    {
//        validationManager.unbindAllParts();
//    }

    
//    public void testunbindPart() throws Exception
//    {
//        validationManager.unbindPart(formPart);
//    }

    
//    public void testunregisterWidgetForProperty() throws Exception
//    {
//        validationManager.unregisterWidgetForProperty(formPart, rcpWidget, model, properties);
//    }

    
    public void testupdateFormToModel() throws Exception
    {
        validationManager.updateFormToModel();
    }

    
    public void testupdateModelToForm() throws Exception
    {
        validationManager.updateModelToForm();
    }

    public void testupdateValidationStatus() throws Exception
    {
        validationManager.updateValidationStatus(null);
    }
    
    public void testCustomUpdateValueStrategy()
    {
        String dummyText = "CustomUpdateValueStrategy";
        RCPText text = new RCPText(dummyText);
        builder.add(text);
        int model2target = validationManager.getModelToTargetUpdateStrategy();
        int target2model = validationManager.getTargetToModelUpdateStrategy();
        
        assertEquals(model2target, UpdateValueStrategy.POLICY_UPDATE);
        assertEquals(target2model, UpdateValueStrategy.POLICY_UPDATE);
        
        validationManager.setModelToTargetUpdateStrategy(UpdateValueStrategy.POLICY_ON_REQUEST);
        validationManager.setTargetToModelUpdateStrategy(UpdateValueStrategy.POLICY_ON_REQUEST);
        
        validationManager.bindValue(text, model, PersonDataModel.P_Name);
        model.setName(dummyText);
        assertEquals(text.getSWTText().getText(), "");
        validationManager.updateModelToForm();
        assertEquals(text.getSWTText().getText(), dummyText);
        
        text.getSWTText().setText("");
        assertEquals(model.getName(), dummyText);
        validationManager.updateFormToModel();
        assertNull(model.getName());
        
        
        //reset policy
        validationManager.setModelToTargetUpdateStrategy(model2target);
        validationManager.setTargetToModelUpdateStrategy(target2model);
        
        }
    
    private void dummyClick(Control c)
    {
        // copied from net.sf.swtbot.widgets.SWTBotButton.click()
        c.notifyListeners(SWT.MouseEnter, createEvent(c));
        c.notifyListeners(SWT.MouseMove, createEvent(c));
        c.notifyListeners(SWT.Activate, createEvent(c));
        c.notifyListeners(SWT.FocusIn, createEvent(c));
        c.notifyListeners(SWT.MouseDown, createEvent(c));
        c.notifyListeners(SWT.MouseUp, createEvent(c));
        c.notifyListeners(SWT.Selection, createEvent(c));
        c.notifyListeners(SWT.MouseHover, createEvent(c));
        c.notifyListeners(SWT.MouseMove, createEvent(c));
        c.notifyListeners(SWT.MouseExit, createEvent(c));
        c.notifyListeners(SWT.Deactivate, createEvent(c));
        c.notifyListeners(SWT.FocusOut, createEvent(c));
    }
    
    protected Event createEvent(Control c) {
        // copied from net.sf.swtbot.widgets.SWTBotButton.click()
        Event event = new Event();
        event.time = (int) System.currentTimeMillis();
        event.widget = c;
        event.display = c.getDisplay();
        return event;
    }
}

class TestValidator extends MethodValidator
{
    boolean validated = false;
    IStatus validationResult;
  
    public TestValidator()
    {
        this(Status.OK_STATUS);
    }
    
    public TestValidator(IStatus result)
    {
        validationResult = result;
    }
    
    @Override
    public IStatus validate(Object model)
    {
        validated = true;
        return validationResult;
    }
}

class PropertyTestValidator extends TestValidator
{
    boolean validated = false;
    IStatus validationResult;
  
    public PropertyTestValidator()
    {
        this(Status.OK_STATUS);
    }
    
    public PropertyTestValidator(IStatus result)
    {
        super(result);
    }

    @Override
    public Object[] getProperties()
    {
        return new Object[]{PersonDataModel.P_Name};
    }

    @Override
    public Object[] getInvalidProperties(Object model)
    {
        return new Object[]{PersonDataModel.P_Name};
    }
}

class TestConverterValidatorStrategy extends ValidatorConverterStrategy
{
    
}
