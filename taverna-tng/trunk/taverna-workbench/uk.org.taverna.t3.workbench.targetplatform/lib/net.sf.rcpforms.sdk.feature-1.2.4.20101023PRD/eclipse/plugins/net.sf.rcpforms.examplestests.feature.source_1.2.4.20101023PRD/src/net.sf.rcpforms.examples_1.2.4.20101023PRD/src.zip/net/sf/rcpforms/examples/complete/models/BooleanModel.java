package net.sf.rcpforms.examples.complete.models;

import net.sf.rcpforms.common.model.JavaBean;

public class BooleanModel extends JavaBean
{
    
    public static final String P_A_PROP = "aprop";
    
    public static final String P_B_PROP = "bprop";

    public static final String P_C_PROP = "cprop";

    public static final String P_D_PROP = "dprop";
    
    private Boolean aprop; 
    private Boolean bprop; 
    private Boolean cprop; 
    private Boolean dprop;
    
    public BooleanModel(Boolean aprop, Boolean bprop, Boolean cprop, Boolean dprop)
    {
        super();
        this.aprop = aprop;
        this.bprop = bprop;
        this.cprop = cprop;
        this.dprop = dprop;
    }
    
    public Boolean getAprop()
    {
        return aprop;
    }
    public void setAprop(Boolean value)
    {
        Object oldValue = aprop;
        aprop = value;
        propertyChangeSupport.firePropertyChange(P_A_PROP, oldValue, value);
        this.aprop = value;
    }
    public Boolean getBprop()
    {
        return bprop;
    }
    public void setBprop(Boolean value)
    {
        Object oldValue = bprop;
        bprop = value;
        propertyChangeSupport.firePropertyChange(P_B_PROP, oldValue, value);
        this.bprop = value;
    }
    public Boolean getCprop()
    {
        return cprop;
    }
    public void setCprop(Boolean value)
    {
        Object oldValue = cprop;
        cprop = value;
        propertyChangeSupport.firePropertyChange(P_C_PROP, oldValue, value);
        this.cprop = value;
    }
    public Boolean getDprop()
    {
        return dprop;
    }
    public void setDprop(Boolean value)
    {
        Object oldValue = dprop;
        dprop = value;
        propertyChangeSupport.firePropertyChange(P_D_PROP, oldValue, value);
        this.dprop = value;
    }
    public static Object[] createModel()
    {
        BooleanModel[] model = new BooleanModel[]{
                new BooleanModel(true, true, true, true),
                new BooleanModel(true, true, true, false),
                new BooleanModel(true, true, false, true),
                new BooleanModel(true, true, false, false),
                new BooleanModel(true, false, true, true),
                new BooleanModel(true, false, true, false),
                new BooleanModel(true, false, false, true),
                new BooleanModel(true, false, false, false),
                new BooleanModel(false, true, true, true),
                new BooleanModel(false, true, true, false),
                new BooleanModel(false, true, false, true),
                new BooleanModel(false, true, false, false),
                new BooleanModel(false, false, true, true),
                new BooleanModel(false, false, true, false),
                new BooleanModel(false, false, false, true),
                new BooleanModel(false, false, false, false),
        };
        
        return model;
    } 
}
