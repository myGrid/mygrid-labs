package net.sf.rcpforms.examples.complete;

import net.sf.rcpforms.examples.complete.models.AddressModel;
import net.sf.rcpforms.modeladapter.converter.AbstractModelValidator;

import org.eclipse.core.runtime.IStatus;

/**
 * Class DateRangeValidator is an example for a validator working on more than one field
 * 
 * @author Marco van Meegen
 */
public class DateRangeValidator extends AbstractModelValidator
{
    public Object[] getProperties()
    {
        return new String[]{AddressModel.P_ValidFrom, AddressModel.P_ValidTo};
    }

    public IStatus validate(Object value)
    {
        AddressModel model = (AddressModel) value;
        IStatus result = ok();
        if (model.getValidFrom() != null && model.getValidTo() != null
                && model.getValidFrom().after(model.getValidTo()))
        {
            result = error("From Date must be earlier than To Date");
        }
        return result;
    }
}
